# Phase 9 – Cookie-Banner: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-08` = `2103af28de15`, Tag `fawkes-phase-09` = `496ba1a47f87`, Tree `cd5a108f697d`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `286d58177635` | Fawkes: Turn on the cookie banner service with the rules from the tree |
| 2 | `1c21e7bc0186` | Fawkes: Decide the cookie banner handling per site |
| 3 | `5296c8cb55c1` | Fawkes: Reject unknown cookie banners heuristically |
| 4 | `c7b83486731c` | Fawkes: Show the cookie banner result in the menu |
| 5 | `8edc6903b2d9` | Fawkes: Follow the cookie banner rules more closely |
| 6 | `a15144ed5fb1` | Fawkes: Test the cookie banner handling |
| 7 | `ef4cbb5fdcb6` | Fawkes: Document the cookie banner handling |
| 8 | `b4f7cfb060a9` | Fawkes: Harden the cookie banner heuristics (eigene Durchsicht) |
| 9 | `7d01fc24424e` | Fawkes: Fix the findings of the cookie banner review (erste Code-Prüfung) |
| 10 | `496ba1a47f87` | Fawkes: Fix the findings of the second cookie banner review (zweite Code-Prüfung) |

Patches: `fawkes-patches/phase-09-cookie-banners/` (10 Dateien) und `fawkes-patches/phase-09-cookie-banners.patch` (69 Dateien).
Plan: `/home/dh/.claude/plans/fawkes-phase-09.md` (ohne Rückfrage umgesetzt, wie vereinbart).
Technische Doku: `browser/components/fawkes/docs/cookie-banners.md`; Tabelle in `categories.md`, Hinweise in `architecture.md`, `storage.md`.

## Was jetzt da ist

Der Schalter `cookieBanner` („Cookie-Banner automatisch ablehnen“, Gruppe Privatsphäre, Standard an) wirkt jetzt pro Site. Zwei Teile arbeiten zusammen, beide privilegierter Browser-Code; nichts wird in Seiten injiziert, keine Erweiterung:

1. **Firefox' Cookie-Banner-Dienst** (`nsCookieBannerService`, Cookie-Injektor, `CookieBannerChild/Parent`) läuft im Modus 2 („ablehnen, sonst akzeptieren“) in normalem und privatem Surfen, mit globalen CMP-Regeln auch in Subframes. Das überschreibt tor-browser#41945 in `001-base-profile.js` (über `fawkes-prefs.js`, das danach eingebunden wird).
2. **Heuristik** im neuen JSWindowActor `FawkesCookieBanner` für alle übrigen Banner und für bekannte Banner, die der Dienst nicht ablehnen kann.

### Ablauf je Banner

1. Ein Banner, das eine Regel des Dienstes ablehnt (Präsenz-Element sichtbar, Regel mit Ablehnen-Selektor), bekommt 2 s Vorrang (`fawkes.cookiebanners.ruleGraceMs`). Die Ablehnung durch den Dienst wird an einem vertrauenswürdigen Klick auf das Ablehnen-Ziel erkannt und gezählt.
2. **Ablehnen** („Alle ablehnen“, „Nur notwendige“, „Reject all“, „Refuser“, „Rifiuta“, „Rechazar“ … in rund 20 Sprachen).
3. **Pay or OK**: kein Ablehnen, aber Akzeptieren und ein Abo-Angebot (Abo-Button oder Text wie „werbefrei mit pur“, „ad-free“) → sofort akzeptieren, ohne die Einstellungen zu öffnen; Abo- und Login-Elemente werden nie angeklickt.
4. **Einstellungen**: Banner mit Schaltern und Speichern-Button → optionale Zwecke abwählen und speichern; sonst „Einstellungen/Anpassen/Optionen verwalten/Paramétrer“ öffnen, dort „Alle ablehnen“ oder alle optionalen Schalter aus + „Auswahl speichern/Confirm my choices“.
5. **Akzeptieren**, nur wenn keine Ablehnung möglich ist: mit dem Akzeptieren-Selektor einer passenden Regel, sonst per Text. Nach einem Ablehnen- oder Speichern-Klick wird auf der Seite nie mehr akzeptiert.
6. **Scroll-Sperren** (`overflow: hidden`/`clip` an `html`/`body`) lösen, auch im Top-Dokument, wenn das Banner in einem Frame war – nur eine Sperre, die die Seite während der Beobachtung hatte, und nicht, solange ein fixiertes Element die Seitenmitte großflächig verdeckt.

Das Menü zeigt am Schalter „– auf dieser Seite abgelehnt“ bzw. „– auf dieser Seite akzeptiert (keine Ablehnung möglich)“. Die Einstellungsseite erklärt den Ablauf im Abschnitt „Cookie-Banner“.

### Regeln offline aus dem Tree

- Der Dump `services/settings/dumps/main/cookie-banner-rules-list.json` **liegt im Tree** (558 Regeln, 1601 Domains, 9 globale CMP-Regeln: OneTrust, Cookiebot, Borlabs, Complianz, consentmanager, TrustArc, Didomi, Quantcast, Sourcepoint; Stand 05.09.2024) und wird nach `browser/defaults/settings/main/` gepackt.
- Tor Browser synchronisiert Remote Settings nie (`AppConstants.BASE_BROWSER_VERSION`: `sync()`/`pollChanges()` importieren nur lokale Dumps, `shouldSkipRemoteActivity`). `RemoteSettings("cookie-banner-rules-list").get()` liefert also den Dump, **ohne Netzabruf**. Externe Daten wurden nicht geholt.
- Hook in `CookieBannerListService.importAllRules()` → `FawkesCookieBannerRules.prepare()` (und bei einem „sync“-Ereignis kompletter Neuimport darüber):
  - `fawkes.cookiebanners.useRuleList` aus (Einstellungsseite) → keine Regeln (keine Regelklicks, keine Cookie-Injektion), nur Heuristik; wirkt sofort (`resetRules(true)`).
  - Eigene globale Regeln (nur Selektoren der plattformeigenen Buttons): Didomi und Sourcepoint mit Ablehnen-Button (die Dump-Regeln akzeptieren nur), neu iubenda, CookieYes, Klaro, Google Funding Choices, CookieFirst, Axeptio, Piwik PRO, Osano, Termly.
  - Klickregeln ohne Ablehnen-Selektor (302 Regeln, darunter die globalen Didomi/Quantcast/Sourcepoint) verlieren ihren Akzeptieren-Selektor; er bleibt als Hinweis für Schritt 5. Ergebnis gegen den echten Dump: 567 Regeln, 18 globale, keine Klickregel akzeptiert mehr ohne Ablehnen.
  - Cookie-Regeln unverändert (Opt-out-Cookies; bei 58 Regeln ohne Opt-out-Cookies Opt-in-Cookies, wie Modus 2 es vorsieht), mit den Origin-Attributen des Loads (First-Party-Isolation bleibt), als Sitzungs-Cookies.

### Pro Site

`nsCookieBannerService::GetDomainPref()` fragt zuerst `FawkesService::HandlesCookieBanners()`: Schalter aus → `MODE_DISABLED`. Darüber laufen Cookie-Injektion (`GetCookiesForURI`) und Klickregeln (`CookieBannerParent`). Die Heuristik fragt `Services.fawkes` für die Top-Level-Site; Frames anderer Sites folgen der Seite, in der sie stehen.

### Heuristik

- **Wo:** jedes http(s)-Frame von Browser-Tabs (`allFrames`), Dokument + offene und geschlossene Shadow-Roots (`openOrClosedShadowRoot`, auch verschachtelt) + `about:blank`/`about:srcdoc`-Iframes ohne eigenen Actor.
- **Wann:** ab `DOMContentLoaded`, nach jeder DOM-Änderung (MutationObserver auf Dokument und jeder Shadow-Root, höchstens alle 250 ms) und einmal pro Sekunde, bis 20 s nach `DOMContentLoaded` bzw. 5 s nach `load` (wie der Dienst); begonnene Prüfungen und Einstellungsdialoge verlängern die Frist; keine Scans im Back-Forward-Cache.
- **Was:** Textknoten mit Cookie-/Consent-Wörtern (von hinten, Shadow-Roots und Frames zuerst); im Top-Dokument das nächste fixed/sticky/modale Overlay mit z-Index ≥ 10, ≥ 15 % Viewport-Fläche oder ≥ 80 % Breite (nicht die ganze Seite: kein `main`/`article` darin); in Frames der nächste Container mit Akzeptieren/Ablehnen. Eine erste Ebene braucht Akzeptieren oder Ablehnen und einen Text-Score ≥ 2; reine Hinweise ohne Wahl ≥ 3 und ein echtes Cookie-Wort. Altersabfragen und (außerhalb geöffneter Einstellungen) Container mit Eingabefeldern sind nie Banner.
- **Sicherheit:** nie Abo/Kauf/Spende/Login/Registrierung; nie Links, die eine Seite laden (nur `#`/`javascript:` ohne fremdes `target`); „Mehr erfahren“ nur als `<button>` mit `aria-expanded`/`aria-controls`/`aria-haspopup`; nie Formulare an andere Sites; nie etwas außerhalb des Banners; Opt-out-Schalter („Do not sell“) bleiben an; jeder Button/Schalter höchstens einmal, max. 8 Klicks pro Seite, max. 5 behandelte Banner bzw. 20 Klicks pro Site und Sitzung (New Identity und das Ende der privaten Sitzung setzen zurück); jede Entscheidung bei `fawkes.debug` in der Browser-Konsole (Präfix `FawkesCookieBanner`).

## Entscheidungen ohne Rückfrage (bitte prüfen)

1. **Regeln aus dem vorhandenen Dump, keine externen Daten.** Abschnitt 5.9 verlangt, vor dem Holen externer Daten zu fragen. Das war nicht nötig: Der Dump liegt im Tree und wird gepackt, Tor Browser lädt Remote Settings nur aus lokalen Dumps. Der Dump ist vom 05.09.2024; neuere Regeln gäbe es nur aus dem Netz – bewusst nicht geholt. Fehlende CMPs decken eigene, handgeschriebene Regeln (nur eindeutige Selektoren) und die Heuristik ab.
2. **Modus 2, aber nie Akzeptieren vor Ablehnen.** Upstream klickt in Modus 2 den Akzeptieren-Selektor sofort, wenn eine Regel keinen Ablehnen-Selektor hat – bei 302 Klickregeln, darunter den globalen für Didomi, Quantcast und Sourcepoint, also auf jeder Seite mit diesen CMPs, auch wenn sie „Ablehnen“ anbieten. Das widerspräche dem Ablauf 1→2→3 aus 5.9. Deshalb entfernt `prepare()` bei solchen Regeln den Akzeptieren-Selektor und gibt ihn der Heuristik als Hinweis für Schritt 3. Der Dienst bleibt in Modus 2 (Cookie-Injektion unverändert).
3. **Tor-Browser-Vorgabe tor-browser#41945 überschrieben.** Tor Browser schaltet den Dienst aus (Fingerprinting-Bedenken). Der Auftrag verlangt ihn im Modus 2 mit Standard „an“. Das Risiko (eine Site sieht, dass Banner automatisch abgelehnt werden: Cookies schon beim ersten Request, synthetische Klicks, Inline-Stil der Scroll-Freigabe; alle FawkesWebXE-Nutzer mit Standardeinstellungen verhalten sich gleich, unterscheiden sich aber von Tor-Browser-Nutzern) ist in `cookie-banners.md` dokumentiert; der Schalter ist pro Site abschaltbar.
4. **Kein Cool-down der Regelklicks** (`cookiebanners.bannerClicking.maxTriesPerSiteAndSession = 0`, Befund der Code-Prüfung): Der Dienst zählt pro Site des *Frames*; ein auf vielen Sites eingebetteter Dritter könnte daran Aktivität auf anderen Sites erkennen. Fawkes begrenzt stattdessen pro Top-Level-Site.
5. **Upstream-Klickregeln bleiben aktiv, die Heuristik lässt ihnen 2 s Vorrang** und übernimmt danach (z. B. OneTrust ohne Ablehnen-Button → Einstellungen).
6. **Pro Site über einen C++-Hook in `GetDomainPref`.** Die eigenen Domain-Prefs des Dienstes sind im privaten Modus flüchtig. Ist der Schalter an, gilt wie bisher die (in Tor Browser ungesetzte) Domain-Pref des Dienstes, damit Upstream-Tests, die sie setzen, weiter funktionieren.
7. **„Pay or OK“ sofort akzeptieren.** Dort lässt sich in den Einstellungen nicht wirksam ablehnen; Speichern mit allem aus führt nur zur Bezahlschranke. Abo-/Login-Elemente werden nie angeklickt; das Menü zeigt „akzeptiert (keine Ablehnung möglich)“.
8. **Nach einem Ablehnen- oder Speichern-Klick kein Akzeptieren auf derselben Seite** (auch wenn das Banner über Tor langsam schließt; Befund der Code-Prüfung). Beim nächsten Seitenaufruf gilt wieder der normale Ablauf.
9. **Strengere Link-Regel als verlangt.** Verlangt ist „keine Links zu anderen Domains“. Fawkes klickt gar keine Links, die eine Seite laden (auch nicht dieselbe Seite neu), nur `#`-/`javascript:`-Links ohne fremdes `target`; „Mehr erfahren“ nur als Dialog-Button.
10. **Funktionale Cookies gelten als optional** und werden abgewählt (bei OneTrust & Co. sind sie optional). Als notwendig gelten „notwendig/essenziell/erforderlich/strictly/technisch“; deaktivierte Schalter werden nie berührt, Schalter, deren eigenes Label „widersprechen/Do not sell“ sagt, auch nicht.
11. **Grenzen gegen Schleifen:** max. 8 Klicks pro Seite, jeder Button/Schalter höchstens einmal, max. 5 Banner bzw. 20 Klicks pro Site und Sitzung (der Parent zählt Klicks schon vor dem Klick, damit auch neu ladende Klicks enden), Beobachtung wie beim Dienst. Alles per Pref einstellbar.
12. **Keine Regeln für unsichere Selektoren.** Usercentrics (Shadow DOM), Quantcast Choice (gleiche `mode`-Attribute für „Mehr Optionen“ und „Ablehnen“), Commanders Act und Ketch (wechselnde IDs) übernimmt die Heuristik. Ein falscher Ablehnen-Selektor, der einen Akzeptieren-Button trifft, wäre schlimmer als keine Regel.
13. **Menü-Status statt eigener Untermenüs.** Banner, die der Dienst per Cookie-Injektion erledigt, erscheinen gar nicht und werden daher nicht angezeigt.

## Geänderte Upstream-Dateien (dünne Hooks, für spätere Rebases)

| Datei | Änderung |
| --- | --- |
| `toolkit/components/cookiebanners/nsCookieBannerService.cpp` | `GetDomainPref()`: zuerst `FawkesService::HandlesCookieBanners()` (+ Include) |
| `toolkit/components/cookiebanners/CookieBannerListService.sys.mjs` | `importAllRules()`: Datensätze über `FawkesCookieBannerRules.prepare()`; `onSync()`: kompletter Neuimport (+ Lazy-Import) |
| `browser/components/DesktopActorRegistry.sys.mjs` | Registrierung des JSWindowActors `FawkesCookieBanner` |

Neuer Code: `toolkit/components/fawkes/FawkesCookieBannerRules.sys.mjs`, `FawkesCookieBannerHeuristics.sys.mjs`, `browser/components/fawkes/actors/FawkesCookieBanner{Parent,Child}.sys.mjs`; Erweiterungen in `FawkesService.{h,cpp}` (`HandlesCookieBanners`), `Fawkes.sys.mjs` (Menü-Status), `fawkes-prefs.js`, `fawkes.ftl` (en-US, de), `moz.build`-Dateien; Tests und Doku.

## Prüfungen ohne Build

- **Erste Code-Prüfung durch einen separaten Prüf-Agenten** (nur lesend, gegen den Tree und Searchfox ESR 153): **keine Build-Blocker** (Include, Namespace, Signaturen, `Modes`-Zuweisung, Unified Build; `GetDomainPref` läuft nur im Parent auf dem Main-Thread, die Assertions von `FawkesService::GetSingleton` halten), alle DOM-/Chrome-/Actor-APIs und XPConnect-Konvertierungen bestätigt, keine neuen Netzverbindungen. Gefunden: 9 wahrscheinliche Fehler, 12 kleinere Punkte – alle behoben (Commits 8 und 9), u. a.: Eskalation zu „Akzeptieren“ bei langsamem Schließen über Tor; Fristablauf brach Prüfungen ab; falscher Sichtbarkeitstest für leere Präsenz-Container; „Cookie-Einstellungen“-Widgets als Banner; Fehlklicks bei „OK/Ja/Weiter“ in Formularen und Altersabfragen; „Do not sell“-Schalter ausgeschaltet; neu ladende Klicks ohne Grenze; Trefferlimit auf Datenschutzseiten; seitenübergreifender Zustand über den Cool-down des Dienstes.
- **Zweite, fokussierte Prüfung** der Korrekturen und aller Testerwartungen (jede Testseite mit den echten Heuristik-Funktionen in Node nachgerechnet und durch den Actor-Code verfolgt): **keine Testerwartung, die fehlschlagen würde, keine API-Abweichung**; 6 weitere Punkte (einer mittel: `load` verkürzte die Frist laufender Einstellungsdialoge) und 3 Restpunkte – alle behoben (Commit 10).
- Eigene Durchsicht fand vorher: `Node.ownerGlobal` heißt in ESR 153 `documentGlobal` (ersetzt durch `ownerDocument.defaultView`), doppelter `observe`-Schlüssel im Parent, verpasste Regel-Klicks vor Eintreffen der Konfiguration, Race beim Schließen der Test-Tabs.
- **Regel-Import gegen den echten Dump** (Node mit `Services`-Attrappe): 567 Regeln, 18 globale, keine Klickregel akzeptiert ohne Ablehnen, 300 Klickregeln als Hinweise, Originaldatensätze unverändert.
- **Klassifizierung** (Node): 142 Button-Texte aus Testseiten und echten CMPs in rund 15 Sprachen ohne Fehlzuordnung; Texte, Zahlungsangebote, Altersabfragen, Opt-out-Schalter, notwendige Zwecke.
- `node --check` für alle geänderten JS-/MJS-Dateien und die Inline-Skripte der Testseiten; Testseiten auf korrekte Verschachtelung geprüft; `browser.toml`/`xpcshell.toml` mit `tomllib`, alle `head`/`support-files` existieren; Fluent (`fluent.syntax`): en-US und de je 136 Nachrichten, keine Fehler, gleiche Attribute.
- WebIDL, XPIDL, IPDL, Static Prefs, ErrorList: unverändert (die `cookiebanners.*`-Prefs existieren in `StaticPrefList.yaml`/`all.js`, nur ihre Standardwerte werden gesetzt).
- 80 Spalten in neuem Code (Ausnahme: lange `moz-src:///`-URLs wie im übrigen Registry-Code); keine `__pycache__`/`parser.out`-Reste.
- `./mach lint` nicht ausgeführt (braucht Bootstrap, Phase 12).

## Grenzen (auch in `cookie-banners.md`)

- Die Heuristik kann Banner übersehen: Banner im normalen Seitenfluss statt als Overlay, Banner in Canvas/Bildern, Texte ohne eines der bekannten Wörter, Buttons ohne Text oder zugänglichen Namen (nur Icons). Sie kann sich irren: ein „Einstellungen“-Button, der woandershin führt, unbeschriftete Schalter mit Widerspruchs-Bedeutung, ein fixiertes Overlay über Cookies, das kein Consent-Banner ist.
- Klicks sind vertrauenswürdige Events: Ein Button, dessen Skript ein Fenster öffnet oder eine Seite lädt, kann das tun (Links werden nie geklickt, die Klickgrenzen beenden Schleifen).
- Einstellungsdialoge mit mehreren Seiten oder Herstellerlisten werden nur so weit bearbeitet, wie die erste Seite Schalter zeigt; Widersprüche gegen „berechtigtes Interesse“ in Herstellerlisten werden nicht gesetzt.
- Cookie-Walls: Nach einer Ablehnung wird auf derselben Seite nichts akzeptiert; fragt die Site beim nächsten Aufruf erneut, wird neu entschieden.
- Regel-Selektoren passen zum heutigen Markup der Plattformen; ändert es sich, übernimmt nach der Wartezeit die Heuristik. Der Dump wird nie aktualisiert (keine Netzabrufe).
- Banner, die erst nach der Beobachtungszeit erscheinen (z. B. nach einem Klick des Nutzers), werden nicht behandelt.
- Andere Scroll-Sperren als `overflow` an `html`/`body` (z. B. ein fixierter, verschobener `body`) werden nicht gelöst; das Lösen setzt einen für die Seite sichtbaren Inline-Stil.
- Speichert eine CMP ihre Entscheidung nur in `localStorage` und ist `js.storage` an (Speicher pro Dokument), erscheint das Banner auf jeder Seite neu; nach 5 Bannern pro Site und Sitzung bleibt es stehen.
- Das Menü zeigt keine Banner, die der Dienst per Cookie-Injektion erledigt hat (dann erscheint keins).
- Testregeln aus `cookiebanners.listService.testRules` umgehen `prepare()` (nur für Tests relevant).
- Der Code ist (wie alle Phasen) nie kompiliert und nie ausgeführt worden; geprüft wurde von Hand, mit zwei Prüf-Agenten, Parsern und Node.

## Tests (geschrieben, laufen erst in Phase 12)

browser-chrome, `browser/components/fawkes/test/browser/cookiebanners/` (eigene `head.js`; das Seiten-Skript `file_cmp.js` protokolliert jeden Klick über `data-result`, Links und Formulare navigieren nie; `checkCmpPage` prüft Ergebnis, verbotene Klicks, die Meldung an den Parent für diesen Tab und dass die Seite wieder scrollt):

| Anforderung (Abschnitt 8) | Test |
| --- | --- |
| Testseite pro CMP-Typ | `browser_fawkes_cookiebanner_cmps.js` (mit Regelliste) und `browser_fawkes_cookiebanner_heuristics_only.js` (nur Heuristik): OneTrust (mit Ablehnen; ohne → Einstellungen, Schalter aus, „Confirm My Choices“), Cookiebot, Usercentrics (Shadow DOM), Didomi, Quantcast Choice (über „More options“ → „Reject all“), Sourcepoint (Cross-Site-Iframe), TrustArc, consentmanager.net, iubenda (it), Borlabs (de), Complianz, CookieYes, Klaro, Google Funding Choices, CookieFirst, Axeptio (fr), Commanders Act (fr), Piwik PRO, Osano, Termly, Ketch; dazu Regelliste (globale Regeln lehnen ab, keine Regel akzeptiert ohne Ablehnen, Domain-Regeln importiert, Opt-out-Cookie von duh.de injiziert bzw. bei Schalter aus nicht), ohne Regelliste keine Regeln und keine Cookies |
| „Pay or OK“ | `browser_fawkes_cookiebanner_payorok.js`: golem-artige Seite (nur „Zustimmen und weiter“ geklickt, nicht Abo/Login/Einstellungen/Datenschutz-Link, Meldung „accepted“ für den Tab), Sourcepoint-artiger PUR-Dialog im Iframe mit und ohne Regelliste |
| Schalter pro Site aus/an | `browser_fawkes_cookiebanner_switch.js`: aus → `getDomainPref` = `MODE_DISABLED`, OneTrust (Regel) und Usercentrics (Heuristik) bleiben unberührt; wieder an → abgelehnt; Standard aus + Override an; Frames folgen der Top-Level-Site; Limit pro Site und Sitzung inkl. Reset durch `resetSession()`; Menü zeigt „rejected“/„accepted“/„none“ |
| Shadow-Roots, Iframes | `browser_fawkes_cookiebanner_frames.js`: offene, geschlossene und verschachtelte Shadow-Roots (spät gerendert, Stylesheet im Shadow-Root), Cross-Site-Iframe mit verbleibender Scroll-Sperre der Seite (Fawkes löst sie), `about:srcdoc`-Iframe, Sourcepoint mit Regel |
| Sicherheitsregeln | `browser_fawkes_cookiebanner_safety.js`: Ablehnen nur als Links (fremde Site, leere URL) bzw. Formular an andere Site → nicht geklickt, Einstellungen + Speichern stattdessen, „Do not sell“ bleibt an; Login und Footer-„Cookie settings“ nie; Overlays ohne Consent (Newsletter, „cookie recipes“), Altersabfrage und Newsletter-Formular mit Cookie-Text unberührt; Hinweis ohne Wahl → „OK“; Klicklimit bei immer wiederkehrendem Banner (3), kein Akzeptieren nach Ablehnen; Schalter in der ersten Ebene (Checkboxen und `role=switch`) |
| Sprachen | `browser_fawkes_cookiebanner_languages.js`: de, en, fr, it, es, nl, pl, pt (Banner nach `load` eingefügt); Englisch mit `fpRandomize` |

xpcshell `toolkit/components/fawkes/test/xpcshell/test_fawkes_cookie_banners.js`: Button-Klassifizierung in vielen Sprachen (inkl. Grenzfälle wie „Do not consent“, „Auswahl akzeptieren“, „Nur essenzielle Cookies akzeptieren“), Texte (Score, Cookie-Wörter, Zahlungsangebot, Altersabfrage, Opt-out-Schalter, notwendige Zwecke), Regel-Import (Fawkes-Regeln, Ersetzen per ID, Akzeptieren-Selektor entfernt und als Hinweis behalten, Domain-Regel ersetzt globale, `runContext`), Regelliste aus, Hook in `GetDomainPref` (normal/privat, injizierte Cookies, andere Sites, IP-Host).

## Manuelle Prüf-Checkliste (Phase 12)

Vorher `fawkes.debug` an und die Browser-Konsole öffnen (Präfix `FawkesCookieBanner`).

1. **golem.de**: Banner („Pay or OK“ mit golem pur) wird akzeptiert, Abo/Login nicht angeklickt; Menü zeigt „akzeptiert (keine Ablehnung möglich)“; Seite scrollt.
2. **OneTrust-Site** (eine große Nachrichten- oder Shop-Site mit OneTrust): mit „Alle ablehnen“ → abgelehnt (Regel des Dienstes, Konsole „A rule … rejected“); ohne „Alle ablehnen“ in der ersten Ebene → Einstellungen, optionale Kategorien aus, „Meine Auswahl bestätigen“; Menü „abgelehnt“.
3. **Usercentrics-Site** (viele deutsche Firmen-/Behördenseiten): Banner im Shadow DOM wird mit „Ablehnen/Deny“ geschlossen.
4. Eine **Sourcepoint**-Site mit Ablehnen (englischsprachige News): Ablehnen im Iframe; eine Sourcepoint-Pay-or-OK-Site (z. B. spiegel.de, heise.de): akzeptiert.
5. Schalter für eine der Sites im Menü aus → neu laden → Banner bleibt, nichts wird geklickt, keine injizierten Cookies; wieder an → behandelt.
6. `about:preferences#fawkes` → „Eingebaute Regeln … verwenden“ aus → dieselben Sites werden nur mit der Heuristik behandelt.
7. New Identity → dieselben Sites zeigen ihr Banner wieder und es wird erneut behandelt.
8. Seiten ohne Banner (Wikipedia, eine Suchmaschine), PDF.js, Reader View, NoScript, about:-Seiten: keine Klicks.
9. Leistung: eine sehr große Seite (langer Wikipedia-Artikel, eine Cookie-Richtlinie mit Tabelle) lädt ohne spürbare Verzögerung; ein Banner am Ende einer Cookie-Richtlinie wird trotzdem gefunden.

## Anwendungsprobe

Index-Probe (temporärer Index, `git read-tree fawkes-base`, dann `git apply --cached` in Phasenreihenfolge; Skript `fawkes-tools/probe.sh`):

- Sammeldateien: `phase-01-branding.patch` bis `phase-09-cookie-banners.patch` bestehen `git apply --check` und ergeben den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`), `fawkes-phase-02` (`ded25fd99f13`), `fawkes-phase-03` (`aa18953cfa4f`), `fawkes-phase-04` (`dd9f9ead8e67`), `fawkes-phase-05` (`33768452f3ad`), `fawkes-phase-06` (`6d56d5b6daa0`), `fawkes-phase-07` (`2778b279eddb`), `fawkes-phase-08` (`3c07fd7ad1f2`) bzw. `fawkes-phase-09` (`cd5a108f697d`).
- Serien: alle Patches aus `phase-01-branding/` (6), `phase-02-framework/` (7), `phase-03-no-tor/` (8), `phase-04-network/` (9), `phase-05-js-apis/` (10), `phase-06-css/` (8), `phase-07-profiling/` (9), `phase-08-randomization/` (12) und `phase-09-cookie-banners/` (10) lassen sich anwenden und ergeben exakt den Tree von `fawkes-phase-09` (`cd5a108f697d`).
- **Ergebnis: grün.**

Die Probe mit `git am` im Prüf-Worktree entfällt weiterhin auf Ihren Wunsch (über sshfs zu langsam).

Phase 9 ändert tor-browser-build nicht.

## Hinweise für spätere Phasen

- **Phase 10** (Proxy-Kette): Phase 9 macht keine eigenen Netzverbindungen; die Heuristik klickt nur in Seiten. Injizierte Cookies tragen die Origin-Attribute des Loads. New Identity setzt die Zähler der Heuristik über `fawkes-session-reset` zurück.
- **Phase 12**: Standardmäßig aktiver Modus 2 und der Actor in jedem Frame können Upstream-Tests stören, die den Dienst als aus annehmen (die meisten Upstream-Cookie-Banner-Tests setzen die Modus-Prefs selbst). Neue Tests: `browser/components/fawkes/test/browser/cookiebanners/` (7 Dateien) und xpcshell `test_fawkes_cookie_banners.js`.
- **Umgebung:** Am 23.10.2026 um 18:20 wurde der Rechner neu gestartet und `/tmp` (alle Scratchpads mit den Prüf-Helfern) geleert. Die Helfer liegen jetzt dauerhaft in `/home/dh/.config/Claude/side-session-notes/local_9c379c81-7c97-4448-86eb-95ee0ce89a11/fawkes-tools/` (`fcommit.py`, `probe.sh`, `ftlcheck.py`, `sf.py`, `heur/check.mjs`). Die übrigen früheren Helfer (`idlcheck.py`, `spcheck.py`, `xpidlcheck.py`, `ipdlcheck.py`, `fakebc/`) sind verloren und müssen bei Bedarf neu geschrieben werden.
