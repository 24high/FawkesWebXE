# Phase 1 – Umbenennung in FawkesWebXE: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-00` = `72e858f6dffb`, Tag `fawkes-phase-01` = `65c5379ad36e`):

| Planschritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `cf9fd41dcd77` | Fawkes: Add FawkesWebXE branding |
| 2 | `2fb6b95abffb` | Fawkes: Use FawkesWebXE branding and disable the updater in mozconfigs |
| 3 | `14054ad5dd62` | Fawkes: Replace Tor Browser and Firefox product names in UI strings |
| 4 | `3301c8849343` | Fawkes: Replace Tor Browser logos with a FawkesWebXE placeholder |
| 5 | – | Updater-UI geprüft: kein Änderungsbedarf (siehe unten) |
| 6 | `a843d996b2fb` | Fawkes: Add branding check script and test |
| 8 (Teil) | `65c5379ad36e` | Fawkes: Generate placeholder graphics for tor-browser-build |

tor-browser-build (`/home/dh/1 Data/Data/tor-browser-build`, Branch `fawkes`, Basis `fawkes-base` = `tbb-16.0a14-build2` = `694c0c25609e`, Tag `fawkes-phase-01`):

| Commit | Inhalt |
| --- | --- |
| `4300c362` | Fawkes: Build Tor Browser as FawkesWebXE |
| `3dc19034` | Fawkes: Replace Tor Browser installer and disk image graphics |
| `615c3352` | Fawkes: Name the desktop packages and start scripts fawkeswebxe (nachträglich auf Wunsch, Tag `fawkes-phase-01` dort verschoben, Patches von tor-browser-build neu erzeugt) |

Schritt 5: Mit `--disable-updater` wird `toolkit/mozapps/update` gar nicht gebaut; alle Aufrufer (about-Dialog, about:preferences, BrowserGlue, Telemetrie) sind über `MOZ_UPDATER` abgesichert, die about:tor-Meldung „wurde aktualisiert“ hängt an `BASE_BROWSER_UPDATE` (jetzt aus), `application.ini` bekommt keinen `[AppUpdate]`-Abschnitt mehr. Die Release-Notes-/Update-URLs im Branding sind leer bzw. `about:blank`.

## Ersetzte Grafikdateien (Platzhalter, zum späteren Tausch)

Erzeugt mit `tools/fawkes/make-placeholder-icons.py` (nur Python-Standardbibliothek; ImageMagick, librsvg und Pillow sind auf dem Rechner nicht vorhanden). Quelle der Geometrie: `browser/branding/fawkeswebxe/fawkeswebxe-placeholder.svg`.

tor-browser, `browser/branding/fawkeswebxe/`:
- `default16.png`, `default22.png`, `default24.png`, `default32.png`, `default48.png`, `default64.png`, `default128.png`, `default256.png`
- `VisualElements_70.png`, `VisualElements_150.png`
- `firefox.ico`, `document.ico`, `document_pdf.ico`, `newtab.ico`, `newwindow.ico`, `pbmode.ico`
- `firefox.icns`, `document.icns`
- `content/about-logo.svg`, `content/about-logo-small.svg`, `content/about-logo.png`, `content/about-logo@2x.png`, `content/about-wordmark.svg`, `content/document_pdf.svg`
- neu: `fawkeswebxe-placeholder.svg`

tor-browser, außerhalb des Brandings:
- `browser/themes/shared/sidebar/tor-browser.svg` (Sidebar-Symbol „firefox“)

tor-browser-build:
- `projects/browser/windows-installer/torbrowser.ico`, `torbrowser-alpha.ico`, `torbrowser-nightly.ico`, `torbrowser-release.ico`
- `projects/common/dmg-root/TorBrowser.dmg/.VolumeIcon.icns`
- `projects/common/dmg-root/TorBrowser.dmg/.background/dmg-window_2x.png` (zeigte die Wortmarke „Tor Browser“)

Neutral angepasste Farben: `content/aboutDialog.css`, `firefox.VisualElementsManifest.xml`. Onion- und Circuit-Symbole sind unverändert.

## Verbleibende Vorkommen (Ausnahmeliste)

Die maschinenlesbare Fassung ist `tools/fawkes/branding-allowlist.txt`. Sie ist eine erste Version und wird in Phase 12 gegen den ersten vollständigen Build abgeglichen; erst dann sind alle Treffer in den Firefox-Dateien bekannt.

| Vorkommen | Begründung |
| --- | --- |
| User-Agent-Token `Firefox/<Version>`, UA-Vorlagen, `navigator.*` | Websites müssen weiter Firefox sehen (6.2). |
| `application.ini`/`platform.ini`: `Name=Firefox` | `MOZ_APP_BASENAME` bleibt Firefox (`Services.appinfo.name`, UA, Add-on-Kompatibilität). |
| URLs mit `Firefox`/`tor-browser` | Linkziele bleiben. |
| about:license, about:rights, about:credits | Lizenz- und Urheberrechtstexte. |
| `trademarkInfo` (about-Dialog) | Markenhinweis „Tor“ / „Firefox“ und Hinweis, dass FawkesWebXE mit keiner der Organisationen verbunden ist. |
| `about-dialog-tor-project-fawkes` | „FawkesWebXE is based on Tor Browser, which is developed by the Tor Project …“ – sachliche Herkunftsangabe. |
| `basebrowser-about-dialog-version-fawkes` | „… (based on Tor Browser and Mozilla Firefox <Version>)“. |
| `brandings.ftl` und Namen wie Firefox Relay/Monitor/Profiler/Color/Accounts/Sync | Andere Mozilla-Produkte/-Dienste. |
| about:addons: „a selection Mozilla recommends“, „Mozilla only recommends extensions …“ | Empfehlungsprogramm von Mozilla (war „Firefox“, jetzt Organisationsname). |
| `TorBrowser/Data`, `TorBrowser-Data` | Daten-/Profilpfade (interne Bezeichner). |
| Umfrage-Banner in `aboutTor.js` („Help us improve Tor Browser …“) | Inaktiv (`_startDate: null`), fragt nach Tor Browser und darf daher nicht umbenannt werden. |
| `default-bookmarks.ftl` (Firefox-Lesezeichen) | Werden von Tor Browsers `default-bookmarks.html` nicht verwendet. |
| Kommentare in FTL/Properties/JS/HTML | Nicht sichtbar; das Prüfskript ignoriert sie. |
| `module.ver`: `COPYRIGHT` „©Firefox and Mozilla Developers …“, `TRADEMARKS` | Urheberrechts-/Markenhinweis (COMPANYNAME ist jetzt FawkesWebXE). |
| Interne Bezeichner: Fensterklasse `Firefox-MediaKeys`, Dateinamen `firefox.ico`/`firefox.icns`/`firefox.VisualElementsManifest.xml`, Chrome-Pfad `sidebar/firefox.svg`, Toast-AUMID-Präfix `Fawkeswebxe…` (aus `MOZ_APP_NAME.title()`) | Keine Anzeigenamen. |
| Year-End-Campaign-Banner auf about:tor | Unverändert: enthält keinen Produktnamen, ist ein Spendenaufruf für Tor (bis 05.01.2027 aktiv). **Bitte entscheiden, ob er bleiben soll.** |

## Support-Links mit externen Zielen (nur Linktext angepasst)

- About-Dialog: `https://www.torproject.org/` (Tor Project), `https://donate.torproject.org/`, `https://community.torproject.org/`, `https://support.torproject.org/tor-browser` („Questions?“), `https://community.torproject.org/relay/`, Mozilla: `https://www.mozilla.org/about/legal/terms/firefox/`, `https://www.mozilla.org/privacy/firefox/`, `https://www.mozilla.org/`, `https://foundation.mozilla.org/`, `https://www.mozilla.org/contribute/`.
- Menü „FawkesWebXE Manual“ und Standard-Lesezeichen „FawkesWebXE Manual“: `about:manual` → Tor-Browser-Handbuch (tb-manual.torproject.org).
- Standard-Lesezeichen „Tor Project Bookmarks“ (Onion-Seiten des Tor Project, donate.torproject.org).
- Onion-Location „Learn more“: `https://tb-manual.torproject.org/<locale>/onion-services/`.
- Windows-Installer (Registry „Programme und Features“): `URL_ABOUT` torproject.org, `URL_UPDATE` Tor-Blog-Release-Notes, `URL_HELP` tb-manual.torproject.org.

## Offene Packaging-Punkte (tor-browser-build)

1. **Datei-/Archivnamen** (erledigt mit `615c3352`): neue Variable `var/package-name` (Standard `var/project-name`, für `torbrowser` = `fawkeswebxe`). Damit heißen die Pakete `fawkeswebxe-linux-x86_64-<version>.tar.xz`, `fawkeswebxe-macos-<version>.dmg` und `fawkeswebxe-windows-x86_64-portable-<version>.exe`, außerdem das Debug-Symbol-Archiv, der Linux-Hauptordner `fawkeswebxe/`, `start-fawkeswebxe`, `start-fawkeswebxe.desktop` und die Logdatei `fawkeswebxe.log`. Die Abnehmer der Dateinamen (linux-packages, macOS-Signing/-Notarisierung, MAR-Werkzeuge) sind angepasst. Weiter `tor-browser` heißen: interne rbm-Ausgabeverzeichnisse, Git-Tags, Android-Pakete, deb/rpm-Paketnamen (`pkg_name`), das Quellarchiv `src-firefox-tor-browser-*` und die Tor-CDN-Regeln (`.htaccess`, `check_file_counts`, `staticiforme-*`).
2. **macOS `.DS_Store`** (`alpha/nightly/release.DS_Store`) speichern die Symbolanordnung für „Tor Browser*.app“; mit `FawkesWebXE.app` fällt Finder auf das Standardlayout zurück. Neu erzeugen geht nur auf einem Mac.
3. **macOS-Bundle-ID**: tor-browser-build übergibt `--with-distribution-id=org.torproject`, daraus wird `org.torproject.fawkeswebxe`. Eigene ID gewünscht?
4. **Windows-Installer**: `PUBLISHER` ist jetzt FawkesWebXE; `COPYRIGHT_STRING` („© … The Tor Project“), `APP_DIR` (`TorProject`) und die URLs sind unverändert.
5. **Update-/MAR-Werkzeuge** (`projects/release`: Incrementals, Update-Responses, `dmg2mar`, `tools/dmg2mar` mit Standard „Tor Browser“, Signieren von MARs) sind mit abgeschaltetem Updater nicht mehr nutzbar und nicht angepasst.
6. **`projects/linux-packages`** (deb/rpm, standardmäßig aus) und **Android** sind nicht angepasst; das `torbrowser`-Target gilt auch für Android, dessen Branding (`mobile/android/branding`) unverändert ist.
7. **Docs**: `Bundle-Data/Docs-TBB/ChangeLog.txt` (Tor-Browser-Changelog) wird weiter mitgeliefert.
8. Alpha/Nightly/Release teilen sich Name und Branding „FawkesWebXE“ (bisher „Tor Browser Alpha“ usw.).
9. Ein In-Place-Update einer bestehenden Tor-Browser-Installation ist nicht vorgesehen (neuer Programmname); FawkesWebXE ist eine Neuinstallation.
10. `rbm showconf` konnte nicht laufen (Perl-Module wie YAML::XS fehlen, Installation bräuchte sudo); geprüft wurde nur das YAML von `rbm.conf`. Vollständige Prüfung in Phase 12.

Hinweis: tor-browser-build überstimmt per Kommandozeile/`mozconfig.in` `--with-branding` und `MOZ_APP_REMOTINGNAME`; deshalb wurden `projects/common/browser-localization` (Branding-Pfad) und `rbm.conf` (`Project_Name`, `display_name`, `exe_name`, `updater_enabled: 0`, `build_mar: 0`) angepasst.

## Hinweise zu den Übersetzungen (nicht en-US)

- **Markenname**: Jede Locale bekommt die en-US-Dateien `brand.ftl`/`brand.properties` (geändertes `locales/jar.mn`). Damit heißt der Browser in allen Sprachen FawkesWebXE, unabhängig von den Weblate-/Firefox-Übersetzungen. `trademarkInfo` ist dadurch in allen Sprachen englisch.
- **Neue Message-IDs**, damit alte Übersetzungen mit „Tor Browser“/„Firefox“ nicht greifen; bis zur Übersetzung erscheinen diese Texte auf Englisch:
  `menu-open-tor-manual-fawkes`, `appmenu-open-tor-manual-fawkes`, `default-bookmarks-tor-manual-fawkes` (neu), `tor-browser-home-tor-check-warning-fawkes`, `tor-browser-home-message-updated-fawkes`, `tor-browser-home-message-testing-fawkes`, `home-mode-choice-tor-fawkes`, `about-dialog-tor-project-fawkes`, `basebrowser-about-dialog-version-fawkes`, `discopane-intro3-fawkes`, `addon-badge-recommended4-fawkes`, `sync-engine-addons-fawkes`, `responsive.fawkes.remoteOnly`, `torConnect.fawkes.{noInternet, couldNotConnect, errorLocation, errorLocationDescription, isLocationCorrectDescription, finalError, restartTorBrowser}`, `settings.fawkes.torPreferencesDescription`.
- **Nicht lösbar ohne größeren Eingriff**: `appstrings.properties` (Netzwerk-Fehlertexte, z. B. „Firefox can’t find the file …“). Die Schlüssel leitet docshell (C++) aus den Fehlercodes ab, daher konnten sie nicht umbenannt werden. In en-US steht jetzt „FawkesWebXE“; die Firefox-Übersetzungen anderer Sprachen enthalten weiter „Firefox“.
- Das Prüfskript sucht nur nach „Tor Browser“, „TorBrowser“, „Tor-Browser“ und „Firefox“. Lokalisierte Formen wie „Navegador Tor“ oder „navigateur Tor“ findet es nur mit `--pattern`. Der Scan in Phase 12 zeigt, welche Übersetzungen den Namen wörtlich statt über den Brand-Term enthalten.

## Prüfungen ohne Build

- `py_compile` für beide Python-Werkzeuge.
- Selbsttest von `check-branding.py` gegen eine Fixture: normales ZIP und eine mit `mozpack` erzeugte optimierte `omni.ja` (Pythons `zipfile` scheitert daran, der eigene Leser nicht). Kommentare werden übersprungen, Ausnahmen und unerklärte Treffer korrekt erkannt, Exit-Code 1.
- `node --check` für alle geänderten JS/MJS-Dateien und den Mochitest; `fluent.syntax` (aus dem Tree) für alle geänderten FTL-Dateien: keine Fehler; TOML-Manifeste geparst.
- Grafiken visuell geprüft; ICO-/ICNS-Struktur validiert.
- `./mach lint` lief nicht: es würde zuerst Virtualenvs in `~/.mozbuild` und ESLint-`node_modules` anlegen (Bootstrap mit Netzzugriff). Das kommt in Phase 12.
- Mochitest und `check-branding.py` gegen einen echten Build: erst in Phase 12.

## Anwendungsprobe

- Index-Probe (temporärer Index, `git apply --cached`): Die Serie auf `fawkes-base` ergibt exakt den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`). Die Sammeldatei besteht `git apply --check` und ergibt denselben Tree. Für tor-browser-build gilt dasselbe (nach `615c3352`: `227386391ad8`).
- Prüf-Worktree `../fawkes-patchcheck` (auf `fawkes-base`): `git apply --check phase-01-branding.patch` OK; `git am phase-01-branding/*.patch` wendet alle 6 Patches an, HEAD-Tree = `fawkes-phase-01`-Tree (`fe16f9c6b5c4`), `git diff fawkes-phase-01` ist leer. **Ergebnis: grün.** Der Worktree steht jetzt auf dem `git am`-Ergebnis und wird in der nächsten Phase wieder auf `fawkes-base` zurückgesetzt.
