# Phase 2 – Fawkes-Grundgerüst: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-01` = `65c5379ad36e`, Tag `fawkes-phase-02` = `5247016d6cb9`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `2f86126862ed` | Fawkes: Add the switch table and FawkesService |
| 2 | `69fbc3914f74` | Fawkes: Persist the per-site settings in fawkes-sites.json |
| 3 | `442e4bbedd4e` | Fawkes: Transport the Fawkes flags to documents, workers and worklets |
| 4 | `36b2e80cb775` | Fawkes: Add the Fawkes strings in English and German |
| 5 | `6456c07d33a2` | Fawkes: Add the Fawkes toolbar button and site menu |
| 6 | `408ae094364a` | Fawkes: Add the Fawkes settings page |
| 7 | `5247016d6cb9` | Fawkes: Document the switches, the flag transport and the storage |

Plan: `/home/dh/.claude/plans/squishy-questing-curry.md` (freigegeben am 22.10.2026).

## Was jetzt da ist

- **Schaltertabelle** `toolkit/components/fawkes/FawkesSwitches.inc`: 34 Schalter. Jeder hat eine stabile ID, eine Gruppe, einen eingebauten Standardwert und ein Bit im 64-Bit-Feld. Jedes Bit bedeutet „Maßnahme aktiv“, Flags = 0 blockiert nichts. Daraus entstehen `FawkesSwitches.h` (C++) und das generierte `FawkesSwitches.sys.mjs` (JS). Die Tabelle mit APIs, geplantem Mechanismus und Bruchrisiko steht in `browser/components/fawkes/docs/categories.md`.
- **Dienst** `Services.fawkes` (`FawkesService`, C++, nur im Parent): Standardwerte und Overrides pro Site.
  - **Site-Schlüssel:** eTLD+1 der Top-Level-Seite, bei IPs und `localhost` der Host. Berechnet wird er wie der Storage-Partition-Key von Firefox, deshalb erben Iframes, Worker und Subressourcen die Top-Level-Site automatisch über den Partition-Key ihrer CookieJarSettings.
- **Persistenz** `fawkes-sites.json` (`FawkesStore.sys.mjs`, über `JSONFile`/`IOUtils`, atomar, mit Schema-Version):
  - Gespeichert werden nur abweichende Standardwerte und nur Sites mit Overrides, jeweils über die Schalter-ID.
  - Gelesen wird asynchron bei `profile-after-change`. Braucht der Dienst die Werte früher, liest er synchron, damit keine Seite mit falschen Einstellungen lädt.
- **Flag-Transport** (verifiziert am RFP-Override-Pfad):
  - Der Parent berechnet die Flags für jeden Channel in `AntiTrackingUtils::UpdateAntiTrackingInfoForChannel` und setzt sie immer, auch auf 0.
  - Weitergegeben werden sie über `LoadInfo`, `LoadInfoArgs` und `ParentLoadInfoForwarderArgs`, dann landen sie am `Document`, und zwar vor dem ersten Skript.
  - Dedicated und verschachtelte Worker übernehmen sie vom Dokument bzw. vom Eltern-Worker, SharedWorker über `RemoteWorkerData`, ServiceWorker vom Parent, Worklets vom Dokument.
  - Abfragen laufen über `nsIGlobalObject::FawkesFlags()`.
  - Ausgenommen (Flags = 0): System-Principal, Erweiterungen, `about:`, `chrome:`, `resource:` (PDF.js), `file:`, Content-Script-Sandboxes und der Worker-Debugger.
- **Toolbar-Button** neben dem Security-Level-Button, mit vollständigem Menü nach Abschnitt 4 des Auftrags:
  - Untermenüs für JS, CSS und Verhaltens-Profiling (mit „Alle“) sowie für die Proxy-Kette.
  - Zurücksetzen, „als Standard übernehmen“ und Link zu den Einstellungen.
  - Der Badge-Punkt zeigt eigene Einstellungen der Seite an.
  - Nach einer Änderung lädt der Tab beim Schließen des Menüs neu (abschaltbar).
  - Bestehende Profile bekommen den Button über einen eigenen Migrationsschritt in CustomizableUI.
  - **Die Schalter werden gespeichert und übertragen, haben aber noch keine Wirkung** (das kommt ab Phase 3).
- **Einstellungsseite** `about:preferences#fawkes`, config-basiert, weil das Settings-Redesign in ESR 153 standardmäßig an ist und klassische Panes dort nicht rendern. Inhalt:
  - Standardwerte aller Schalter, Seitenliste mit Einzel- und Komplettlöschung.
  - Googlebot-UA (aktuell/klassisch/eigener), Referer-Modus.
  - Proxy-Liste, Latenz-Schwelle und Fallback-Option.
  - Eigene blockierte Domains (FawkesWeb `BlockedDomains`, laut Ihrer Entscheidung).
  - Eigene JS-/CSS-Muster.
  - CMP-Liste ein/aus, automatisches Neuladen, Debug-Ausgabe.
- **Strings:** `browser/fawkes.ftl` auf Englisch und Deutsch (92 Nachrichten). Paketiert wird über `browser/locales/jar.mn`: de bekommt die deutsche Datei, jede andere Sprache die englische. tor-browser-build muss dafür nicht geändert werden.

## Abweichungen vom Auftrag (bitte prüfen)

1. **JSON speichert Schalter-IDs statt Hex-Bitfeldern** (Beispiel in 3.2: `"jsCategories": "0x…"`). Die Bits sind ein internes Transportdetail und dürfen sich ändern. Die IDs bleiben stabil, die Datei bleibt lesbar und migrierbar.
2. **Unter `defaults` stehen nur Abweichungen vom eingebauten Standard.** Ändert sich ein eingebauter Standard in einer neuen Version, greift er bei allen Nutzern, die ihn nicht selbst geändert haben.
3. **Ändern eines Standardwerts entfernt Overrides, die ihm nun gleichen.** So stehen wirklich nur abweichende Sites in der Datei (3.2).
4. **Einstellungsseite:** Die Abschnitte für den Tor-Schalter (mit „Tor automatisch neu verbinden“, laut Ihrer Entscheidung), den Adblock-Status und den Proxy-Scraper kommen in den Phasen 3, 4 und 11. Sie hängen an Diensten, die es noch nicht gibt.
5. **Menü-Platzhalter bis zur zuständigen Phase:**
   - Die Verbindungszeile zeigt fest „über Tor“ (dynamisch ab Phase 3).
   - Der Adblock-Zähler fehlt (Phase 4).
   - „Neuen Proxy wählen“ ist deaktiviert (Phase 10).
6. **Googlebot-UA:** Der Standard ist `… Chrome/155.0.0.0 …`. Die Version ist eine Hochrechnung für Oktober 2026 (Chrome stellt ab September 2026 auf zwei Wochen um; öffentliche Kalender nennen 153–156 für September/Oktober). Bitte in Phase 4 oder beim Test gegen die tatsächliche Version prüfen; der Wert ist in den Einstellungen änderbar.
7. **Nicht übernommen aus FawkesWeb:**
   - `CookieAllowList`: widerspricht dem Löschen aller Cookies am Sitzungsende.
   - KI, RSS, Kalender, IMAP, Vorlesen: haben nichts mit Datenschutz zu tun.

## Geänderte Upstream-Dateien (dünne Hooks, für spätere Rebases)

| Datei | Änderung |
| --- | --- |
| `netwerk/base/nsILoadInfo.idl`, `netwerk/base/LoadInfo.h` | Attribut `fawkesFlags`; eine Zeile im Makro `LOADINFO_FOR_EACH_FIELD` (deckt Member, Kopien, IPC-Konstruktor und TRRLoadInfo ab) |
| `netwerk/ipc/NeckoChannelParams.ipdlh`, `ipc/glue/BackgroundUtils.cpp` | Feld in `LoadInfoArgs` und `ParentLoadInfoForwarderArgs`, Serialisierung |
| `toolkit/components/antitracking/AntiTrackingUtils.cpp` | Berechnung im Parent (eine Zeile plus Include) |
| `dom/base/Document.{h,cpp}` | Member und Getter, Berechnung in `RecomputeResistFingerprinting`, Kopie in `CloneDocHelper` |
| `dom/base/nsIGlobalObject.{h,cpp}`, `dom/base/nsGlobalWindowInner.{h,cpp}` | virtuelles `FawkesFlags()`, Testzugang |
| `dom/workers/WorkerLoadInfo.h`, `WorkerPrivate.{h,cpp}`, `WorkerScope.{h,cpp}` | Übernahme von Dokument bzw. Eltern-Worker |
| `dom/workers/remoteworkers/RemoteWorkerTypes.ipdlh`, `RemoteWorkerChild.cpp`, `dom/workers/sharedworkers/SharedWorker.cpp`, `dom/serviceworkers/ServiceWorkerPrivate.cpp` | SharedWorker und ServiceWorker |
| `dom/worklet/WorkletImpl.{h,cpp}`, `WorkletGlobalScope.{h,cpp}` | Worklets |
| `dom/webidl/WindowOrWorkerGlobalScope.webidl` | `fawkesFlagsForTesting()` (nur mit `fawkes.testing.enabled`) |
| `modules/libpref/init/StaticPrefList.yaml`, `modules/libpref/moz.build` | Static-Pref-Gruppe `fawkes` |
| `toolkit/components/moz.build` | DIRS `fawkes` |
| `browser/components/customizableui/CustomizableUI.sys.mjs` | Standardplatzierung neben `security-level-button`, Migrationszähler `kVersionFawkes` |
| `browser/base/content/navigator-toolbox.inc.xhtml`, `browser/base/content/browser.xhtml` | Button-Markup, CSS- und FTL-Link |
| `browser/components/BrowserComponents.manifest` | Init/Uninit pro Fenster |
| `browser/components/preferences/preferences.{js,xhtml}` | Pane `fawkes`, Nav-Button, FTL-Link, Widget-Skript |
| `browser/locales/jar.mn` | `browser/fawkes.ftl` (de oder en-US) |
| `browser/app/profile/000-tor-browser.js` | `#include` der Fawkes-Prefs |

Neuer Code: `toolkit/components/fawkes/` und `browser/components/fawkes/`.

## Tests (geschrieben, laufen erst in Phase 12)

- xpcshell `toolkit/components/fawkes/test/xpcshell/`:
  - `test_fawkes_service.js`: Schaltertabelle, Override-Semantik, Bereinigung, Notifications, ungültige Argumente, Site-Schlüssel für IPv4, IPv6, `localhost`, einteilige Hosts, `.onion`, IDN, `about:`, `file:`, `view-source:`, `data:`, `moz-extension:`; außerdem synchrones Laden der Datei bei der ersten Abfrage.
  - `test_fawkes_store.js`: keine Datei ohne Änderungen, Round-Trip, synchrones Laden, Migration, kaputte Datei.
- browser-chrome `browser/components/fawkes/test/browser/`:
  - `browser_fawkes_flags_transport.js`: Dokument, Dedicated, verschachtelter, Blob- und Shared-Worker, Cross-Site-, `about:blank`-, `srcdoc`- und Sandbox-Iframe, Worker im Cross-Site-Iframe, `about:blank`-Popup, Seite ohne Overrides, `about:`-Seite (0), neue Flags erst nach dem Neuladen.
  - `browser_fawkes_button.js`: Platzierung, vollständiges Menü, Umschalten mit Persistenz über eine simulierte Neuinitialisierung, Neuladen an/aus, invertierter WebRTC-Schalter, „Alle“-Profiling, Zurücksetzen, als Standard übernehmen, Badge, inaktiv auf `about:`-Seiten.
  - `browser_fawkes_preferences.js`: Pane, Standardwerte, Seitenliste, Googlebot-Presets.

## Prüfungen ohne Build

- XPIDL-Parser aus dem Tree auf `nsIFawkesService.idl` und `nsILoadInfo.idl`, Header erzeugt: Die Signaturen passen zur Implementierung bzw. zu den LoadInfo-Makros.
- IPDL-Parser und -Typprüfung für `NeckoChannelParams.ipdlh` und `RemoteWorkerTypes.ipdlh`: OK. Die Reihenfolge der Felder in allen positionalen Konstruktoraufrufen (LoadInfoArgs, ParentLoadInfoForwarderArgs, zweimal RemoteWorkerData) ist von Hand geprüft.
- WebIDL-Parser auf `WindowOrWorkerGlobalScope.webidl`: OK.
- Generator der Static-Prefs auf `StaticPrefList.yaml`: OK, erzeugt die Gruppe `fawkes`.
- `FawkesSwitches.h` mit g++ (C++20, `-fsyntax-only -Wall`) kompiliert, die Standardmaske stimmt.
- Generator `extract_fawkes_switches.py`: erzeugt 34 Schalter, 16 davon standardmäßig an, und lädt in Node.
- `fluent.syntax` aus dem Tree: beide FTL-Dateien ohne Fehler, gleiche IDs und Attribute; jeder Schalter hat ein Label.
- `browser/locales/jar.mn` mit dem mozbuild-Präprozessor für de, en-US und fr: richtige Quelle.
- `node --check` für alle neuen bzw. geänderten JS/MJS-Dateien.
- `./mach lint` lief wie in Phase 1 nicht (es bräuchte Bootstrap mit Netz). Kommt in Phase 12.
- Bei der Selbstprüfung gefunden und vor dem Commit behoben: fehlendes `#include "mozilla/BasePrincipal.h"` in `FawkesService.cpp` (im Unified Build nur zufällig verdeckt).

## Bekannte Grenzen

- Ein gleichherkünftiges Popup erbt die Flags seines Openers. Ändern sich die Einstellungen, während beide offen sind, bekommt das Popup die neuen Flags erst, wenn auch der Opener neu geladen wurde.
- Für Member des `Window`-Globals selbst werden `[Func]`-Prüfungen beim Erzeugen des Inner-Window ausgewertet, also bevor es sein Dokument hat. `FawkesFlags()` greift dann auf das Dokument des Outer-Window zurück. Das ist ab Phase 5 zu beachten.

## Hinweis zur Arbeitsweise mit git über sshfs

`git commit`, `git diff` und `git status` gleichen den ganzen Index (~400.000 Dateien) über sshfs ab und brauchen jeweils mehr als 30 Minuten. Die Commits dieser Phase sind deshalb mit Plumbing entstanden (`hash-object`, `update-index --index-info`, `write-tree`, `commit-tree`, `update-ref`). Das ergibt identische Commits, braucht aber keinen Stat-Durchlauf.

## Anwendungsprobe

Index-Probe (temporärer Index, `git read-tree fawkes-base`, dann `git apply --cached` in Phasenreihenfolge):

- Sammeldateien: `phase-01-branding.patch` und `phase-02-framework.patch` bestehen `git apply --check` und ergeben den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`) bzw. `fawkes-phase-02` (`ded25fd99f13`).
- Serien: alle Patches aus `phase-01-branding/` und `phase-02-framework/` lassen sich anwenden und ergeben exakt den Tree von `fawkes-phase-02` (`ded25fd99f13`).
- **Ergebnis: grün.**

Die Probe mit `git am` im Prüf-Worktree `../fawkes-patchcheck` entfällt ab dieser Phase auf Ihren Wunsch (über sshfs dauert sie wegen des Index-Abgleichs bis zu einer Stunde). Ein bereits gestarteter Durchgang wurde zu Beginn von `git reset --hard` abgebrochen. Der Prüf-Worktree ist danach in einem undefinierten Zustand und wird nicht mehr verwendet; Sie können ihn mit `git worktree remove --force ../fawkes-patchcheck` entfernen.

Phase 2 ändert tor-browser-build nicht.
