# Phase 3 – Betrieb ohne Tor: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-02` = `5247016d6cb9`, Tag `fawkes-phase-03` = `35616030d641`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `91aa96f53a3e` | Fawkes: Add the strings for running without Tor |
| 2 | `dc72ab3a0ea6` | Fawkes: Run without Tor when the Tor network is turned off |
| 3 | `620d5fbda31d` | Fawkes: Block .onion addresses without Tor |
| 4 | `b800c8c574bb` | Fawkes: Switch between Tor and a direct connection with a restart |
| 5 | `9240390f4856` | Fawkes: Warn without Tor and hide the Tor-only UI |
| 6 | `be66e590e815` | Fawkes: Reconnect to Tor automatically |
| 7 | `ca3e7e1bd054` | Fawkes: Test running without Tor |
| 8 | `35616030d641` | Fawkes: Document running without Tor |

Patches: `fawkes-patches/phase-03-no-tor/` (8 Dateien) und `fawkes-patches/phase-03-no-tor.patch`.
Plan: `/home/dh/.claude/plans/fawkes-phase-03.md` (ohne Rückfrage umgesetzt, wie vereinbart).
Ausführliche technische Doku: `browser/components/fawkes/docs/tor-mode.md`.

## Was jetzt da ist

- **Schalter** `fawkes.tor.enabled` (Standard an), gelesen einmal pro Sitzung in `FawkesTorMode.sys.mjs`. Umgebungsvariablen, die Tor konfigurieren (`TOR_PROVIDER=tor|none`, `TOR_SKIP_LAUNCH`, `TOR_TRANSPROXY`, `TOR_SOCKS_*`, `TOR_CONTROL_*`), halten Tor an; die Einstellungsseite sagt das dann.
- **Ohne Tor** startet kein `tor`-Prozess, es gibt keinen Control-Port, kein about:torconnect vor dem Surfen und keine Tor-Verbindungseinstellungen. Statt des Tor-Providers läuft `FawkesDirectProvider` (ein `TorProviderNone`, `build()` gibt ihn nicht heraus). Er setzt die Direktverbindung: Flag `fawkes.tor.directModeActive`, `.onion`-DNS-Sperre, kein DNS-Prefetch, DoH nach Wahl, lokales DNS an, zuletzt Proxy aus. Alles nur auf dem Default-Branch und gesperrt, nichts in `prefs.js`.
- **Umschalten** in `about:preferences#fawkes` (Gruppe „Tor-Netzwerk“: Status, „Tor-Netzwerk verwenden“, „Tor automatisch neu verbinden“; Gruppe „DNS ohne Tor“) oder nach einem Verbindungsfehler mit „Ohne Tor fortfahren…“ auf about:torconnect. Ablauf: Dialog → Neustart-Anfrage (kann verweigert werden) → Sitzung löschen wie „Neue Identität“ (alle Tabs zu, Cookies, Caches, Website-Daten usw.) → Einstellung speichern → Neustart.
- **`.onion` ohne Tor**: `nsHttpChannel::AsyncOpen` bricht mit dem neuen Fehler `NS_ERROR_FAWKES_ONION_WITHOUT_TOR` ab, bevor Proxy oder DNS gefragt werden; der DNS-Dienst lehnt `.onion` zusätzlich in jeder Schreibweise ab (Groß-/Kleinschreibung, Punkte am Ende, IDN-Formen). Fehlerseite „Diese .onion-Website braucht Tor“ ohne „Nochmal versuchen“. Onion-Location und die Onion-Suche auf about:tor sind aus.
- **Warnhinweis**, dauerhaft: „Ohne Tor“ mit Warnsymbol in der Adressleiste (Tooltip „Ohne Tor – deine IP-Adresse ist für Websites sichtbar“, Klick öffnet die Fawkes-Einstellungen), „!“ am Fawkes-Button, Menüzeile „Verbindung: OHNE TOR – deine IP-Adresse ist für Websites sichtbar“, gelber Kasten mit dem vollen Satz auf about:tor, Warnung in den Einstellungen.
- **Tor-UI aus**: „Neuer Tor-Kanal für diese Seite“ (Menü, App-Menü, Toolbar-Button, Strg+Umschalt+L) ausgeblendet bzw. deaktiviert; Circuit-Anzeige, Connect-Button und Brücken-Einstellungen blenden sich bei deaktiviertem TorConnect ohnehin aus.
- **Bleibt aktiv**: RFP, Sicherheitsstufe, First-Party-Isolation, alle Fawkes-Funktionen, „Neue Identität“ (ohne Circuit-Wechsel).
- **„Tor automatisch neu verbinden“** (FawkesWeb `TorReconnect`): `FawkesTorReconnect.sys.mjs` startet tor nach einem Absturz neu und verbindet erneut, nur im Tor-Modus und nur nach einer erfolgreichen Verbindung in dieser Sitzung.

## Entscheidungen ohne Rückfrage (bitte prüfen)

1. **Umgebungsvariablen überschreiben nur Richtung Tor.** Die bestehenden Variablen bedeuten „Tor anders erreichen“ (externes tor, Transparent-Proxy), nicht „ohne Tor“. Ist eine gesetzt, bleibt Tor an, auch wenn `fawkes.tor.enabled` aus ist. Keine Variable schaltet Tor ab: Das bleibt eine ausdrückliche Nutzerwahl mit Dialog. `TOR_PROVIDER=mock` (nur der Testharness) zählt nicht.
2. **Direktbetrieb nur im Speicher.** Die Proxy- und DNS-Werte stehen auf dem Default-Branch und sind gesperrt, statt sie als Nutzerwerte zu schreiben (so wie `TOR_TRANSPROXY` es tut). Folgen: Die nächste Tor-Sitzung muss nichts zurücksetzen, ein Absturz hinterlässt keinen Direkt-Zustand, und bis der Provider läuft, zeigt der Browser noch auf den (leeren) Tor-SOCKS-Port – fail closed. Netzwerk-Prefs, die eine Unternehmensrichtlinie sperrt, bleiben unangetastet.
3. **Ort des Schalters**: in `about:preferences#fawkes`, nicht in den Tor-Verbindungseinstellungen. Diese sind ohne Tor ausgeblendet, man käme also nicht zurück.
4. **Dialog**: Beim Verlassen von Tor ist „Abbrechen“ der Standardknopf. Die Sitzung wird vor dem Speichern der Wahl gelöscht; scheitert etwas vorher, bleibt der alte Modus. Verweigert ein anderer Teil des Browsers den Neustart (z. B. laufende Downloads), passiert nichts. Alle Tabs werden geschlossen, auch wenn `browser.new_identity.close_newnym` aus ist. Ein Ändern von `fawkes.tor.enabled` direkt in about:config wirkt beim nächsten Start ohne Löschen – ausdrückliche Nutzerwahl, dokumentiert.
5. **about:torconnect** zeigt „Ohne Tor fortfahren…“ nur, nachdem das Verbinden fehlgeschlagen ist (Fehler-Stages, Offline, tor gestoppt), nie während des Verbindens und nicht beim ersten Start. Ein einziges Element, das zum selben Dialog führt.
6. **Warnhinweis**: In der Adressleiste steht kurz „Ohne Tor“ (der volle Satz würde die URL verdrängen), der volle Satz steht im Tooltip, im Fawkes-Menü, auf about:tor und in den Einstellungen. Der Hinweis in der Adressleiste verschwindet wie der Tor-Connect-Button nur während des Tippens. Das Zeichen „⚠“ aus Abschnitt 4 des Auftrags habe ich nicht in Strings übernommen (der Style Guide verbietet Emoji); stattdessen das Warnsymbol `warning.svg`.
7. **Wortlaut**: „deine IP-Adresse“ wörtlich aus dem Auftrag. Die übrigen deutschen Fawkes-Texte nutzen wie Firefox die Sie-Form; die Texte rund um den Warnsatz sind unpersönlich formuliert. Bei Bedarf in `browser/components/fawkes/locales/de/fawkes.ftl` anpassen.
8. **`.onion`-Sperre zweistufig**: Kanal (für die verständliche Fehlerseite) und DNS-Dienst (für alles andere: Spekulative Verbindungen, WebSocket-Admission, Erweiterungen). Die DNS-Härtung gilt auch mit Tor; dort ist DNS ohnehin aus, sie ändert also nichts außer, dass sie strenger ist.
9. **Neues Fehlermodul `FAWKES` (49)** in `ErrorList.py` statt eines weiteren Codes im Tor-Modul. Phase 4 (Adblock-Fehlerseite) und Phase 10 (Proxy-Kette fail closed) können dort weitere Codes anlegen; Docshell zeigt Fehler dieses Moduls schon für alle Frames.
10. **DoH**: Modi „System“, „DoH mit Rückfall“, „nur DoH“; Standard System, kein voreingestellter Anbieter, nur `https://`. „Nur DoH“ ohne gültige Adresse löst nichts auf (fail closed); „mit Rückfall“ ohne gültige Adresse = System. Änderungen wirken nach einem Neustart (ein Live-Wechsel hätte die Sperren kurz lösen müssen).
11. **HTTP/3 und WebRTC** bleiben auch ohne Tor global aus, bis die Schalter pro Seite existieren (Phase 4 bzw. 5). Sonst liefe bis dahin auf jeder Seite HTTP/3, obwohl „HTTP/3 blockieren“ standardmäßig an ist.
12. **„Tor automatisch neu verbinden“**: Standard aus (wie in FawkesWeb). Was TorConnect schon kann, habe ich nicht doppelt gebaut: Quickstart verbindet beim Start, tor baut Circuits nach Netzausfällen selbst neu. Neu ist nur die Erholung, wenn tor nach einer bestehenden Verbindung stoppt: Neustart von tor, normaler Bootstrap mit den aktuellen Einstellungen, Wiederholungen nach 5 s, 30 s und 2 min, dann Aufgeben. Keine Connection Assist (die würde die Brückenverteilung kontaktieren), Abbruch durch den Nutzer wird respektiert, nie ein Wechsel in den Direktbetrieb, nie eine Änderung an Proxy oder Brücken.
13. **Testharness**: `testing/mochitest/runtests.py` wartet vor jedem Manifest auf einen Tor-Bootstrap; bei deaktiviertem TorConnect hinge das. Der Harness überspringt das jetzt in diesem Fall (Testcode, kein Produktcode).

## Geänderte Upstream-Dateien (dünne Hooks, für spätere Rebases)

| Datei | Änderung |
| --- | --- |
| `toolkit/components/tor-launcher/TorProviderBuilder.sys.mjs` | `providerType` ohne Tor = `none`; `none` ohne Tor = `FawkesDirectProvider` |
| `toolkit/components/tor-launcher/TorLauncherUtil.sys.mjs` | `_getShouldStartAndOwnTor()` ohne Tor = false |
| `toolkit/components/tor-launcher/TorDomainIsolator.sys.mjs` | Proxyfilter und `newnym` ohne Tor übersprungen |
| `modules/libpref/init/StaticPrefList.yaml` | `fawkes.tor.directModeActive` |
| `xpcom/base/ErrorList.py`, `js/xpconnect/src/xpc.msg` | Modul `FAWKES` (49), `NS_ERROR_FAWKES_ONION_WITHOUT_TOR` |
| `netwerk/protocol/http/nsHttpChannel.cpp` | `.onion`-Prüfung in `AsyncOpen` nach `NS_CheckPortSafety` |
| `netwerk/dns/nsDNSService2.cpp` | robuste `.onion`-Prüfung in `PreprocessHostname` (vor und nach IDN) |
| `docshell/base/nsDocShell.cpp` | Fehlerschlüssel `fawkesOnionWithoutTor`, Modul `FAWKES` in der Fehlerseiten-Liste |
| `toolkit/content/aboutNetError.{mjs,html}` | `initFawkesError()`, FTL-Link |
| `browser/components/onionservices/OnionLocationParent.sys.mjs` | Onion-Location ohne Tor ignoriert |
| `browser/components/newidentity/content/newidentity.js` | `clearStateForRestart()`, `closeTabs(force)` |
| `browser/components/preferences/preferences.js` | Gruppen `fawkesTor`, `fawkesDirectDns` im Fawkes-Pane |
| `browser/components/torconnect/content/aboutTorConnect.{html,js,css}`, `TorConnectParent.sys.mjs`, `toolkit/modules/RemotePageAccessManager.sys.mjs` | Button „Ohne Tor fortfahren…“ und Nachricht `torconnect:fawkes-without-tor` |
| `browser/base/content/navigator-toolbox.inc.xhtml` | `#include` des Urlbar-Hinweises |
| `browser/components/abouttor/AboutTorParent.sys.mjs`, `content/aboutTor.{html,js,css}` | Warnkasten, Tor-Check und Onion-Suche ohne Tor aus |
| `testing/mochitest/runtests.py` | kein Bootstrap-Warten bei deaktiviertem TorConnect |

Neuer Code: `toolkit/components/fawkes/` (`FawkesTorMode.{sys.mjs,h,cpp}`, `FawkesDirectProvider.sys.mjs`, `FawkesTorReconnect.sys.mjs`) und `browser/components/fawkes/` (`FawkesTorSwitch.sys.mjs`, `content/fawkesUrlbar.inc.xhtml`, Erweiterungen in `Fawkes.sys.mjs`, `fawkesButton.css`, `content/config/fawkes.mjs`, `fawkes-prefs.js`, `fawkes.ftl`).

## Tests (geschrieben, laufen erst in Phase 12)

Abschnitt 8 „Betrieb ohne Tor“:

| Anforderung | Test |
| --- | --- |
| kein `tor`-Prozess | `direct/browser_fawkes_direct_mode.js`: kein Start/Besitz von tor, Provider `none` läuft, `build()` verweigert, `TorProvider`/`TorProcess`/`TorControlPort` nie geladen |
| keine Verbindung zum Tor-SOCKS-Port | ebd.: Proxy-Prefs gesperrt auf direkt, Proxy-Dienst liefert für einen Kanal keinen Proxy, Testseite lädt direkt über `127.0.0.1` |
| keine Navigationssperre durch about:torconnect | ebd.: TorConnect `Disabled`, Seite lädt sofort, about:torconnect leitet weiter |
| `.onion` ohne DNS-Anfrage blockiert | `direct/browser_fawkes_direct_onion.js` (Fehlerseite für mehrere Schreibweisen, fetch/Bild/WebSocket scheitern, kein Eintrag im DNS-Cache trotz DNS-Override), `xpcshell/test_fawkes_onion_block.js` (DNS lehnt alle Formen inkl. IDN ab, Kanal liefert den Fawkes-Fehler nur ohne Tor, `onion.fawkestest.test` lädt) |
| kein automatischer Wechsel bei Tor-Fehlern | `tormode/browser_fawkes_tor_mode.js` (Bootstrap-Fehler mit Mock-Provider), `tormode/browser_fawkes_tor_reconnect.js` (Reconnect aus/an/Aufgeben/Abbruch – immer Tor) |
| Wechsel erst nach Neustart mit geleerter Sitzung | `tormode/browser_fawkes_tor_switch.js`: Abbrechen ändert nichts (Standard „Abbrechen“), Bestätigen löscht vor dem Speichern und startet neu, verweigerter Neustart ändert nichts, `clearStateForRestart()` schließt alle Tabs trotz `close_newnym=false` und löscht Cookies |
| Warnhinweis sichtbar | `direct/browser_fawkes_direct_ui.js`: Adressleiste, Button, Menü, about:tor, Einstellungen, Tor-UI ausgeblendet |
| Proxy-Kette mit einem Hop | kommt mit der Proxy-Kette in Phase 10 |

Außerdem `xpcshell/test_fawkes_tor_mode.js` (Modusauflösung mit Umgebungsvariablen, DoH-Abbildung, Reihenfolge und Sperren der Direkt-Konfiguration). Die Direktmodus-Tests stehen in einem eigenen Manifest mit `prefs = ["fawkes.tor.enabled=false"]` (wirkt beim Start, Standard „run by manifest“), die Tor-Modus-Tests mit dem Mock-Provider in einem zweiten, weil sie tor stoppen und neu starten. Sie greifen auf `127.0.0.1:8888` zu, weil die PAC-Konfiguration des Harness ohne Tor bewusst nicht gilt.

## Prüfungen ohne Build

- `node --check` für alle neuen bzw. geänderten JS/MJS-Dateien.
- Node-Logiktests mit Attrappen (Scratchpad, nicht im Tree): `FawkesTorMode` (Modusauflösung, DoH, Direkt-Konfiguration nur auf Default-Branch, Nutzerwerte bleiben) und die Zustandsmaschine von `FawkesTorReconnect` (Neustart + Bootstrap, drei Versuche dann Aufgeben, gescheiterter tor-Neustart wird wiederholt, aus = nichts, Abbruch stoppt, ohne Tor keine Beobachter): grün.
- `fluent.syntax` aus dem Tree: beide FTL-Dateien ohne Fehler, gleiche IDs und Attribute (119 Nachrichten).
- `ErrorList.py`-Generator: `NS_ERROR_MODULE_FAWKES 49`, `NS_ERROR_FAWKES_ONION_WITHOUT_TOR = 0x80760001`, keine Kollision.
- Static-Pref-Generator mit Präprozessor: erzeugt `fawkes_tor_directModeActive` in der Gruppe `fawkes`.
- `components.conf` geparst (3 Klassen); `runtests.py` per `ast` geparst.
- C++ (`FawkesTorMode.cpp`, Hooks) von Hand gegen die Header geprüft: `ToLowerCase`/`StringEndsWith` (`nsReadableUtils.h`), `StaticPrefs_fawkes.h`, `nsIURI::GetAsciiHost`, Namensauflösung `fawkes::` aus `mozilla::net`. Kompiliert wird erst in Phase 12.
- Commit-Tree gegen Arbeitsstand verglichen (57 Dateien identisch), keine Dateimodus-Änderung (`ErrorList.py` bleibt 100755; das Commit-Hilfsskript übernimmt jetzt den Modus aus HEAD).
- Keine `__pycache__`-Reste.
- `./mach lint` nicht ausgeführt (braucht Bootstrap, Phase 12).

## Grenzen und Übergaben an spätere Phasen

- Ohne Tor sehen Websites die echte IP-Adresse und der Internetanbieter (bzw. der DoH-Anbieter) die aufgerufenen Domains. RFP verbirgt die IP nicht.
- Phase 4: HTTP/3 im Direktbetrieb global erlauben, sobald der Per-Site-Schalter wirkt; LAN-Schutz prüft im Direktbetrieb zusätzlich aufgelöste IPs; Adblock-Fehlercode im Modul `FAWKES` anlegen.
- Phase 5: WebRTC/UDP im Direktbetrieb.
- Phase 10: Proxy-Kette mit einem Hop. `TorDomainIsolator` ist im Direktbetrieb bewusst inaktiv (sonst bekämen externe Proxys Tor-Nonces als Zugangsdaten); `.onion` ist schon vor der Kette blockiert.
- Der Urlbar-Hinweis verschwindet während des Tippens einer Adresse (wie der Connect-Button).
- Der Test für `clearStateForRestart()` ersetzt das Neuladen der Erweiterungen durch einen Stub, weil sonst der Testharness selbst neu geladen würde.
- Eine Unternehmensrichtlinie, die eine der Netzwerk-Prefs sperrt, behält ihren Wert (Browser verbindet dann ggf. gar nicht, aber nie schwächer).

## Manuelle Prüf-Checkliste (Phase 12)

1. Frischer Start: über Tor wie bisher, kein Warnhinweis.
2. Einstellungen → Fawkes → „Tor-Netzwerk verwenden“ aus → Dialog (Standard „Abbrechen“) → „Ohne Tor neu starten“ → Neustart ohne about:torconnect, alle Tabs weg.
3. Ohne Tor: „Ohne Tor“ in der Adressleiste, „!“ am Fawkes-Button, Menüzeile, Kasten auf about:tor, keine Onion-Suche; „Neuer Tor-Kanal“ fehlt; Strg+Umschalt+L tut nichts.
4. Kein `tor`-Prozess (Taskmanager/`ps`), IP-Prüfseite zeigt die eigene IP.
5. `http://duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion/` → Fehlerseite „Diese .onion-Website braucht Tor“; mit Wireshark/`tcpdump` keine DNS-Anfrage für `.onion`.
6. DoH: „Nur DNS über HTTPS“ mit eigener Adresse → nach Neustart DNS nur noch über DoH (Wireshark), mit ungültiger Adresse lädt nichts.
7. „Neue Identität“ ohne Tor funktioniert.
8. Zurück: „Tor-Netzwerk verwenden“ an → Dialog → Neustart über Tor, Proxy-Einstellungen wie vorher, kein Hinweis.
9. Tor-Verbindung absichtlich scheitern lassen (z. B. Netzwerk aus) → about:torconnect zeigt „Ohne Tor fortfahren…“, der Browser wechselt nie von selbst.
10. „Tor automatisch neu verbinden“ an, verbunden, `tor`-Prozess beenden → tor startet neu und verbindet wieder.

## Anwendungsprobe

Index-Probe (temporärer Index, `git read-tree fawkes-base`, dann `git apply --cached` in Phasenreihenfolge):

- Sammeldateien: `phase-01-branding.patch`, `phase-02-framework.patch` und `phase-03-no-tor.patch` bestehen `git apply --check` und ergeben den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`), `fawkes-phase-02` (`ded25fd99f13`) bzw. `fawkes-phase-03` (`aa18953cfa4f`).
- Serien: alle Patches aus `phase-01-branding/` (6), `phase-02-framework/` (7) und `phase-03-no-tor/` (8) lassen sich anwenden und ergeben exakt den Tree von `fawkes-phase-03` (`aa18953cfa4f`).
- **Ergebnis: grün.**

Die Probe mit `git am` im Prüf-Worktree entfällt weiterhin auf Ihren Wunsch (über sshfs zu langsam).

Phase 3 ändert tor-browser-build nicht.
