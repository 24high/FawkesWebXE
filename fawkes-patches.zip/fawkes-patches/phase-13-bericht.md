# Phase 13 – Captcha-Ausnahmen und Lazy Loading: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-12` = `9e9f590654af`, Tag
`fawkes-phase-13` = `331577b39abe`, Tree `59e3ca0c5a21`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `331577b39abe` | Fawkes: Exempt captcha providers and split lazy loading from scroll |

Patches: `fawkes-patches/phase-13-captcha-lazy/` (1 Datei) und
`fawkes-patches/phase-13-captcha-lazy.patch`.

## Was geändert wurde

- **Captcha-Ausnahmen:** `FawkesFlags.cpp` erkennt jetzt Dokumente von
  Cloudflare (`challenges.cloudflare.com`), Google reCAPTCHA (`google.com` und
  `gstatic.com` unter `/recaptcha/`, `recaptcha.google.com`, `recaptcha.net`)
  und hCaptcha (`hcaptcha.com` und Subdomains). Für diese Dokumente werden
  **alle** Fawkes-Schalter gelöscht (Rückgabe 0), damit die Prüfung ihre
  Skripte, Canvas-Zeichnung und Speicher nutzen kann. Die einbettende Seite
  behält ihre Einstellungen; ihre eigenen Skripte bleiben blockiert.
- **Lazy Loading als eigener Schalter:** neuer Schalter
  `profiling.lazyLoading` (Bit 46, Standard an). `LoadsLazyElementsEagerly()`
  in `FawkesDom.cpp` prüft ihn statt `profiling.scroll`. Damit kann
  Scroll-Tracking aus bleiben, während natives Lazy Loading weiterläuft.
- Doku (`categories.md`, `profiling.md`, `README.md`) und der Test
  `browser_fawkes_profiling_scroll.js` angepasst.

## Offen

- Der Adblocker gibt blockierte Domains weiterhin als Fehler zurück; die
  geforderte leere 200-Antwort ist noch nicht umgesetzt (eigener Commit folgt).
- Tests und Build wurden nicht ausgeführt; die Objdirs wurden auf Wunsch
  gelöscht.
