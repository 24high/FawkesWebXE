# Phase 10 – Proxy-Kette: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-09` = `496ba1a47f87`, Tag `fawkes-phase-10` = `c6a656c5eed7`, Tree `e128037d632e`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `5dab9cde28f9` | Fawkes: Carry the external proxy of the proxy chain in nsProxyInfo |
| 2 | `2d71c23c5b74` | Fawkes: Chain a second SOCKS5 handshake in the SOCKS layer |
| 3 | `c33f1637b5d8` | Fawkes: Keep the requests of proxy chain sites in the chain |
| 4 | `c1c8624ab3c8` | Fawkes: Choose an external proxy per site |
| 5 | `6c3f2bd7ea18` | Fawkes: Show the proxy chain in the menu and the settings |
| 6 | `96f29ac70aa0` | Fawkes: Test the proxy list and the choice of proxies |
| 7 | `b1603908c523` | Fawkes: Test the proxy chain end to end |
| 8 | `abd6a74d6852` | Fawkes: Document the proxy chain |
| 9 | `08d6f77b446e` | Fawkes: Fix the findings of the proxy chain review (erste Code-Prüfung) |
| 10 | `c6a656c5eed7` | Fawkes: Fix the findings of the second proxy chain review (zweite Code-Prüfung) |

Patches: `fawkes-patches/phase-10-proxy-chain/` (10 Dateien) und `fawkes-patches/phase-10-proxy-chain.patch` (44 Dateien).
Plan: `/home/dh/.claude/plans/fawkes-phase-10.md` (ohne Rückfrage umgesetzt, wie vereinbart).
Technische Doku: `browser/components/fawkes/docs/proxy-chain.md`; Hinweise in `network.md`, `categories.md`, `storage.md`, `architecture.md`, `tor-mode.md`.

Die Phase wurde einmal durch das Nutzungslimit unterbrochen (nach Schritt 6) und danach in derselben Sitzung fortgesetzt.

## Was jetzt da ist

Der Schalter `proxyChain` („Proxy-Kette (Tor → externer Proxy)“, Gruppe Netzwerk, Standard aus) wirkt jetzt pro Site:

```
mit Tor:   Browser → Tor-SOCKS → (Tor) → externer SOCKS5-Proxy → Website
ohne Tor:  Browser → externer SOCKS5-Proxy → Website
```

### Datenpfad

- **`nsProxyInfo`** trägt den externen Proxy (ID, Host, Port, Benutzer, Passwort, maximale Greeting-Zeit; neue Attribute `fawkesProxyId`, `fawkesChainHost`, … und `setFawkesProxyChain()` in `nsIProxyInfo`), auch über IPC (`ProxyInfoCloneArgs`) und durch die Klone von Necko. Die Felder gehören zum Verbindungsschlüssel und zum ORIGIN-Frame-Schlüssel: Verbindungen über verschiedene externe Proxys und mit/ohne Kette werden nie geteilt.
- **SOCKS-Layer** (`nsSOCKSIOLayer.cpp`): Nach dem CONNECT an Tor (Ziel = externer Proxy, Namen als ATYP 3, aufgelöst am Exit) folgt auf derselben Verbindung ein zweiter SOCKS5-Handshake: Greeting, ggf. Benutzer/Passwort (RFC 1929, UTF-8), CONNECT zur Website – Namen als Namen (ATYP 3), Adressen als Adressen. **Lokal wird nichts aufgelöst**, weder der Proxy noch die Website. Ohne Tor ist der Proxy selbst der einzige Hop.
- Die **Circuit-Isolation bleibt**: der Tor-Hop behält die SOCKS-Zugangsdaten, die `TorDomainIsolator` pro First-Party-Domain vergibt (der Fawkes-Filter läuft an Position 10, nach dem Isolator an Position 0).

### Auswahl pro Site

`toolkit/components/fawkes/FawkesProxyChain.sys.mjs` (Start bei `profile-after-change`):

- Proxy-Liste `fawkes.proxy.list`: `host:port`, `user:pass@host:port`, `socks5://`, `socks5h://`, `[IPv6]:port`, `#`-Kommentare (auch hinter Einträgen); ungültige, doppelte und in dieser Sitzung unbrauchbare Zeilen (.onion-Proxy ohne Tor, lokaler Proxy mit Tor) werden übersprungen und in den Einstellungen mit Zeilennummer gemeldet.
- Jede Site (eTLD+1 der Top-Level-Seite, über das neue `Services.fawkes.getSiteForChannel()`) bekommt bei der ersten Nutzung eine eigene zufällige Reihenfolge der Proxys (`crypto.getRandomValues`); ihr Proxy ist der erste gesunde und gilt für **alle** Requests der Seite, auch Drittanbieter. Er wechselt nur bei Ausfall/zu langsamer Antwort (mit Hinweis im Menü) oder über „Neuen Proxy wählen“ (Tab wird neu geladen).
- New Identity (`fawkes-session-reset`) löscht alle Zuordnungen.

### Antwortzeit und Failover

- Gemessen wird die Zeit vom Greeting bis zur Methodenantwort des externen Proxys, **nachdem der Tor-Hop steht**. Ein One-Shot-Timer auf dem Socket-Thread beendet den Handshake bei Überschreitung von `fawkes.proxy.maxLatencyMs` (Standard 1000); die Poll-Methode des SOCKS-Layers weckt dafür den Socket-Transport. Ohne Tor gilt dieselbe Grenze zusätzlich für den TCP-Aufbau zum Proxy.
- Ausfälle des externen Proxys (über Tor nicht erreichbar, zu langsam, schließt, spricht SOCKS4/HTTP, lehnt Authentifizierung ab, Antwort 2/7/8) enden in `NS_ERROR_FAWKES_PROXY_FAILED`. Dieser Fehler nimmt am Proxy-Failover von Necko teil: jeder Request hat eine Liste von bis zu fünf Proxys seiner Site; der nächste wird genommen, **bevor Nutzdaten gesendet wurden**.
- Der SOCKS-Layer meldet jedes Ergebnis an den Main-Thread (`fawkes-proxy-result`); langsame/ausgefallene Proxys werden `fawkes.proxy.retryAfterSeconds` (neu, 300 s) übersprungen, betroffene Sites wechseln zum nächsten gesunden Proxy ihrer Reihenfolge.
- Fallen alle aus: Fehlerseite „Die Proxy-Kette ist ausgefallen“ (mit „Erneut versuchen“), außer `fawkes.proxy.fallbackDirect` ist an (dann mit Tor nur über Tor, ohne Tor direkt).

### Nie ohne Kette (fail closed)

- `fawkes::CheckProxyChain()` in `nsHttpChannel::BeginConnect`: Ein Request einer Ketten-Site, dessen Proxy nicht zur Kette gehört (leere Liste, Filterfehler, fremder Filter), scheitert mit `NS_ERROR_FAWKES_PROXY_UNAVAILABLE` (Fehlerseite „Kein Proxy für die Proxy-Kette“), bevor etwas verbunden wird – außer bei Bypass-Zielen oder erlaubtem Fallback (mit Tor nur über Tors SOCKS-Proxy).
- WebSockets von Ketten-Sites lösen für ihre Zulassung keine Namen mehr lokal auf (Hook in `WebSocketChannel::OnProxyAvailable`).
- `.onion`-Ziele und lokale Ziele umgehen die Kette immer (JS-Filter, C++-Prüfung und SOCKS-Layer als zweite Verteidigung); `.onion`-Namen erreichen nie einen externen Proxy.
- HTTP/3 und WebTransport sind bei aktiver Kette immer gesperrt (kein UDP über SOCKS), WebRTC seit Phase 5; beide Menüeinträge sind dann gesperrt. Early-Hints-Preconnects werden für Ketten-Sites nicht gemacht.

### UI

- Menü (Untermenü „Proxy-Kette“, ohne Tor „Externer Proxy“): Schalter, Proxy der Site mit letzter Greeting-Zeit bzw. „zu langsam/nicht erreichbar, kein anderer Proxy verfügbar“, Hinweis „Gewechselt, weil … ausgefallen ist / zu langsam geantwortet hat“, „Neuen Proxy wählen“.
- Einstellungen: erweiterte Erklärung (Formate, Zufallswahl, Klartext-Hop, Speicherung der Zugangsdaten), Statuszeile der Liste (nutzbare Proxys, fehlerhafte und unbrauchbare Zeilen), Antwortzeit (0 = keine Grenze), Wiederholzeit, Fallback-Text je Modus.

## Entscheidungen ohne Rückfrage (bitte prüfen)

1. **Verketteter Handshake im SOCKS-Layer** wie vorgeschlagen, kein lokaler Helferprozess (kein offener lokaler Port).
2. **Lokale Ziele umgehen die Kette** wie `.onion`: Sie erreichen nie das Netz des externen Proxys. Mit `blockLan` (Standard) sind sie von öffentlichen Seiten ohnehin gesperrt; wo erlaubt, gehen sie wie ohne Kette.
3. **Fail closed unabhängig vom JS-Filter**: zusätzliche C++-Prüfung in `BeginConnect`. Eine eingeschaltete Kette ohne nutzbaren Proxy zeigt eine eigene Fehlerseite statt direkt über Tor zu laden (außer mit `fawkes.proxy.fallbackDirect`).
4. **Failover über Necko** (Liste in `nsProxyInfo::mNext`), höchstens **5 Proxys pro Request** (Konstante), damit ein kaputter Listenblock nicht minutenlang probiert wird.
5. **Feste zufällige Reihenfolge pro Site**: Bei Ausfall rückt der nächste gesunde Proxy dieser Reihenfolge nach; so nutzen gleichzeitige Requests einer Seite denselben Proxy. Sind alle gesperrt, werden alle trotzdem versucht (sonst sperrte ein kurzer Tor-Ausfall die Kette für 5 Minuten).
6. **„Einige Minuten“ = `fawkes.proxy.retryAfterSeconds` 300 s** (neue Pref, in den Einstellungen änderbar).
7. **Gesundheitszustand bleibt bei New Identity**, nur die Zuordnungen werden gelöscht (der Zustand sagt nichts über Sites).
8. **Ohne Tor gilt die Zeitgrenze auch für den TCP-Aufbau** zum Proxy (sonst hinge ein toter Proxy bis zum Verbindungs-Timeout von Necko).
9. **Standard 1000 ms beibehalten**, wie im Auftrag; mit Tor enthält das Greeting eine Circuit-Rundreise, die oft länger dauert – dokumentiert, 0 schaltet die Grenze ab.
10. **Was gegen den Proxy zählt**: jeder Fehler des Tor-CONNECT zum Proxy, Greeting/Authentifizierung, Antworten 2/7/8. Die Antworten 1, 3–6 gelten als Fehler der Website (ein vertippter Name ließe sonst alle Proxys ausfallen).
11. **.onion-Proxys nur mit Tor, lokale Proxys nur ohne Tor.**
12. **Prozentkodierung nur in den URL-Formen**; Zugangsdaten als UTF-8.
13. **Zuordnung pro Site**, nicht pro Container/privatem Fenster (wie im Auftrag; Tor Browser nutzt beides nicht). Mit wenigen Proxys teilen sich viele Sites einen Proxy – dokumentiert.
14. **Zugangsdaten im Profil (`prefs.js`)** wie verlangt; zusätzlich Hinweis, dass die Strecke Tor-Exit → Proxy unverschlüsselt ist und die Exits sie mitlesen können.
15. **Early-Hints-Preconnects** für Ketten-Sites blockiert (sie liefen sonst an der Kette vorbei).
16. **Windows mit Tor über Named Pipe**: Kette nicht möglich (blockierender Handshake ohne wirksame Zeitgrenze) → fail closed.
17. **Necko sperrt Ketten-Proxys nicht selbst** (`GetFailoverForProxy`), nur der Fawkes-Dienst entscheidet.
18. **Ergebnisse nur im Parent-Prozess** (ein separater Socket-Prozess ist in Firefox Desktop aus).
19. **Requests des Browsers für eine Seite folgen deren Site** (Befund der zweiten Prüfung): der Klartext-Request von HTTPS-Only nach 2,2 s und die Reader-Ansicht (Artikel und Bilder) hatten keine Fawkes-Site und liefen an der Kette vorbei (ohne Tor sogar von der echten IP). Jetzt gilt für die Kette die Site des Artikels bzw. die First-Party-Domain der First-Party-Isolation – dieselbe, nach der Tor die Circuits trennt. Interne First-Partys (`*.mozilla`, Erweiterungen) zählen nicht.
20. **Ohne Tor vertraut der LAN-Schutz auf Ketten-Sites nicht dem Adressraum des Tabs** (Befund der zweiten Prüfung): Über einen Proxy geladene Dokumente setzen ihn nicht, ein Tab erbte sonst den „lokal“-Status einer vorher gezeigten Router-Seite.

## Geänderte Upstream-Dateien (dünne Hooks, für spätere Rebases)

| Datei | Änderung |
| --- | --- |
| `netwerk/base/nsIProxyInfo.idl` | Attribute `fawkesProxyId`, `fawkesChainHost/Port/Username/Password`, `fawkesMaxLatencyMs`, Methode `setFawkesProxyChain()` |
| `netwerk/base/nsProxyInfo.{h,cpp}` | Felder, Getter/Setter, (De-)Serialisierung, `AppendFawkesChainKey()` |
| `netwerk/ipc/NeckoChannelParams.ipdlh` | sechs Felder in `ProxyInfoCloneArgs` |
| `netwerk/protocol/http/nsHttpConnectionInfo.cpp` | Kettenschlüssel in `BuildHashKey` und `BuildOriginFrameHashKey` |
| `netwerk/socket/nsSOCKSIOLayer.cpp` | zweiter Handshake, Zeitgrenze (Timer + Poll), Meldungen, Fehlerzuordnung (größter Eingriff, ~300 Zeilen) |
| `netwerk/base/nsSocketTransport2.cpp` | `ErrorAccordingToNSPR` reicht das Fehlermodul FAWKES durch |
| `xpcom/base/ErrorList.py` | `NS_ERROR_FAWKES_PROXY_FAILED` (8), `NS_ERROR_FAWKES_PROXY_UNAVAILABLE` (9) |
| `netwerk/protocol/http/nsHttpChannel.cpp` | `CheckProxyChain` in `BeginConnect`, Failover-Status in `ContinueOnStartRequest2` |
| `netwerk/base/nsProtocolProxyService.cpp` | `GetFailoverForProxy` sperrt Ketten-Proxys nicht |
| `netwerk/protocol/websocket/WebSocketChannel.cpp` | kein Zulassungs-DNS für Ketten-Sites |
| `docshell/base/nsDocShell.cpp`, `toolkit/content/aboutNetError.mjs` | zwei Fehlerseiten |
| `js/xpconnect/src/xpc.msg` | Meldungstexte der zwei Fehlercodes |

Neuer Code: `toolkit/components/fawkes/FawkesProxyChain.{h,cpp,sys.mjs}`; Erweiterungen in `FawkesNetwork.cpp` (HTTP/3, Preconnect, Adressraum), `FawkesService.{h,cpp}`/`nsIFawkesService.idl` (`getSiteForChannel`, `getFirstPartySiteForChannel`), `components.conf`, `moz.build`, `fawkes-prefs.js`, `Fawkes.sys.mjs`, `content/config/fawkes.mjs`, `fawkes.ftl` (en-US, de); Testmodul `FawkesMockSocks.sys.mjs`; Tests und Doku.

## Prüfungen ohne Build

- **Erste Code-Prüfung durch einen separaten Prüf-Agenten** (nur lesend, gegen den Tree und Searchfox ESR 153): **keine Build-Blocker** (XPIDL/IPDL-Signaturen, `Buffer<>`-Vorlagen, Timer-Überladung, `NS_IMPL_ISUPPORTS` mit zwei Interfaces, Fehlercode-Casts, `NetAddr::InitFromString`, moz.build/components.conf); Zustandsautomat des SOCKS-Layers, Timer/Poll über NSPR/NSS, Failover, Hash-Schlüssel und IPC bestätigt. 13 Befunde, alle bearbeitet (Commit 9): WebSocket-Zulassung löste ohne Tor lokal auf, Klartext-Hop Exit → Proxy undokumentiert, Fallback mit Tor akzeptierte DIRECT, Necko sperrte Ketten-Proxys selbst, Antwort 2 ohne Failover, Zugangsdaten als Latin-1, Named Pipe unter Windows, Latenz 0 nicht einstellbar, „Neuen Proxy wählen“ mit einem Proxy, zweiter Setter-Aufruf; dazu eine falsch angenommene DNS-Voreinstellung im Test.
- **Zweite, fokussierte Prüfung** der Korrekturen und **aller Testerwartungen** (jede Aufgabe gegen die Implementierung verfolgt): keine Build-Fehler in den Korrekturen; gefunden und behoben (Commit 10): zwei Umgehungen der Kette (HTTPS-Only-Hintergrund-Request, Reader-Ansicht), der geerbte Adressraum ohne Tor, zwei Tests, die fehlgeschlagen wären (Wiederverwendung offener Verbindungen zwischen Testaufgaben; HTTPS-Only in privaten Fenstern im Browser-Test), fehlende Fehlertexte, strengere Fallback-Prüfung. Ergebnis sonst: `test_fawkes_proxy_list.js` 7/7, `test_fawkes_proxy_chain.js` 16/16 nach der Korrektur, `test_fawkes_proxy_chain_direct.js` 6/6, Browser-Tests 3/3 und 2/2 nach der Korrektur.
- Eigene Prüfungen: Parser, Auswahl-, Failover- und Filterlogik des JS-Moduls in Node mit nachgebauten `Services` (über 40 Prüfungen, `fawkes-tools/proxychain-node/`); das Mock-SOCKS5-Modul in Node mit simulierten Verbindungen (Weiterleitung, geteilte Schreibvorgänge, IPv4/IPv6, Ablehnung, Fehlverhalten, Verzögerung).
- XPIDL (`nsIProxyInfo.idl`, `nsIFawkesService.idl`) mit dem In-Tree-Parser inkl. Header-Erzeugung (neues `fawkes-tools/xpidlcheck.py`); IPDL (`NeckoChannelParams.ipdlh`, `PNecko.ipdl`, `PSocketProcess.ipdl`, `PProxyConfigLookup.ipdl`) mit Parser und Typprüfung über alle 474 IPDL-Dateien, vorverarbeitet (neues `fawkes-tools/ipdlcheck.py`); `ErrorList.py` erzeugt die neuen Codes (`0x80760008`, `0x80760009`).
- `node --check` für alle geänderten JS/MJS-Dateien und Tests; TOML der drei Manifeste mit `tomllib`; Fluent (`fluent.syntax`): en-US und de je 148 Nachrichten, keine Fehler, gleiche Attribute; 80 Spalten im neuen Code (Ausnahme: lange URLs und Tabellenzeilen).
- Static Prefs: unverändert (neue Prefs nur in `fawkes-prefs.js`); keine `__pycache__`/`parser.out`-Reste im Tree.
- `./mach lint` nicht ausgeführt (braucht Bootstrap, Phase 12).

## Grenzen (auch in `proxy-chain.md`)

- Externe Proxys werden von Unbekannten betrieben: Sie sehen die besuchten Websites, unverschlüsselte Inhalte und können Honeypots sein. HTTPS nutzen.
- SOCKS5 ist unverschlüsselt: Mit Tor sehen die Exits Benutzer/Passwort des Proxys und die Zielnamen (wie ohne Kette); mit Zugangsdaten kann der Proxy die Sites eines Nutzers verknüpfen.
- Löst der Proxy einen Namen zu einer privaten Adresse auf, landet der Request in seinem LAN; ohne lokales DNS nicht erkennbar (wie bei Tor-Exits).
- Die Greeting-Zeit über Tor enthält eine Circuit-Rundreise; gesunde Proxys können bei 1000 ms als langsam gelten.
- Fällt ein Proxy erst aus, nachdem Daten der Website flossen, scheitert dieser Request; der nächste nutzt einen anderen Proxy.
- Die Circuit-Anzeige zeigt nur den Tor-Teil.
- Windows mit Tor über Named Pipe: Kette nicht nutzbar.
- Mit separatem Socket-Prozess (in Desktop aus) funktionieren Handshake und Failover, aber langsame Proxys werden nicht gemerkt.
- Eine geänderte Liste beendet offene Verbindungen nicht.
- Der Code ist (wie alle Phasen) nie kompiliert und nie ausgeführt worden.

## Tests (geschrieben, laufen erst in Phase 12)

| Anforderung (Abschnitt 8) | Test |
| --- | --- |
| Proxy-Listen-Parser | xpcshell `test_fawkes_proxy_list.js`: alle Formate, ungültige Zeilen mit Grund, Duplikate, unbrauchbare Proxys mit/ohne Tor |
| Auswahl/Failover-Logik | `test_fawkes_proxy_list.js`: Wahl pro Site, Wechsel bei langsam/ausgefallen, alle ausgefallen, Wiederholzeit, Listenänderungen, „Neuen Proxy wählen“, New Identity, Ausgabe des Filters mit/ohne Tor (Felder, Reihenfolge, max. 5, Fallback, Bypass) |
| Mock-SOCKS5-Server: einer als „Tor“, mehrere externe, einer verzögert > 1 s | `FawkesMockSocks.sys.mjs` + `test_fawkes_proxy_chain.js` (mit Tor): zwei Hops, ATYP 3 an beiden Hops, Adressen als ATYP 1, Zugangsdaten (auch UTF-8), Drittanbieter, langsamer Proxy (Verzögerung 3 s, Grenze 0,5 s) mit Failover und Überspringen, nicht erreichbare/schließende/SOCKS4/HTTP-Proxys, Ablehnung per Regel, Fehler der Website ohne Failover, alle ausgefallen, Fallback über Tor, leere Liste (fail closed), .onion/LAN-Bypass, getrennte Verbindungen, kein HTTP/3; **kein lokales DNS** über `network.dns.notifyResolution` |
| Ohne Tor (ein Hop) | `test_fawkes_proxy_chain_direct.js`: ein Hop, Zugangsdaten, abgelehnter Port + langsamer Proxy, alle ausgefallen, direkter Fallback, leere Liste |
| Menü/Einstellungen | browser-chrome `browser_fawkes_proxy_chain.js` (Menü, HTTP/3 gesperrt, Hinweis nach Wechsel, leere Liste, New Identity, Statuszeile) und `direct/browser_fawkes_direct_proxy_chain.js` (Seite über Mock-Proxy ohne Tor, Texte des Direktmodus) |

## Manuelle Prüf-Checkliste (Phase 12)

Vorher `fawkes.debug` an und `MOZ_LOG=SOCKS:5,FawkesProxyChain:5` für das Protokoll. Für öffentliche SOCKS5-Proxys gelten die Warnungen oben.

1. **Kette mit Tor**: 2–3 SOCKS5-Proxys eintragen, Kette für eine IP-Anzeige-Site einschalten (z. B. eine „What is my IP“-Seite): angezeigt wird die IP des Proxys, nicht die des Tor-Exits; Menü zeigt Proxy und ms; Circuit-Anzeige zeigt den Tor-Circuit.
2. **Kette ohne Tor**: dasselbe im Direktmodus; IP des Proxys; `about:networking#dns` enthält den Namen der Site nicht.
3. **Langsamer Proxy**: `fawkes.proxy.maxLatencyMs` z. B. auf 50 setzen → Menü zeigt „Gewechselt, weil … zu langsam“; sind alle zu langsam → Fehlerseite „Die Proxy-Kette ist ausgefallen“; mit 0 lädt die Seite wieder.
4. **Failover**: einen toten Eintrag an den Anfang setzen (`192.0.2.1:1080`) und „Neuen Proxy wählen“, bis er gewählt ist → die Seite lädt trotzdem.
5. **New Identity** → Menü zeigt „noch keiner gewählt“, danach ein neuer Proxy.
6. **.onion-Bypass**: Kette für eine .onion-Site einschalten → lädt nur über Tor; im SOCKS-Log kein zweiter Handshake.
7. **LAN-Ziel**: von einer Ketten-Site ein Bild von `192.168.1.1` → blockiert (`blockLan`); mit `blockLan` aus ohne externen Proxy.
8. **Leere Liste**: Kette an, Liste leer → Fehlerseite „Kein Proxy für die Proxy-Kette“; mit Fallback-Option → lädt über Tor.
9. **Einstellungen**: ungültige/doppelte/unbrauchbare Zeilen werden mit Nummer gemeldet.
10. **Menü**: WebRTC und HTTP/3 sind bei Kette gesperrt.

## Anwendungsprobe

Index-Probe (temporärer Index, `git read-tree fawkes-base`, dann `git apply --cached` in Phasenreihenfolge; Skript `fawkes-tools/probe.sh`, jetzt mit Wiederholung bei sshfs-Fehlern):

- Sammeldateien: `phase-01-branding.patch` bis `phase-10-proxy-chain.patch` bestehen `git apply --check` und ergeben den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`), `fawkes-phase-02` (`ded25fd99f13`), `fawkes-phase-03` (`aa18953cfa4f`), `fawkes-phase-04` (`dd9f9ead8e67`), `fawkes-phase-05` (`33768452f3ad`), `fawkes-phase-06` (`6d56d5b6daa0`), `fawkes-phase-07` (`2778b279eddb`), `fawkes-phase-08` (`3c07fd7ad1f2`), `fawkes-phase-09` (`cd5a108f697d`) bzw. `fawkes-phase-10` (`e128037d632e`).
- Serien: alle Patches aus `phase-01-branding/` (6), `phase-02-framework/` (7), `phase-03-no-tor/` (8), `phase-04-network/` (9), `phase-05-js-apis/` (10), `phase-06-css/` (8), `phase-07-profiling/` (9), `phase-08-randomization/` (12), `phase-09-cookie-banners/` (10) und `phase-10-proxy-chain/` (10) lassen sich anwenden und ergeben exakt den Tree von `fawkes-phase-10` (`e128037d632e`).
- **Ergebnis: grün.**

Die Probe mit `git am` im Prüf-Worktree entfällt weiterhin auf Ihren Wunsch (über sshfs zu langsam).

Phase 10 ändert tor-browser-build nicht.

## Hinweise für spätere Phasen

- **Phase 11 (Proxy-Scraper)**: `parseProxyLine()`/`parseProxyList()` aus `FawkesProxyChain.sys.mjs` wiederverwenden; die Latenzmessung soll wie hier das Greeting messen (mit Tor über Tor). Für Prüfungen über Tor kann der Scraper Proxy-Infos mit `setFawkesProxyChain()` bauen und dieselbe Kette nutzen. `Services.fawkesNetwork.isLocalHost()` filtert lokale Einträge.
- **Phase 12**: neue Tests siehe oben; `test_fawkes_proxy_chain*.js` brauchen keine echten Netzzugriffe. Upstream-SOCKS-Tests (`netwerk/test/unit/test_socks.js`) sollten unverändert laufen (ohne Fawkes-Felder bleibt der Handshake gleich).
- **Umgebung**: Das sshfs-Mount lieferte in dieser Phase bei etwa jedem sechsten Lesezugriff `Operation not permitted`. Neue Helfer mit Wiederholung in `fawkes-tools/`: `rd.sh`, `g.sh`, `frepl.py`; `fcommit.py` und `probe.sh` wiederholen jetzt selbst; neu geschrieben: `xpidlcheck.py`, `ipdlcheck.py`.
