# FawkesWebXE patches

Patches that turn Tor Browser into FawkesWebXE, one directory (series, one file
per commit) and one combined file per phase.

## Base

| Repository | Base tag | Branch / tag it is based on | Commit |
| --- | --- | --- | --- |
| tor-browser | `fawkes-base` (= `fawkes-phase-00`) | `tor-browser-153.5.0esr-16.0-1-build2` (branch `tor-browser-153.5.0esr-16.0-1`) | `72e858f6dffb` |
| tor-browser-build | `fawkes-base` | `tbb-16.0a14-build2` (references `tor-browser-153.5.0esr-16.0-1-build2`) | `694c0c25609e` |

The tags `fawkes-base` and `fawkes-phase-NN` exist only locally and are not
pushed.

**Build status:** the patches of phases 1–11 have never been built on their
own. Phase 12 changes the defaults of the built browser (icon, DNS, switches,
Cloudflare, Tor connection, proxy scraper) and is built and tested with the
complete series.

## Phases

| Phase | Series | Combined file | Content |
| --- | --- | --- | --- |
| 00 | – | – | Branch `fawkes` and tag `fawkes-base`; no changes. |
| 01 | `phase-01-branding/` | `phase-01-branding.patch` | Rename to FawkesWebXE: branding, mozconfigs (app name `fawkeswebxe`, updater disabled), UI strings, placeholder graphics, branding check script and test. |
| 01 (tor-browser-build) | `phase-01-branding/tor-browser-build/` | `phase-01-branding-tor-browser-build.patch` | Package as FawkesWebXE: product name, program file, branding directory, no updater/MAR, installer and disk image graphics, package/archive and start script names `fawkeswebxe`. |
| 02 | `phase-02-framework/` | `phase-02-framework.patch` | Fawkes framework: switch table, `Services.fawkes`, per-site settings in `fawkes-sites.json`, flag transport from the parent to documents, workers and worklets, toolbar button and menu, `about:preferences#fawkes`, English and German strings (switches have no effect yet). |
| 03 | `phase-03-no-tor/` | `phase-03-no-tor.patch` | Operation without Tor: `fawkes.tor.enabled` (read at startup, environment variables can only keep Tor on), direct provider without tor process or SOCKS proxy, switching only with confirmation, deleted session and restart (settings, about:torconnect after a failure), `.onion` blocked before DNS with its own error page, optional DNS over HTTPS, permanent warning and hidden Tor-only UI, "Reconnect to Tor automatically", tests and docs. |
| 04 | `phase-04-network/` | `phase-04-network.patch` | Network protection decided in the parent per channel: referer blocker (Origin unchanged), Googlebot user agent in header and `navigator` (windows and workers), HTTP/3 and WebTransport block (HTTP/3 turned on without Tor), ad blocker with `adblock.txt` next to the program file and `fawkes.blockedDomains` (error page, menu counter, settings status), local network and port scan protection (immediate identical failures, Tor ports, resolved addresses without Tor), tests and docs. |
| 05 | `phase-05-js-apis/` | `phase-05-js-apis.patch` | JavaScript protection in the engine: WebIDL `[Func]` checks, neutralized DOM methods and ignored event listeners for the JavaScript categories (WebGL/WebGPU, canvas readout, audio, device information, sensors, local fonts, storage, beacons, clipboard, hardware interfaces, DRM), pausing pages in background tabs and inactive windows, WebRTC per site (off with the proxy chain; the build keeps `--disable-webrtc`), custom script patterns dropped before compilation, tests and docs. |
| 06 | `phase-06-css/` | `phase-06-css.patch` | CSS protection in the style system and the CSS loader: media features with the resistFingerprinting values (plus `display-mode`, `forced-colors`, used color scheme), no `local()` in `@font-face` rules, images of interaction-dependent rules (`:hover`, `:checked`, `[value]`, …, marked by Stylo while parsing) not loaded, no scroll-driven animations, `env(safe-area-inset-*)` = 0, custom stylesheet patterns dropped before parsing (shared pattern compiler, error `NS_ERROR_FAWKES_STYLESHEET_BLOCKED`), tests and docs. |
| 07 | `phase-07-profiling/` | `phase-07-profiling.patch` | Behavioral profiling protection: scroll, wheel and pointer listeners ignored, IntersectionObserver reports only the first state, lazy loading made eager, visibility listeners ignored and window/document focus events hidden with `document.hidden`/`visibilityState`/`hasFocus()` always "visible and focused" for the page, exit-intent mouse events hidden and no beforeunload dialogs, coarse jittered clocks (`performance.now()`, `Date`, rAF, event timestamps, windows and workers) while the user types, built-in session replay/heatmap domain list blocked in the parent (`NS_ERROR_FAWKES_SESSION_REPLAY_BLOCKED`, menu counter), fix of `GetOwnerGlobal()` calls from phase 05, tests and docs. |
| 08 | `phase-08-randomization/` | `phase-08-randomization.patch` | Fingerprint randomization per site (`fpRandomize`): session key in `FawkesService` (reset by New Identity), key per site carried as RFP's randomization key in the cookie jar settings, deterministic values for canvas/WebGL/audio noise, WebGL strings and extensions, screen, window, `devicePixelRatio`, color depth and their media features, mouse screen coordinates, `hardwareConcurrency`, `maxTouchPoints`, cameras, fonts asked for by name, element and text boxes, user agent within the OS family (header and `navigator`), time zone; English (`Accept-Language`, `navigator.languages`, `Intl`) for such sites; blocking switches win; fixes of phase 02 code and of the xpcshell test head, tests and docs. |
| 09 | `phase-09-cookie-banners/` | `phase-09-cookie-banners.patch` | Cookie banners (`cookieBanner`): Firefox' cookie banner service in "reject, otherwise accept" mode (normal and private browsing, global rules also in frames, no cool-down) with the rules of the in-tree Remote Settings dump (no network requests) plus Fawkes rules, accept-only click rules turned into hints, rule list switchable (`fawkes.cookiebanners.useRuleList`), per-site decision in `nsCookieBannerService::GetDomainPref`; heuristic JSWindowActor `FawkesCookieBanner` in every frame and in open/closed shadow roots (reject, else turn off the purposes in the settings and save, accept only without a way to reject / "pay or OK", release scroll locks, safety rules and limits), result in the menu, tests (one page per required CMP) and docs. |
| 10 | `phase-10-proxy-chain/` | `phase-10-proxy-chain.patch` | Proxy chain (`proxyChain`): external SOCKS5 proxy in `nsProxyInfo` (IDL, IPC, connection keys), second SOCKS5 handshake through Tor in `nsSOCKSIOLayer` (names as names, no local DNS; one hop without Tor) with a time limit on the greeting and Necko failover (`NS_ERROR_FAWKES_PROXY_FAILED`), random proxy per site for the session (`FawkesProxyChain.sys.mjs`, proxy filter after `TorDomainIsolator`, reset by New Identity), fails closed in `nsHttpChannel::BeginConnect` (`NS_ERROR_FAWKES_PROXY_UNAVAILABLE`), .onion and local hosts bypass it, HTTP/3/WebTransport/WebRTC off, menu and settings (list status, latency, retry time, fallback), mock SOCKS5 tests and docs. |
| 11 | `phase-11-proxy-scraper/` | `phase-11-proxy-scraper.patch` | Proxy scraper next to the proxy list (only on a click): eight public list sites, one adapter each (`FawkesProxySources.sys.mjs`, chosen and rejected sites in `docs/proxy-sources.md`), strict validation without private, local or reserved addresses, checks through the same way as the proxy chain (with Tor through Tor; real SOCKS5 greeting and CONNECT, median greeting time of three below the limit, elite check through an HTTPS judge with normal TLS validation, offline GeoIP country check of the listed and the outgoing address with tor's `geoip`/`geoip6`, 14 Eyes blocked by default), 32 parallel checks, cancel, appending without duplicates with a comment line, recheck that marks failed proxies; no preset judge; settings with progress, tests with mock SOCKS5 proxies and TLS judges, docs. |
| 12 | `phase-12-customization/` | `phase-12-customization.patch` | Defaults of the built browser: the application icons from `fawkes.ico`, DNS over HTTPS only with NextDNS (`https://dns.nextdns.io/`), every switch on by default except the proxy chain, the Cloudflare challenge host (`challenges.cloudflare.com`) exempt from the JavaScript, CSS and profiling protections while the site that shows the challenge keeps them, "Always connect automatically" (Tor at startup, also on the first start), the proxy scraper without the external judge (the browser checks SOCKS5, the tunnel and a valid certificate itself and marks the proxies, the judge stays optional for the address checks), WebRTC compiled in on Linux and macOS (the MinGW builds keep it off), and the `README.md` with the feature overview and the build instructions. |
| 13 | `phase-13-captcha-lazy/` | `phase-13-captcha-lazy.patch` | Captcha and challenge providers (Cloudflare, Google reCAPTCHA, hCaptcha) are fully exempt: their documents get no Fawkes protections, the embedding site keeps its own. Native lazy loading (`loading="lazy"`) is its own switch `profiling.lazyLoading`, separate from `profiling.scroll`. |

Corrections to code of earlier phases are added as new commits to the current
phase; already generated patches of earlier phases are not rewritten.

## Applying

Apply the phases in order on a checkout of the base commit.

tor-browser, series (keeps the commits):

```
git checkout -b fawkes fawkes-base     # or: tor-browser-153.5.0esr-16.0-1-build2
git am fawkes-patches/phase-01-branding/*.patch
git am fawkes-patches/phase-02-framework/*.patch
git am fawkes-patches/phase-03-no-tor/*.patch
git am fawkes-patches/phase-04-network/*.patch
git am fawkes-patches/phase-05-js-apis/*.patch
git am fawkes-patches/phase-06-css/*.patch
git am fawkes-patches/phase-07-profiling/*.patch
git am fawkes-patches/phase-08-randomization/*.patch
git am fawkes-patches/phase-09-cookie-banners/*.patch
git am fawkes-patches/phase-10-proxy-chain/*.patch
git am fawkes-patches/phase-11-proxy-scraper/*.patch
git am fawkes-patches/phase-12-customization/*.patch
git am fawkes-patches/phase-13-captcha-lazy/*.patch
```

tor-browser, combined files (no commits):

```
git apply fawkes-patches/phase-01-branding.patch
git apply fawkes-patches/phase-02-framework.patch
git apply fawkes-patches/phase-03-no-tor.patch
git apply fawkes-patches/phase-04-network.patch
git apply fawkes-patches/phase-05-js-apis.patch
git apply fawkes-patches/phase-06-css.patch
git apply fawkes-patches/phase-07-profiling.patch
git apply fawkes-patches/phase-08-randomization.patch
git apply fawkes-patches/phase-09-cookie-banners.patch
git apply fawkes-patches/phase-10-proxy-chain.patch
git apply fawkes-patches/phase-11-proxy-scraper.patch
git apply fawkes-patches/phase-12-customization.patch
git apply fawkes-patches/phase-13-captcha-lazy.patch
# or: patch -p1 < fawkes-patches/phase-01-branding.patch   (no binary files!)
```

`patch -p1` cannot apply the binary graphics (icons, PNGs) of phase 01, the
binary test certificate (`client-cert.p12`) of phase 11 or the binary icons of
phase 12; use `git apply` for the combined files.

tor-browser-build (in a checkout of `tbb-16.0a14-build2`):

```
git am /path/to/fawkes-patches/phase-01-branding/tor-browser-build/*.patch
# or: git apply /path/to/fawkes-patches/phase-01-branding-tor-browser-build.patch
```

## Apply check

After each phase, the series and the combined files of all phases up to that
phase are applied in order to `fawkes-base` in a temporary index
(`GIT_INDEX_FILE=… git read-tree fawkes-base`, then `git apply --cached`);
the resulting tree must be identical to the tree of the phase tag. Up to phase
01 the series were additionally applied with `git am` in the check worktree
`../fawkes-patchcheck`; from phase 02 on this step is skipped (user decision:
over sshfs it takes up to an hour because git refreshes the whole index).

Last check: phase 12, combined files and series 01–12 give the tree of
`fawkes-phase-12` (`f7cfe2d26d65`); phase 13 is added on top.
