# Phase 11 – Proxy-Scraper: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-10` = `c6a656c5eed7`, Tag `fawkes-phase-11` = `7be6bb5456ad`, Tree `91cb3fe28a4e`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `8cb45b4a8195` | Fawkes: Add the proxy list sites of the proxy scraper |
| 2 | `e2d4fdaa4a0a` | Fawkes: Check proxy candidates, judge answers and countries offline |
| 3 | `5e0c3f44e883` | Fawkes: Search and check public SOCKS5 proxies |
| 4 | `3abe6044a81d` | Fawkes: Show the proxy scraper in the proxy chain settings |
| 5 | `bbf30db8016f` | Fawkes: Test the proxy scraper |
| 6 | `772d6b9a9bd2` | Fawkes: Test the proxy scraper settings |
| 7 | `b4c7f863d650` | Fawkes: Document the proxy scraper |
| 8 | `aa74d940a831` | Fawkes: Fix the findings of the proxy scraper review (erste Code-Prüfung) |
| 9 | `7be6bb5456ad` | Fawkes: Fix the findings of the second proxy scraper review (zweite Code-Prüfung) |

Patches: `fawkes-patches/phase-11-proxy-scraper/` (9 Dateien) und `fawkes-patches/phase-11-proxy-scraper.patch` (39 Dateien, enthält das binäre Test-Zertifikat `client-cert.p12` – in beiden Varianten als Binär-Patch).
Plan: `/home/dh/.claude/plans/fawkes-phase-11.md` (ohne Rückfrage umgesetzt, wie vereinbart).
Technische Doku: `browser/components/fawkes/docs/proxy-scraper.md` und `proxy-sources.md`; Hinweise in `proxy-chain.md`, `storage.md`, `architecture.md`, `categories.md`, `network.md`.

Die Phase wurde einmal unterbrochen (Sitzungsende während der Quellenprüfung) und danach in derselben Sitzung fortgesetzt.

## Was jetzt da ist

Neben der Proxy-Liste der Proxy-Kette (`about:preferences#fawkes`, Gruppe „Proxy-Kette“) gibt es den Bereich **„Proxy-Scraper“**:

- Warnhinweis (öffentliche Proxys werden von Unbekannten betrieben, können mitschneiden oder Honeypots sein; Kette nur für HTTPS-Seiten nutzen) – immer sichtbar, vor der ersten Suche zusätzlich eine Bestätigung (Abbrechen ist die Standardtaste).
- **Proxy-Judge (HTTPS-URL)** – leer; ohne Judge startet der Scraper nicht, die Seite erklärt warum (siehe Entscheidungen).
- **Gesperrte Länder** (ISO-3166-Codes, Standard: die 14 Eyes US, GB, CA, AU, NZ, DK, FR, NL, NO, DE, BE, IT, ES, SE); ungültige Einträge werden angezeigt und ignoriert, „UK“ zählt als „GB“.
- **Zu durchsuchende Proxy-Listen**: eine Checkbox pro Quelle (8).
- **„Proxys suchen …“**, **„Bestehende Liste neu prüfen“**, **„Abbrechen“** (nur während eines Laufs).
- **Fortschritt** (Widget `fawkes-proxy-scraper-status`): Phase, Fortschrittsbalken, Seiten abgerufen / Proxys gefunden (davon nach Länderangabe der Seite übersprungen) / geprüft / bestanden, Zustand jeder Quelle mit Fehlergrund, am Ende das Ergebnis (bestanden, hinzugefügt bzw. Fehler).
- Am Ende werden die bestandenen Proxys (schnellste zuerst) der Liste **angehängt**, ohne Duplikate (gleicher Host und Port zählen als derselbe Proxy, auch mit Benutzernamen), unter einer Kommentarzeile `# gescrapt am <Datum>, <Anzahl> Proxys` (in der Sprache des Browsers).
- „Bestehende Liste neu prüfen“ prüft die Proxys der Liste mit denselben Kriterien (Proxys mit Zugangsdaten mit diesen) und **markiert** durchgefallene mit `# [Fawkes] <Grund>, geprüft am <Datum>` hinter dem Eintrag; nichts wird entfernt, die Markierung verschwindet, wenn der Proxy wieder besteht. Kommentare hinter Einträgen ignoriert die Proxy-Kette; markierte Proxys bleiben also nutzbar, bis Sie sie löschen. Das deckt auch den optionalen Punkt „manuell eingetragene Proxys aus gesperrten Ländern markieren“ ab.
- Der Scraper läuft **nur auf Klick**, braucht mit Tor eine bestehende Tor-Verbindung und wird **abgebrochen, wenn die Einstellungsseite geschlossen wird** („nie im Hintergrund“).

### Ablauf einer Suche (`FawkesProxyScraper.sys.mjs`)

1. GeoIP-Datenbanken von tor laden (`geoip`/`geoip6` aus dem App-Datenverzeichnis von tor über `TorLauncherUtil.getTorFile("torappdatadir")`, auch ohne Tor lesbar; in Stücken geparst). Fehlen sie, wird nichts geprüft.
2. Mit Tor: Tors SOCKS-Proxy beim Proxy-Dienst erfragen; fehlt er, wird nichts geprüft (nie direkt, solange Tor benutzt wird). Jeder Lauf nutzt **eigene SOCKS-Zugangsdaten**, also eigene Tor-Circuits.
3. **Basisabfrage beim Judge** ohne externen Proxy (mit Tor nur über Tor, ohne Tor direkt): Der Judge muss mit „200 OK“ ohne Weiterleitung über gültiges TLS antworten, die Request-Header zeigen (User-Agent und Host oder Accept), genau eine Adresse nennen und selbst keine Proxy-Header hinzufügen. Die gezeigte Adresse ist die eigene bzw. die des Tor-Exits; mit Tor wird die Abfrage nach fünf Minuten wiederholt (Exits wechseln).
4. **Listen-Seiten** nacheinander, wenige Seiten pro Quelle, mindestens 2 s Abstand. Mit Tor erzwungen über Tors SOCKS-Proxy mit eigenen Zugangsdaten je Quelle (eigener Circuit je Quelle; danach wird geprüft, dass die Seite wirklich über Tor kam), ohne Tor direkt – nie über die Proxy-Kette (First-Party-Domain `<quelle>.fawkes-scraper.mozilla`, die Fawkes ignoriert). Anonym (keine Cookies, keine Zugangsdaten), ohne Cache, mit dem normalen UA und einem festen englischen `Accept-Language` (`en-US,en;q=0.5`, wie bei resistFingerprinting). Keine Weiterleitungen, höchstens 5 MB und 60 s (ohne Tor 30 s) pro Seite. Eine ausfallende Quelle wird mit Grund angezeigt, die anderen laufen weiter.
5. **Validierung** jedes Eintrags: nur IP-Adressen in üblicher Schreibweise, Port 1–65535, keine Tor-Ports, keine privaten, lokalen oder reservierten Adressen (Klassifikator aus 5.10, `Services.fawkesNetwork.isLocalHost()`, plus die Sonderbereiche nach RFC 6890: Dokumentation, Benchmark, Multicast, 6to4, Teredo, alles außerhalb 2000::/3). Duplikate und Proxys, die schon in der Liste stehen, werden übersprungen; mit Länderangabe der Seite in einem gesperrten Land ebenfalls (nur als Vorfilter).
6. **Prüfung**, 32 gleichzeitig (Pref `fawkes.proxy.scraper.parallelChecks`, 1–64), höchstens 1000 Kandidaten pro Lauf (`…maxCandidates`).

### Die Prüfung eines Proxys (5.14, Punkte 1–6)

| Kriterium | Umsetzung |
| --- | --- |
| 6. Land der gelisteten IP | GeoIP offline; unbekannt oder gesperrt → verworfen, **bevor** irgendeine Verbindung entsteht. „EU“, „AP“, „A1“ usw. gelten als unbekannt. |
| 1. Gleicher Pfad wie im Betrieb | Dieselbe Proxy-Info wie der Ketten-Filter aus Phase 10: mit Tor Tors SOCKS-Proxy + externer Proxy über `setFawkesProxyChain()` (Necko macht beide Hops, ATYP 3 für Namen, lokal wird nichts aufgelöst), ohne Tor der Proxy selbst. Proxys, die Tor-Exits sperren, fallen mit Tor dadurch heraus. |
| 2. Echtes SOCKS5 | Drei Verbindungen zum Judge-Host über den Proxy (rohe Socket-Transports mit dieser Proxy-Info): Greeting „no auth“ und CONNECT zum Judge müssen gelingen. SOCKS4, HTTP, Proxys mit Anmeldepflicht, schließende oder stumme Proxys fallen heraus. |
| 3. Antwortzeit | Gemessen vom SOCKS-Layer der Proxy-Kette (Greeting bis Methodenantwort, nach dem Tor-Hop, Meldung `fawkes-proxy-result`); er bricht bei `fawkes.proxy.maxLatencyMs` ab (zählt dann als unendlich langsam). Der **Median der drei** muss **unter** der Schwelle liegen. Harte Grenze je Versuch 30 s (ohne Tor 15 s). |
| 4. Elite | HTTPS-Request zum Judge über den Proxy (ein temporärer Proxy-Filter setzt genau diese Proxy-Info; danach wird geprüft, dass die Antwort wirklich über diesen Proxy und mit Tor über Tor kam). Verworfen bei `Via`, `X-Forwarded-For`, `Forwarded`, `X-Real-IP`, `Proxy-Connection` (und ähnlichen wie `X-Client-IP`, `True-Client-IP`, auch als `HTTP_…`-Felder klassischer Judges), bei mehr als einer Adresse, wenn die gesehene IP die eigene oder die des Tor-Exits ist, und wenn sonst eine fremde Adresse in der Antwort steht. |
| 5. Keine Manipulation | Normale TLS-Validierung von Necko, keine Weiterleitungen. Ein Proxy mit eigenem Zertifikat oder Klartext statt Tunnel lässt den Request scheitern. |
| 6. Land der ausgehenden IP | GeoIP der vom Judge gesehenen Adresse; unbekannt oder gesperrt → verworfen. |

Abbrechen schließt sofort alle Verbindungen und Requests des Laufs; danach startet keine Prüfung mehr. Filter und Beobachter des Laufs werden am Ende entfernt.

## Quellen (live geprüft am 24.10.2026)

Geprüft wurden alle zwölf Ausgangskandidaten und zehn weitere bekannte Listen-Seiten, nur mit lesenden Abrufen: `robots.txt`, Nutzungsbedingungen (wo vorhanden) und ein Abruf der Liste bzw. des Endpunkts (zwei bei ProxyScrape wegen der Seitenaufteilung). Kein Konto, kein Captcha, keine Umgehung.

**Gewählt: 8 Quellen – weniger als 10.** Ich habe keine ungeeignete Seite aufgenommen, um auf zehn zu kommen. Rangfolge nach der Zahl angebotener SOCKS5-Einträge am Prüftag (gleichzeitig die Abrufreihenfolge):

| # | Quelle | Endpunkt | SOCKS5 | Seiten pro Lauf | Begründung |
| --- | --- | --- | --- | --- | --- |
| 1 | FreeProxy.World | HTML-Tabelle `?type=socks5&page=N` | ~10 100 | 4 | robots.txt ohne Regeln (nur Content-Signals ohne Vorgabe), keine Verbotsklausel, HTML ohne Skript. Cloudflare-Erkennungsskript eingebunden, lieferte aber ohne Challenge. |
| 2 | ProxyScrape | offizielle API v4 (JSON, `limit=2000&skip=…`) | 3 900–4 829 | 3 | FAQ erlaubt Scraping ausdrücklich und empfiehlt die freie API; robots.txt erlaubt alles; AGB betreffen nur Käufe. Mit Ländercodes. |
| 3 | ProxyHub | HTML `all-socks5-proxy-list.html?page=N` | ~2 000 | 5 | robots.txt erlaubt alles (sperrt nur SEO-Crawler namentlich), keine Verbotsklausel. |
| 4 | Geonode | API `proxylist.geonode.com/api/proxy-list` (JSON) | 1 239 | 3 | Die Listenseite bietet die API-URL ausdrücklich „for programmatic access“ an; die AGB verbieten Scraping nur, soweit es nicht „expressly permitted by the Services“ ist. Subdomain ohne robots.txt (die von geonode.com gilt nur für diesen Host). |
| 5 | ProxyDB | HTML `?protocol=socks5&offset=N` | 1 080 | 4 | Weder robots.txt noch AGB. Die Portzelle enthält versteckte Lockziffern; der Adapter liest Adresse und Port exakt aus dem Link der Zeile (keine Dekodierung). |
| 6 | ProxyListPlus | HTML `Socks-List-N` | ~450 | 3 | robots.txt sperrt nur Flaggen und zwei Aktionen; keine AGB. |
| 7 | spys.me (spys.one) | offizieller Textexport `socks.txt` | ~400 | 1 | robots.txt wünscht 10 s Abstand – ein Lauf macht einen Abruf. |
| 8 | My-Proxy.com | HTML-Textliste `ip:port#CC` | 70 | 1 | robots.txt erlaubt alles; die AGB des Betreibers (Didsoft) betreffen den Bezahldienst. |

**Verworfen:**

| Kandidat | Grund |
| --- | --- |
| free-proxy-list.net / socks-proxy.net | erlaubt, aber 0 SOCKS5-Einträge (300 SOCKS4); API nur mit Bezahlkonto |
| proxy-list.download | nicht erreichbar (Cloudflare 502) |
| OpenProxy.space | nicht erreichbar (Cloudflare 521) |
| hide.mn (HideMy.name) | robots.txt verbietet alle URLs mit Query (`Disallow: /*?`), die der SOCKS5-Filter braucht; reCAPTCHA; Export kostenpflichtig |
| advanced.name | robots.txt verbietet `/freeproxy/*` (die Seiten der Liste); reCAPTCHA-Formular |
| ProxyNova | keine SOCKS5-Liste; Adressen per Seiten-JavaScript; robots.txt sperrt die Export-Endpunkte |
| spys.one (HTML) | gleiche Liste wie der Textexport von spys.me (genutzt); Ports per JavaScript-Arithmetik verschleiert |
| free-proxy.cz | zur Prüfzeit nicht erreichbar (Timeouts); Adressen per Seiten-JavaScript (Base64) |
| iproyal.com | Liste nur per Seiten-JavaScript |
| openproxylist.xyz, proxyspace.pro | identische Textlisten inkl. ungültiger Einträge (`0.0.0.0:80`): Spiegel von GitHub-Listen |
| proxy-list.org | Liste per Seiten-JavaScript |
| fineproxy.org | robots.txt verbietet URLs mit Query (`Disallow: */?`); 2,7 MB pro Seite |
| GitHub-Listen | laut Auftrag keine „Seiten“; nur nach Rückfrage – nicht aufgenommen |

Gegenprobe der acht Parser gegen die live abgerufenen Seiten (nur im Scratchpad, nicht im Tree): FreeProxy.World 50, ProxyScrape 2 000, ProxyHub 20, Geonode 50 (mit `limit=50` abgerufen), ProxyDB 30, ProxyListPlus 50, spys.me 400, My-Proxy 70 SOCKS5-Einträge je Seite, alle mit Ländercode (bis auf 2 bei ProxyListPlus); keine Seite sah wie eine Challenge aus. Die Test-Fixtures sind dagegen **nachgebaute** Seiten mit Dokumentationsadressen (keine Kopien der echten Seiten, keine echten IPs).

Doku: `browser/components/fawkes/docs/proxy-sources.md`.

## Entscheidungen ohne Rückfrage (bitte prüfen)

1. **Quellen**: die 8 oben, weniger als 10; keine GitHub-Listen, keine Spiegel von GitHub-Listen.
2. **Kein voreingestellter Judge.** Ein Judge sieht jeden geprüften Proxy, den Zeitpunkt jeder Suche und bei der Basisabfrage den Tor-Exit bzw. ohne Tor Ihre echte IP; er kann alles einem Nutzer zuordnen. Das ist eine bewusste Entscheidung für einen Dritten, deren Logging-Praxis ich nicht prüfen kann; der Auftrag verlangt außerdem, den Standard vorher vorzuschlagen. Ohne Judge verweigert der Scraper den Start und erklärt warum. **Vorschläge** (live geprüft: zeigen Header und Adresse, fügen selbst keine Proxy-Header hinzu):
   - `https://httpbin.org/get` – JSON mit allen Request-Headern und `origin`; eine weitergeleitete Adresse erscheint dort als zweite Adresse (wird erkannt). Betrieben von Postman. **Mein Favorit.**
   - `https://echo.free.beeceptor.com/` – JSON mit Headern und `ip`. Betrieben von Beeceptor.
   - Nicht geeignet: `httpbingo.org/get` und `ifconfig.me/all.json` (fügen selbst `Via`/`X-Forwarded-For` bzw. `via`/`forwarded` hinzu – der Scraper erkennt das bei der Basisabfrage und lehnt sie ab), `ifconfig.co/json`, Cloudflare-Trace, `api.ipify.org` (keine Header), `postman-echo.com/get` (keine Adresse); azenv.net und proxyjudge.us waren nicht erreichbar.
3. **Länder**: nur die 14 Eyes als Standard. **Weitere Kandidaten (nur Vorschlag, nicht eingebaut)**: Staaten mit umfassender staatlicher Überwachung des Internetverkehrs und Zugriffspflichten für Betreiber, z. B. CN, RU, IR, KP, BY, SA, AE; die „Third Parties“ der Five Eyes mit enger SIGINT-Kooperation, z. B. JP, KR, SG, IL; Staaten mit weitreichender Vorratsdatenspeicherung. Jeder Eintrag verkleinert die Auswahl weiter; die Liste ist in den Einstellungen frei editierbar.
4. **Nur IP-Literale aus den Listen** (keine Hostnamen): das Land eines Hostnamens lässt sich ohne Auflösung nicht bestimmen, und mit Tor darf nicht lokal aufgelöst werden; unbekanntes Land = verworfen.
5. **Tor-Ports (9050, 9051, 9150, 9151) ausgeschlossen**: dort laufen fremde Tor-Clients, die Kette würde wieder aus einem Tor-Exit kommen.
6. **Reservierte Bereiche** zusätzlich zum Klassifikator aus 5.10 ausgeschlossen (RFC 6890: Dokumentation, Benchmark, Multicast, 6to4, Teredo, IPv6 außerhalb 2000::/3).
7. **Basisabfrage beim Judge** (ohne externen Proxy) zur Bestimmung der eigenen bzw. der Exit-Adresse und zur Prüfung, ob der Judge taugt (Header sichtbar, eine Adresse, keine eigenen Proxy-Header). Mit Tor alle fünf Minuten wiederholt.
8. **Elite streng**: neben den fünf genannten Headern auch verwandte (`X-Client-IP`, `True-Client-IP`, `X-Originating-IP`, …) und jede fremde Adresse in der Antwort; keine Weiterleitungen beim Judge.
9. **Eigene SOCKS-Zugangsdaten pro Lauf** für alle Prüfungen (eigene Circuits statt der von `TorDomainIsolator`) und **je Quelle** für die Listen-Abrufe; mit Tor werden beide über den Proxy-Filter des Scrapers erzwungen und hinterher kontrolliert, statt sich auf die Proxy-Einstellungen zu verlassen.
10. **Listen-Abrufe nie über die Proxy-Kette**, sondern „über den aktuellen Verbindungsmodus“ wie verlangt (interne First-Party-Domain auf `.mozilla`, die Fawkes ignoriert).
11. **Drei Greeting-Proben als eigene Verbindungen zum Judge-Host** (das CONNECT braucht ein Ziel; so kommt kein weiterer Dritter hinzu). Ein Versuch, der die Schwelle überschreitet, zählt als unendlich langsam; zwei davon beenden die Prüfung.
12. **Länderangaben der Seiten nur als Vorfilter nach dem Abruf**: Die Seiten bieten nur Filter für *ein* Land, kein Ausschließen; die eigene GeoIP-Prüfung entscheidet immer.
13. **Höflichkeit**: Quellen nacheinander, höchstens 1–5 Seiten pro Quelle, ≥ 2 s Abstand; rund 25 Abrufe pro Suche. Höchstens 1000 Kandidaten pro Lauf, 32 parallele Prüfungen.
14. **Warnung**: immer sichtbar plus Bestätigungsdialog vor der ersten Suche (Pref `fawkes.proxy.scraper.warningAccepted`).
15. **Recheck markiert** (`# [Fawkes] …`) statt zu entfernen; Proxys mit Zugangsdaten werden mit diesen geprüft.
16. **Abbruch beim Schließen der Einstellungsseite**; mit Tor ist der Start erst nach erfolgreichem Bootstrap möglich.
17. **Pref `fawkes.proxy.scraper.geoipDir`** für ein anderes GeoIP-Verzeichnis (Tests, ungewöhnliche Installationen).
18. **Keine Weiterleitungen bei Listen-Seiten** (eine Weiterleitung ersetzt den Kanal, der dann nicht mehr abgebrochen oder begrenzt werden könnte); die Adapter nennen die endgültigen URLs, eine weiterleitende Seite gilt als fehlgeschlagen.
19. **Fester englischer `Accept-Language`** für alle Requests des Scrapers, damit sie nie Ihre Sprachen zeigen; der User-Agent ist der normale des Browsers (Requests mit Systemprinzipal bekommen den gefälschten RFP-UA nicht; ob er sich vom echten unterscheidet, zeigt erst der Build – Kandidat für Phase 12).
20. **Test-Zertifikat**: `client-cert.p12` aus `netwerk/test/unit` in den Fawkes-Testordner kopiert (TLS-Judge-Mocks); in den Tests per Ausnahme für den Judge-Host vertraut.


## Geänderte Upstream-Dateien (dünne Hooks, für spätere Rebases)

| Datei | Änderung |
| --- | --- |
| `browser/components/preferences/preferences.xhtml` | eine Zeile: `<script type="module">` für das Widget `fawkes-proxy-scraper-status.mjs` (neben dem der Seitenliste aus Phase 2) |

Sonst nur neuer bzw. Fawkes-eigener Code: `toolkit/components/fawkes/FawkesProxySources.sys.mjs`, `FawkesProxyCheck.sys.mjs`, `FawkesGeoIP.sys.mjs`, `FawkesProxyScraper.sys.mjs` (+ `moz.build`); `browser/components/fawkes/content/config/fawkes.mjs`, `content/widgets/fawkes-proxy-scraper-status.mjs`, `jar.mn`, `fawkes-prefs.js`, `locales/{en-US,de}/fawkes.ftl`; Testmodule `FawkesMockJudge.sys.mjs` (neu) und `FawkesMockSocks.sys.mjs` (Optionen `forwards`, `anyCredentials`); Tests, Fixtures und Doku. Kein C++, kein IDL, keine IPC, keine Static Prefs. Die zweite Prüfung bemängelte zwei Variablennamen im Phase-10-Code der Einstellungen (`status` überdeckt ein Browser-Global); umbenannt in Commit 9.

## Prüfungen ohne Build

- **Erste Code-Prüfung durch einen separaten Prüf-Agenten** (nur lesend, gegen den Tree und Searchfox ESR 153; Bericht `audit-phase11-a.md` im Notizordner): **keine Build-Blocker**; alle verwendeten Gecko-APIs (Socket-Transport, Event-Sink, Proxy-Dienst, `setFawkesProxyChain`, `channelId`, `proxyInfo`, OA-Setter, NetUtil, IOUtils, TorLauncherUtil, TorConnect, Prompt-Dienst, Fluent DATETIME, Einstellungs-Framework, TLSServerSocket, Zertifikats-Overrides) existieren mit diesen Signaturen. Bestätigt: die Meldung `fawkes-proxy-result` kommt immer vor `STATUS_CONNECTED_TO` bzw. dem Stream-Fehler an; `STATUS_CONNECTED_TO` erst nach beiden SOCKS-Hops und dem CONNECT zum Judge; kein Pfad verbindet mit Tor ohne Tor oder löst lokal auf; Judge-Requests nutzen immer ihre Proxy-Info, kein Teilen von Verbindungen zwischen Kandidaten. 11 Befunde, alle bearbeitet (Commit 8): drei Tests wären gescheitert (der Mock-„Tor“ lehnte die Zugangsdaten des Scrapers ab; fehlender Import; Zahl „1,234 ms“ mit Tausendertrennzeichen), Weiterleitungen machten Listen-Abrufe unabbrechbar, Einstellungsfelder folgten dem Laufzustand nicht, IPv4-gemappte Judge-Adressen führten zu falschen Ablehnungen; dazu fünf kleinere (Requests nach internem Fehler, Basisabfrage auf alter Verbindung, Listen-Abrufe mit Tor jetzt erzwungen über Tor mit eigenen Zugangsdaten je Quelle, Zählung des Kandidatenlimits, echte Sprachliste im Accept-Language).
- **Zweite, fokussierte Prüfung** der Korrekturen und **aller Testaufgaben** (jede gegen Implementierung und Mocks verfolgt; Bericht `audit-phase11-b.md`): **keine Bugs**, alle xpcshell- und Browser-Testaufgaben laufen laut Nachverfolgung durch (Tabelle im Bericht); gefunden und behoben (Commit 9): vier Lint-Treffer, die in Phase 12 `./mach lint` gestoppt hätten (unbenutzter Import, `prompt`/`status` überdecken Browser-Globals, gerade Apostrophe in en-US, zwei Prettier-Fälle), eine falsche Begründung in Kommentar/Doku, mögliche Flakiness durch Neckos Backup-Verbindungen in den Tests, die „Limit erreicht“-Anzeige.
- **Eigene Prüfungen**: die acht Parser gegen die live abgerufenen Seiten (siehe Quellen); Regeln, Judge-Auswertung und GeoIP in Node (über 60 Prüfungen); die **Engine selbst in Node mit nachgebauten XPCOM-Objekten** (neuer Harness `fawkes-tools/scraper-node/`: Recheck mit 15 Fällen, Suche mit Seitenabstand, Duplikaten, Vorfilter, Quellenfehler, Kandidatenlimit, Abbruch ohne weitere Requests, Betrieb ohne Tor, Fehler bei fehlendem Tor-Proxy/Judge/GeoIP) – fehlerfrei.
- `node --check` für alle neuen/geänderten JS/MJS-Dateien; TOML beider Manifeste mit `tomllib`; Fluent (`fluent.syntax`): en-US und de je 170 Nachrichten, keine Fehler, gleiche Attribute; keine geraden Apostrophe in en-US; 80 Spalten (Ausnahme: lange URLs/Imports, wie sonst auch).
- `./mach lint` nicht ausgeführt (braucht Bootstrap, Phase 12). Keine `__pycache__`/`parser.out`-Reste im Tree.

## Tests (geschrieben, laufen erst in Phase 12)

| Anforderung (Abschnitt 8) | Test |
| --- | --- |
| Parser-Tests je Quelle mit gespeicherten Fixtures, ohne echte Seiten | xpcshell `test_fawkes_proxy_sources.js` + `data/proxy-sources/` (je Quelle eine nachgebaute Seite, Challenge-Seite, Müll) |
| echter SOCKS5-Elite-Proxy besteht | `test_fawkes_proxy_scraper.js` (mit Tor, zwei Hops über Mock-„Tor“) und `test_fawkes_proxy_scraper_direct.js` (ohne Tor, ein Hop) |
| langsamer Proxy > 1 s / Schwelle | beide (Greeting-Verzögerung 1,5 s bei Schwelle 0,5 s) |
| nur SOCKS4, HTTP-Proxy, Anmeldepflicht | `test_fawkes_proxy_scraper.js` |
| Proxy mit `X-Forwarded-For`, weitergeleitete/eigene/fremde Adresse | `test_fawkes_proxy_scraper.js` (TLS-Judge-Mocks je Verhalten) + Regeltest |
| Proxy mit TLS-Manipulation | `test_fawkes_proxy_scraper.js`: Proxy antwortet im Klartext statt zu tunneln → TLS-Fehler; Judge mit ungültigem Zertifikat → Lauf verweigert |
| private IPs in Listen | Regeltest (Klassifikator + reservierte Bereiche) und Scrape-/Recheck-Test (nie kontaktiert) |
| gelistete oder ausgehende IP in gesperrtem Land, unbekanntes Land (GeoIP aus Test-Fixture) | `test_fawkes_proxy_scraper.js` + Regeltest (`head_scraper.js` schreibt `geoip`/`geoip6` ins Profil) |
| Duplikatentfernung beim Übernehmen | Regeltest (`appendProxies`) und Scrape-Test |
| Abbrechen stoppt alle Requests | `test_cancel_stops_everything`: nach dem Abbruch keine Greetings/Verbindungen mehr, Warteschlange nie kontaktiert |
| kein Judge / ungeeigneter Judge / kein Tor-Proxy / kein GeoIP | `test_fawkes_proxy_scraper.js` |
| Einstellungen | browser-chrome `browser_fawkes_proxy_scraper.js` (Warnung, Judge-Pflicht, Länder, Quellen, Bestätigungsdialog, Anhängen mit Kommentarzeile, Markieren beim Recheck, echter Lauf ohne GeoIP) |

## Grenzen (auch in `proxy-scraper.md`)

- Seiten ändern Layout und Regeln. Ein Adapter kann brechen oder eine Seite beginnen zu blockieren (gerade über Tor zeigen Cloudflare-Seiten oft Challenges); die Quelle erscheint dann als fehlgeschlagen und sollte vor einer Reparatur erneut gegen robots.txt/AGB geprüft werden.
- GeoIP ordnet Adressbereiche zu, nicht Betreiber; die Daten sind so alt wie das tor-Paket. Beide Adressen werden geprüft, ein Betreiber kann aber für anderen Verkehr eine dritte Adresse nutzen.
- Mit Tor wählt Tor den Exit je Zielport; der Exit zum Proxy kann ein anderer sein als bei der Basisabfrage. Ein Proxy, der die Exit-Adresse in die Antwort schreibt, fällt trotzdem auf (als Proxy-Header oder fremde Adresse); einer, der selbst auf der Adresse des Exits läuft, nicht.
- Bestehen sagt nichts über den Betreiber; ein Proxy kann später ausfallen oder mitschneiden.
- Die Greeting-Zeit über Tor enthält eine Circuit-Rundreise; mit dem Standard 1000 ms fallen mit Tor viele Proxys durch. Die Schwelle gilt auch für die Proxy-Kette.
- Hostnamen in der eigenen Liste lassen sich nicht auf ihr Land prüfen und werden beim Recheck markiert.
- Leitet eine Listen-Seite künftig weiter (Host- oder Pfadwechsel), schlägt die Quelle fehl, bis ihr Adapter angepasst ist.
- Mit separatem Socket-Prozess (in Firefox Desktop aus) kommen die Greeting-Zeiten nicht an; dann fiele jeder Proxy durch.
- Die Fortschrittsanzeige zählt Proxys, die nur wegen der Länderangabe der Seite übersprungen wurden, als „gefunden“, aber nicht als „geprüft“.
- Der Code ist (wie alle Phasen) nie kompiliert und nie im Browser ausgeführt worden.

## Manuelle Prüf-Checkliste (Phase 12)

Vorher `fawkes.debug` an; für das Protokoll `MOZ_LOG=SOCKS:5,FawkesProxyChain:5`. Die Warnungen zu öffentlichen Proxys gelten.

1. **Einstellungen**: `about:preferences#fawkes` → Proxy-Kette → Proxy-Scraper: Warnung sichtbar, Judge leer, „Proxys suchen …“ gesperrt mit Erklärung; 14 Eyes in der Länderliste; 8 Quellen angehakt.
2. Judge eintragen (z. B. `https://httpbin.org/get`), „Proxys suchen …“ → Bestätigungsdialog (Abbrechen ist Standard) → bestätigen.
3. **Live-Lauf mit Tor**: Fortschritt beobachten; notieren: Seiten abgerufen, Proxys gefunden, davon nach Länderangabe übersprungen, geprüft, bestanden; Zustand jeder Quelle (welche scheitern über Tor an Challenges?). Erwartung: Liste bekommt `# gescrapt am …, N Proxys` und N Zeilen ohne Duplikate.
4. Mit `about:networking#dns`: keine Namen der Listen-Seiten oder des Judge lokal aufgelöst.
5. **Abbrechen** während eines Laufs: Anzeige „Abgebrochen“, Liste unverändert; in `about:networking#sockets` keine neuen Verbindungen zu Proxys mehr.
6. **Einstellungsseite schließen** während eines Laufs: Lauf endet (beim Wiederöffnen kein laufender Fortschritt).
7. **„Bestehende Liste neu prüfen“**: tote/langsame Einträge tragen `# [Fawkes] …`, nichts wird gelöscht; ein `192.0.2.1:1080` bekommt „lokale Adresse“.
8. Bestandene Proxys mit der Proxy-Kette nutzen: Kette für eine IP-Anzeige-Site einschalten → angezeigte IP ist die des Proxys, Land nicht in der Sperrliste.
9. **Ohne Tor** (Direktmodus) dasselbe; der Judge sieht bei der Basisabfrage Ihre echte IP (dokumentiert).
10. Ungeeigneter Judge (z. B. `https://httpbingo.org/get`): Ergebnis „fügt selbst Proxy-Header hinzu“, nichts geprüft.
11. GeoIP fehlt (Pref `fawkes.proxy.scraper.geoipDir` auf ein leeres Verzeichnis): Ergebnis „GeoIP-Datenbanken nicht gefunden“, nichts geprüft.

**Ergebnis eines manuellen Live-Laufs (gefunden / geprüft / bestanden):** konnte ich nicht ermitteln – ein Live-Lauf braucht den gebauten Browser (Phase 12), und die Prüf-Requests an öffentliche Proxys und einen Judge gingen über reine Lesezugriffe auf die Listen-Seiten hinaus. Bitte die Zahlen aus Punkt 3 eintragen. Als Anhaltspunkt für „gefunden“: Die acht Quellen boten am 24.10.2026 zusammen rund 20 000 SOCKS5-Einträge an; ein Lauf liest davon wegen der Seitenlimits höchstens etwa 8 500 und prüft höchstens 1 000 neue (nach Duplikaten und Länder-Vorfilter).


## Anwendungsprobe

Index-Probe (temporärer Index, `git read-tree fawkes-base`, dann `git apply --cached` in Phasenreihenfolge; Skript `fawkes-tools/probe.sh`, jetzt bis Phase 11):

- Sammeldateien: `phase-01-branding.patch` bis `phase-11-proxy-scraper.patch` bestehen `git apply --check` und ergeben den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`), `fawkes-phase-02` (`ded25fd99f13`), `fawkes-phase-03` (`aa18953cfa4f`), `fawkes-phase-04` (`dd9f9ead8e67`), `fawkes-phase-05` (`33768452f3ad`), `fawkes-phase-06` (`6d56d5b6daa0`), `fawkes-phase-07` (`2778b279eddb`), `fawkes-phase-08` (`3c07fd7ad1f2`), `fawkes-phase-09` (`cd5a108f697d`), `fawkes-phase-10` (`e128037d632e`) bzw. `fawkes-phase-11` (`91cb3fe28a4e`).
- Serien: alle Patches aus `phase-01-branding/` (6), `phase-02-framework/` (7), `phase-03-no-tor/` (8), `phase-04-network/` (9), `phase-05-js-apis/` (10), `phase-06-css/` (8), `phase-07-profiling/` (9), `phase-08-randomization/` (12), `phase-09-cookie-banners/` (10), `phase-10-proxy-chain/` (10) und `phase-11-proxy-scraper/` (9) lassen sich anwenden und ergeben exakt den Tree von `fawkes-phase-11` (`91cb3fe28a4e`).
- **Ergebnis: grün.**

Die Probe mit `git am` im Prüf-Worktree entfällt weiterhin auf Ihren Wunsch (über sshfs zu langsam).

Phase 11 ändert tor-browser-build nicht.

## Hinweise für Phase 12

- Neue Tests siehe oben; sie brauchen keine echten Netzzugriffe (Mock-SOCKS5-Server, TLS-Judges auf 127.0.0.1 mit `client-cert.p12` und Zertifikats-Ausnahme für `judge.test:<Port>`, lokale Listen-Seite über httpd.js). Der Browser-Test ersetzt `FawkesProxyScraper.run` mit sinon; ein Lauf bricht dort absichtlich an fehlenden GeoIP-Daten ab.
- Beim ersten `./mach lint` die Phase-11-Dateien mit `--fix` formatieren lassen (Prettier wurde nicht ausgeführt; die zweite Prüfung fand zwei Fälle von Hand, es kann mehr geben).
- Für einen Live-Lauf mit dem gebauten Browser: `geoip`/`geoip6` müssen im App-Datenverzeichnis von tor liegen (bei einem `mach`-Build ohne tor-Paket ggf. fehlend → Pref `fawkes.proxy.scraper.geoipDir` auf ein Verzeichnis mit den Dateien aus einem Tor-Browser-Paket setzen).
- Der Helfer `fawkes-tools/scraper-node/` führt die Engine ohne Build aus (nützlich, falls Tests scheitern).
- Umgebung: Die lokale Platte hat nur noch ~18 GB frei (zu wenig für ein objdir), das sshfs-Volume ~134 GB.

