# Phase 8 – Fingerprinting-Randomisierung + Englisch: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-07` = `c6f3f412a55b`, Tag `fawkes-phase-08` = `2103af28de15`, Tree `3c07fd7ad1f2`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `dbb769fcee8f` | Fawkes: Do not dereference the result of nsIChannel::LoadInfo() (Korrektur von Phase-2-Code) |
| 2 | `82f9ff010be8` | Fawkes: Keep a session key for the fingerprint randomization |
| 3 | `cc0bdc6415f8` | Fawkes: Randomize canvas, WebGL and audio per site |
| 4 | `d1aad7ed5746` | Fawkes: Randomize the screen and the window per site |
| 5 | `0c4b864ae7be` | Fawkes: Randomize device values, fonts and element boxes per site |
| 6 | `ccc9d8ac043b` | Fawkes: Use English, a random user agent and time zone per site |
| 7 | `488de2ab1d73` | Fawkes: Import TestUtils and AppConstants in the xpcshell tests (Korrektur der Testbasis von Phase 2/4) |
| 8 | `121676885b4f` | Fawkes: Test the fingerprint randomization |
| 9 | `9e5364ade6fd` | Fawkes: Use canonical time zones for the randomization |
| 10 | `923c18c135f4` | Fawkes: Document the fingerprint randomization |
| 11 | `3e7f9de4af48` | Fawkes: Harden the fingerprint randomization (Schriften auf Style-Threads, Worker, Zoom-Rundung) |
| 12 | `2103af28de15` | Fawkes: Fix the findings of the randomization review (Befunde der Code-Prüfung) |

Patches: `fawkes-patches/phase-08-randomization/` (12 Dateien) und `fawkes-patches/phase-08-randomization.patch`.
Plan: `/home/dh/.claude/plans/fawkes-phase-08.md` (ohne Rückfrage umgesetzt, wie vereinbart).
Technische Doku: `browser/components/fawkes/docs/randomization.md`; Tabelle in `categories.md`, Hinweise in `architecture.md`, `css.md`, `js-apis.md`, `network.md`, `storage.md`.

## Was jetzt da ist

Der Schalter `fpRandomize` („Fingerprinting-Randomisierung (Sprache immer Englisch)“, Gruppe Privatsphäre, Standard aus) wirkt jetzt in der Engine. Statt der konstanten Werte von resistFingerprinting (RFP), die alle Tor-Browser-Nutzer gleich zeigen, bekommt eine Site zufällige, aber deterministische Werte: stabil auf der Site (Reload, neue Tabs, andere Hosts derselben eTLD+1), verschieden zwischen Sites, neu nach Neustart oder „New Identity“. Die Sprache ist dabei immer Englisch. Kein eingeschleustes JavaScript, keine Erweiterung; betroffen ist nur Web-Inhalt.

### Schlüssel und Transport

- `FawkesService` erzeugt je einen Sitzungsschlüssel für normales und privates Surfen (32 Zufallsbytes, nur im Speicher, erst wenn die erste Site ihn braucht). Der Schlüssel einer Site ist `HMAC-SHA256(Sitzungsschlüssel, Origin-Attribute ohne Partition + Site)` plus die 8-Byte-Markierung `FawkesRK`.
- Transport über die vorhandene RFP-Infrastruktur statt einer zweiten: `AntiTrackingUtils::UpdateAntiTrackingInfoForChannel` erzeugt für jedes Top-Level-Dokument den Schlüssel der RFP-Canvas-Randomisierung und ruft danach `FawkesService::UpdateRandomizationKey()`, das ihn bei Sites mit `fpRandomize` durch den Site-Schlüssel ersetzt. Er steckt im `fingerprintingRandomizationKey` der Cookie-Jar-Settings und erreicht so den Content-Prozess, Iframes (auch Drittanbieter-Iframes, über `LoadInfo` → `CookieJarSettings::Clone`), Dedicated-, Shared- und verschachtelte Worker und alle Requests der Seite. Ein Schlüssel, den ein früherer Redirect-Schritt für eine andere Site bekam, wird durch Zufallsbytes ersetzt.
- Alle Werte werden in `toolkit/components/fawkes/FawkesRandomize.{h,cpp}` aus dem Site-Schlüssel abgeleitet: verschlüsselter SipHash (`HashCodeScrambler`) je Wert-Label über gewichtete Listen, für Rects/Textmetriken ein verschlüsselter Hash des Werts, für Audio ein XorShift-Strom. Der Parent leitet die HTTP-Werte aus demselben Schlüssel ab; `Services.fawkes.getRandomizedProfile(site, privat)` zeigt sie als JSON (Tests, Fehlersuche).
- `Services.fawkes.resetSession()` verwirft alle Schlüssel und meldet `fawkes-session-reset`; „New Identity“ ruft es in `clearState()` auf (`newidentity.js`, Schritt `clearFawkesSession()`), bevor das neue Fenster öffnet. Das Ende der privaten Sitzung (`last-pb-context-exited`) erneuert nur den privaten Schlüssel. Die Site-Einstellungen in `fawkes-sites.json` bleiben.
- Service Worker (in Tor Browser abgeschaltet) bekommen Schlüssel, Englisch und Zeitzone der Site in `ServiceWorkerPrivate::Initialize`.

### Randomisierte Werte

Die Listen gehören zur echten Betriebssystemfamilie (Windows, macOS, Linux; auf Android nur Rauschen und Sprache), damit User-Agent, `navigator.platform`/`oscpu`, Schriften, Formularelemente und Tastenkürzel zusammenpassen.

| Was | Werte | Hooks |
|---|---|---|
| Canvas-Auslesen (`toDataURL`, `toBlob`, `getImageData`, `OffscreenCanvas`, WebGL `readPixels`) | RFP-Pixelrauschen mit dem Site-Schlüssel statt Platzhalter und Canvas-Abfrage | `CanvasUtils::ImageExtractionResult` |
| `measureText()` | Rauschen < 1/256 px auf gebrochenen Werten | `CanvasRenderingContext2D::MeasureText` |
| WebGL | `RENDERER`, `UNMASKED_RENDERER/VENDOR_WEBGL` aus einer Liste im Format von Firefox' bereinigten Strings; einige optionale Erweiterungen fehlen auf einem Drittel der Sites | `ClientWebGLContext` |
| Audio | `OfflineAudioContext`-Ergebnis × (1 ± 2·10⁻⁶), `AnalyserNode`-Float-Daten | `AudioDestinationNode`, `AnalyserNode` |
| Bildschirm/Fenster | übliche Bildschirmgröße (die nächstgrößere, wenn das letterboxte Fenster nicht passt), verfügbare Fläche ohne Taskleiste/Dock/Panel, Browser-Rahmen, Fensterposition (60 % maximiert), `devicePixelRatio`, Farbtiefe 24/30, alles zoomabhängig; `screen.orientation`, Bildschirmkoordinaten von Maus-Events | `nsScreen`, `nsGlobalWindowOuter/Inner`, `ScreenOrientation`, `MouseEvent` |
| CSS | `device-width/-height`, `device-aspect-ratio`, `resolution`, `color`, `color-gamut` aus demselben Bildschirm | `nsMediaFeatures.cpp` |
| Geräte | `hardwareConcurrency` (Fenster + Worker), `maxTouchPoints`, Kamera nur auf 60 % der Sites (außer die Seite darf die Kamera schon nutzen) | `Navigator`, `WorkerNavigator`, `MediaDevices` |
| Schriften | ein Viertel der per Name angefragten Familien ist für die Site verborgen (außer gängigen Web- und den Standard-/Emoji-Schriften) | `gfxFontGroup::AddPlatformFont` |
| `getBoundingClientRect`/`getClientRects` (Elemente, Ranges) | Rauschen < 1/256 px auf gebrochenen Werten, nur für Skripte der Seite | `Element.cpp`, `AbstractRange.cpp` |
| User-Agent/Plattform | RFP-User-Agent mit einem OS-Token der echten Familie (Linux / Ubuntu / Fedora; Windows 64- oder 32-Bit), `oscpu` passend; Header, `navigator` in Fenster und Worker | `Navigator`, `WorkerNavigator`, `FawkesNetwork.cpp` |
| Zeitzone | kanonische IANA-Zone statt RFP-UTC in `Date`, `Intl`, `document.lastModified`; Fenster, Worker, Worklets | `nsGlobalWindowOuter`, `WorkerPrivate`, `WorkletImpl`/`WorkletGlobalScope`, `Document` |
| Sprache | Englisch (siehe unten) | |

**Englisch:** `Accept-Language: en-US,en;q=0.5` für alle Requests der Site (im Parent), `navigator.language(s)` = `en-US`, `en` (Fenster und Worker, Sprachwechsel des Nutzers erreichen diese Worker nicht), `JSLocale` von RFP für das Dokument erzwungen → `Intl`-Standardlocale `en-US`, Datums-/Zahlenformate, englische Engine-Strings (Formular-Validierung, XML-Fehlerseiten usw.); Worker über die Load-Info, Worklets über ihre Realm-Optionen.

**Vorrang (entschieden):** Googlebot-UA > Blockier-Schalter > Randomisierung > RFP > echter Wert. `js.canvas` → Platzhalter, `js.audio` → kein Rauschen, `js.device` → RFP-Gerätewerte, `css.mediaQueries` → Bildschirm/Fenster/dpr/Farbtiefe bleiben RFP **auch in JavaScript** (damit Skripte und Media-Queries übereinstimmen), `googlebotUA` → Googlebot-Werte (Sprache bleibt Englisch).

## Entscheidungen ohne Rückfrage (bitte prüfen)

1. **Transport über den RFP-Schlüssel statt eines eigenen Felds.** Der Site-Schlüssel ersetzt bei Sites mit `fpRandomize` den Schlüssel der RFP-Canvas-Randomisierung in den Cookie-Jar-Settings. So brauchen Iframes, Worker, Shared Worker und Requests keinen neuen IPC-Weg, und das vorhandene Canvas-/WebGL-Rauschen (`nsRFPService::RandomizeElements`) arbeitet unverändert mit dem Fawkes-Schlüssel. Der Sitzungsschlüssel gehört `FawkesService` (Abschnitt 3.1), nicht `nsRFPService`; die 8-Byte-Markierung `FawkesRK` unterscheidet die beiden Schlüssel (Schriften und WebGL prüfen vorher die Fawkes-Flags ihres Dokuments bzw. Workers). RFP liest nur die ersten 24 Bytes bzw. hasht den ganzen Schlüssel, die Länge 40 stört nicht. Ein Schlüssel, den ein früherer Redirect-Schritt für eine andere Site bekam, wird durch Zufallsbytes ersetzt.
2. **Vorrang:** Googlebot-UA > Blockier-Schalter > Randomisierung > RFP > echter Wert, wie in den Phasen 5/6 vorgeschlagen. Bei `css.mediaQueries` bleibt nicht nur CSS, sondern auch der JavaScript-Bildschirm bei den RFP-Werten – sonst widersprächen sich `screen.width` und `device-width`.
3. **Betriebssystemfamilie bleibt echt.** Der User-Agent variiert nur innerhalb der echten Familie (Linux: „X11; Linux x86_64“, „X11; Ubuntu; Linux x86_64“, „X11; Fedora; Linux x86_64“; Windows: 64-Bit oder `WOW64`; macOS: nur der eine RFP-Token). Ein fremdes Betriebssystem wäre an Schriften, Scrollbalken, Formularelementen und Tastenkürzeln sofort zu erkennen (RFP-Begründung) und würde Tastenkürzel brechen. Die Firefox-Version bleibt die von RFP (Feature-Detection würde eine andere verraten).
4. **Nur plausible Werte aus festen Listen, nie echte Werte.** Alle randomisierten Werte stammen aus festen Listen oder sind Rauschen auf Werten, die die Seite ohnehin sieht. RFP wird damit nur dort ersetzt, wo der Schalter es verlangt (Liste in `randomization.md`), und es werden keine von RFP verborgenen echten Systemwerte sichtbar.
5. **Sprachstimmen bleiben leer (RFP-Wert).** Gefälschte Stimmen gehen nicht (sie müssten im Sprachsynthese-Dienst registriert sein), und eine zufällige Teilmenge der echten Stimmen würde installierte Sprachpakete verraten – im Widerspruch zum erzwungenen Englisch. Abweichung von der Auftragsliste, dokumentiert.
6. **Mediengeräte:** RFP zeigt je eine Kamera, ein Mikrofon, einen Lautsprecher (echt oder gefälscht); die Randomisierung entfernt die Kamera auf 40 % der Sites. Ohne WebRTC im Build (`--disable-webrtc`, Phase 5) und mit `blockWebRTC` als Standard ist `navigator.mediaDevices` ohnehin meist nicht da.
7. **Schriften: Verbergen statt Metrik-Rauschen im Layout.** Rauschen auf Layout-Metriken würde Seiten brechen. Stattdessen ist ein Viertel der per Name angefragten Familien für die Site verborgen (deterministisch je Site), außer einer festen Liste gängiger Web-, Standard- und Emoji-Schriften. Generische Familien, Web-Fonts und der Zeichen-Fallback bleiben, Text wird also weiter dargestellt. Der Hook sitzt in `gfxFontGroup::AddPlatformFont` (pro Dokument), nicht in den gecachten Plattform-Font-Listen, damit nichts zwischen Dokumenten durchsickert. Zusätzlich bekommt `measureText()` Rauschen.
8. **Rect-Rauschen nur auf gebrochenen Werten und nur für Skripte der Seite.** Ganzzahlige Größen, die Seiten selbst setzen, bleiben exakt; Browser-Code (Prüfung über den aufrufenden JS-Kontext) und Layout sehen die echten Werte. Größe < 1/256 CSS-Pixel – für Seiten unsichtbar, für Hashes über Text-Geometrie aber neu.
9. **Bildschirmmodell:** Der Bildschirm ist eine übliche Größe der Plattform, die größer als das letterboxte Fenster plus Rahmen und Taskleiste ist (sonst die nächstgrößere der Liste); Fensterposition, Rahmen, Taskleiste und Pixelverhältnis sind ebenfalls aus Listen. Damit stimmen `screen`, `outerWidth`, `screenX`, `mozInnerScreenX`, die Bildschirmkoordinaten von Maus-Events, `devicePixelRatio` und die Media-Queries überein, auch bei Zoom. Auf Android bleibt RFP (mobile Bildschirme, kein Letterboxing).
10. **Zeitzone aus einer Liste kanonischer IANA-Zonen** (USA, Kanada, Westeuropa, Australien, UTC und RFPs Reykjavik), keine Verknüpfungsnamen, damit `Intl` genau den gewählten Namen meldet. HTTP überträgt keine Zeitzone; `document.lastModified` folgt der Zone. Ein Zeitzonen-Override der Entwicklerwerkzeuge gewinnt.
11. **Englisch auch für skriptgesetztes `Accept-Language`.** Der Parent setzt den Header für alle Requests der Site; ein Wert, den ein Skript selbst setzt, wird ersetzt (einfacher und sicherer als zu unterscheiden).
12. **Audio:** Rauschen auf dem Ergebnis von `OfflineAudioContext` (die verbreitete Fingerprinting-Methode) und den Float-Daten von `AnalyserNode`. Abtastrate und Latenzen bleiben die von RFP (eine andere Abtastrate würde den echten Audio-Pfad ändern).
13. **WebGL-„Parameter“:** Die Grenzwerte (MAX_TEXTURE_SIZE usw.) bleiben die minimalen RFP-Werte – größere Werte wären nicht ehrlich nutzbar und würden Seiten brechen, kleinere gibt es nicht. Stattdessen variiert die Liste der optionalen Erweiterungen (Texturkompression, anisotrope Filterung, Timer-Queries u. a.; je ein Drittel der Sites ohne).
14. **Eigene Sitzungsschlüssel für normales und privates Surfen** (Befund der Code-Prüfung): Der Site-Schlüssel enthält zusätzlich die Origin-Attribute ohne Partition (privat ja/nein, Container), damit eine Site privates und normales Surfen nicht verknüpfen kann; das Ende der privaten Sitzung (`last-pb-context-exited`) erneuert nur den privaten Schlüssel, „New Identity“ beide. In Tor Browser (immer privat) ändert das nichts Sichtbares.
15. **Kein Reset auf `new-identity-requested`** (Befund der Code-Prüfung): Das Topic kommt erst, nachdem New Identity das neue Fenster geöffnet hat; der explizite Aufruf in `clearState()` davor genügt und vermeidet, dass eine Startseite im neuen Fenster mit altem Schlüssel neue Header bekommt.
16. **Korrekturen früherer Phasen (eigene Commits):** `ComputeDocumentFlags` (Phase 2) dereferenzierte das `already_AddRefed` von `nsIChannel::LoadInfo()` – Compile-Fehler; die xpcshell-Tests von Phase 2/4 nutzten `TestUtils` ohne Import.

## Geänderte Upstream-Dateien (dünne Hooks, für spätere Rebases)

| Datei | Änderung |
| --- | --- |
| `toolkit/components/antitracking/AntiTrackingUtils.cpp` | nach dem RFP-Schlüssel `FawkesService::UpdateRandomizationKey()` |
| `browser/components/newidentity/content/newidentity.js` | `clearFawkesSession()` → `Services.fawkes.resetSession()` |
| `dom/canvas/CanvasUtils.cpp` | `ImageExtractionResult` (Element, OffscreenCanvas) → `Randomize` |
| `dom/canvas/CanvasRenderingContext2D.cpp` | `MeasureText` → `AddTextMetricsNoise` |
| `dom/canvas/ClientWebGLContext.cpp` | `GetParameter` (RENDERER, UNMASKED_*), `IsExtensionForbiddenForCaller` |
| `dom/media/webaudio/AudioDestinationNode.cpp`, `AnalyserNode.cpp` | Audio-Rauschen |
| `dom/base/nsScreen.cpp`, `nsGlobalWindowOuter.cpp`, `nsGlobalWindowInner.cpp`, `ScreenOrientation.cpp`, `dom/events/MouseEvent.cpp` | Bildschirm, Fenster, `devicePixelRatio`, Orientierung, Maus-Bildschirmkoordinaten; Realm-Zeitzone (`nsGlobalWindowOuter`), keine `languagechange`-Events (`nsGlobalWindowInner`) |
| `layout/style/nsMediaFeatures.cpp` | `device-*`, `resolution`, `color`, `color-gamut` |
| `layout/base/nsPresContext.{h,cpp}` | Viewport-Größe auch bei `fpRandomize`; `FawkesFlags()` |
| `toolkit/components/resistfingerprinting/FontVisibilityProvider.h`, `dom/canvas/OffscreenCanvas.{h,cpp}`, `dom/workers/WorkerPrivate.h` | virtuelles `FawkesFlags()` |
| `gfx/thebes/gfxTextRun.cpp` | `AddPlatformFont` → `HidesFontFamily` |
| `dom/base/Element.cpp`, `dom/base/AbstractRange.cpp` | Rect-Rauschen |
| `dom/base/Navigator.cpp`, `dom/workers/WorkerNavigator.cpp` | `hardwareConcurrency`, `maxTouchPoints`, `userAgent`, `oscpu`, `languages` |
| `dom/media/MediaDevices.cpp` | Kamera je Site |
| `dom/base/Document.cpp` | `ShouldResistFingerprinting` → `ForcesResistFingerprinting` (JSLocale), `lastModified` in der Zeitzone |
| `dom/workers/WorkerPrivate.cpp` | Englisch/Zeitzone in der Load-Info, `forceUTC`, keine Sprachwechsel |
| `dom/worklet/WorkletImpl.{h,cpp}`, `WorkletGlobalScope.cpp` | Zeitzone und Englisch in Worklets |
| `dom/serviceworkers/ServiceWorkerPrivate.cpp` | Schlüssel, Englisch, Zeitzone für Service Worker |

Neuer Code: `toolkit/components/fawkes/FawkesRandomize.{h,cpp}`; Erweiterungen in `FawkesService.{h,cpp}` (Sitzungsschlüssel, Observer), `nsIFawkesService.idl` (`resetSession()`, `getRandomizedProfile(site, private)`), `FawkesNetwork.cpp` (User-Agent, Accept-Language), `FawkesFlags.cpp` (Korrektur), `moz.build`; `browser/components/fawkes/` (Tests, Doku).

## Prüfungen ohne Build

- **Code-Prüfung durch einen separaten Prüf-Agenten** (nur lesend, gegen die Header des Trees und Searchfox ESR 153; Bericht im Scratchpad `audit-phase08.md`): ein Build-Blocker (`Document::GetPresContext()` ist nur in `DocumentInlines.h` definiert) und fünf wahrscheinliche Logikfehler (ein Schlüssel für normales und privates Surfen, dreifacher Reset bei New Identity mit Reset nach dem neuen Fenster, Service Worker ohne Randomisierung, Viewport-Größe ohne RFP/veraltet, Kamera trotz Berechtigung entfernt) plus sechs kleinere Punkte – alle in Commit 12 behoben bzw. als Grenze dokumentiert (Aufheben von DevTools-Overrides). Alle verwendeten APIs, Signaturen, Überladungen, Unified-Build-Namen, `constexpr`-Tabellen und die Verträglichkeit des 40-Byte-Schlüssels mit RFP wurden bestätigt; keine GC-Hazards. Gezielte Suche in den Phasen 1–7: keine weiteren `LoadInfo()->`- oder `GetOwnerGlobal()`-Fehler.
- Eigene Prüfung fand vorher schon den Phase-2-Fehler `channel->LoadInfo()->…` (Commit 1) und fehlende `TestUtils`-Importe in den xpcshell-Tests (Commit 7).
- **XPIDL-Parser**: `nsIFawkesService.idl` erzeugt `ResetSession()` und `GetRandomizedProfile(const nsACString&, bool, nsACString&)`, passend zur Implementierung.
- WebIDL, Static Prefs, ErrorList, FTL: in dieser Phase unverändert.
- `node --check` für alle neuen/geänderten Tests, die Testseite (Inline-Skript), den Worker, die `.sjs`-Dateien, `newidentity.js`; `browser.toml`/`xpcshell.toml` mit `tomllib` geparst, alle `head`- und `support-files`-Pfade existieren.
- 80 Spalten in neuem Code; keine `__pycache__`/`parser.out`-Reste.
- `./mach lint` nicht ausgeführt (braucht Bootstrap, Phase 12).

## Grenzen (auch in `randomization.md`)

- Die Listen sind kurz, viele Nutzer teilen jeden Wert; Betriebssystemfamilie, Firefox-Version und der letterboxte Viewport bleiben echt. Eine Site, die Fawkes kennt, kann erkennen, dass ein Profil randomisiert ist (z. B. eine Bildschirmgröße, die nicht zur Letterbox-Rundung passt) – sie kann es aber nicht mit anderen Sites verknüpfen.
- Innerhalb einer Sitzung erkennt eine Site wiederkehrende Besuche an den stabilen Werten (gewollt: „stabil innerhalb einer Domain“); New Identity beginnt neu.
- Vor New Identity geladene Seiten behalten den alten Schlüssel (New Identity schließt sie). Nach einem Schalterwechsel nutzen schon geladene Seiten bis zum Neuladen die alten Werte, ihre Requests aber schon die neuen Header (das Menü lädt neu).
- Im Vollbild sind Bildschirm, verfügbare Fläche und Fenster gleich dem Viewport (wie bei echtem Vollbild); Pixelverhältnis und Farbtiefe bleiben randomisiert.
- Rect-Rauschen deckt `getBoundingClientRect()`/`getClientRects()` ab, nicht `offsetWidth`, `scrollWidth`, berechnete Stile, IntersectionObserver-Einträge; nur gebrochene Werte.
- Schriften: Der Zeichen-Fallback findet verborgene Familien weiterhin (nötig zur Darstellung); `local()` verbergen nur `css.localFonts`/`js.fonts`; welche Sprachpaket-Schriften RFP zulässt, hängt weiter von den echten Sprachen des Nutzers ab.
- Audio-Rauschen nicht auf `ScriptProcessorNode`-/`AudioWorklet`-Eingängen und Byte-Daten von `AnalyserNode` (dafür `js.audio`).
- Zeitzonen- und Sprach-Overrides der Entwicklerwerkzeuge gewinnen; wird ein solcher Override aufgehoben, gelten bis zum Neuladen Systemzeitzone und -locale.
- Ein von Skripten gesetztes `Accept-Language` wird durch Englisch ersetzt.
- Android: Bildschirm/Fenster bleiben RFP; Rauschen, Geräte, User-Agent (RFP-Token), Zeitzone, Englisch wirken.
- Der Code ist (wie alle Phasen) nie kompiliert; die Prüfung erfolgte von Hand, mit einem Prüf-Agenten und Parsern (siehe unten).

## Tests (geschrieben, laufen erst in Phase 12)

| Anforderung (Abschnitt 8) | Test |
| --- | --- |
| stabil innerhalb einer Domain, verschieden zwischen Domains | `browser_fawkes_randomize.js`: gleiche Werte nach erneutem Laden und auf `test1.example.com`, wiederholtes Auslesen gleich (Fenster + Worker); Canvas, Worker-Canvas, Element- und Range-Boxen, Textmetriken, Audio, Parent-Profil verschieden zwischen `example.com` und `example.org` |
| neu nach (simulierter) New Identity | `browser_fawkes_randomize.js` (`resetSession()`, Topic `fawkes-session-reset`, Einstellungen bleiben); xpcshell: beide Sitzungen neu nach `resetSession()`, nur die private nach `last-pb-context-exited`, privat ≠ normal |
| Iframes/Worker erben | `browser_fawkes_randomize.js`: Drittanbieter-Iframe (`example.org` in `example.com`) sieht Navigator, Zeit, Canvas, Audio, Bildschirm, Worker-Canvas und Header der Top-Level-Site |
| Konsistenz JS (Hauptthread/Worker) ↔ CSS ↔ HTTP | `browser_fawkes_randomize_consistency.js`: Navigator/Date/Intl Fenster = Worker; User-Agent und Accept-Language von Drittanbieter-, Worker- und Dokument-Requests; Media-Queries = `screen`/`devicePixelRatio`/Farbtiefe, Fenster liegt auf dem Bildschirm (auch bei 150 % Zoom); `screenX − clientX` von Klicks = `mozInnerScreenX`; Redirect zu anderer Site bekommt normalen UA und normale Sprache; `browser_fawkes_randomize.js`: Werte = Parent-Profil (UA, oscpu, Kerne, Touchpoints, Zeitzone, Farbtiefe, WebGL) |
| Englisch-Spoofing | `browser_fawkes_randomize_english.js` (Nutzersprache `de-DE`): Fenster und Worker `en-US`/`en`, `Intl`-Locale, Zahlen-/Datumsformat, Accept-Language (fetch, Worker, Dokument); andere Sites behalten Deutsch; Sprachwechsel erreicht die Site nicht |
| Vorrang Blockier-Schalter | `browser_fawkes_randomize_precedence.js`: `js.device`, `css.mediaQueries` (Bildschirm und Media-Queries = RFP), `js.canvas` (Platzhalter, gerundete Metriken), `js.audio`, `googlebotUA` (Sprache trotzdem Englisch) |
| ohne Schalter | `browser_fawkes_randomize.js`: Nutzersprachen, RFP-UTC |
| Parent | xpcshell `test_fawkes_randomization.js`: Werte stabil/verschieden, plausible Profile (nur OS-Token variiert, UA ↔ oscpu, gültige Zeitzonen, WebGL-Strings), Sitzungs-Resets, Schlüssel in den Cookie-Jar-Settings von Dokument-Channels (Markierung, stabil, je Site verschieden, neu nach Reset, nicht nach Redirect), Header von Dokumenten, Subressourcen und Redirects, Googlebot gewinnt |

Hilfsdateien: `head_randomize.js`, `file_fawkes_randomize.html`, `file_fawkes_randomize_worker.js`, `file_fawkes_redirect.sjs`; `file_fawkes_echo_headers.sjs` und die xpcshell-`/echo` liefern jetzt auch `accept-language`.

## Manuelle Prüf-Checkliste (Phase 12)

1. **EFF Cover Your Tracks** (coveryourtracks.eff.org) mit `fpRandomize` an für die Site: Test zweimal laufen lassen → gleiche Werte (Canvas-Hash, WebGL-Hash, Bildschirm, Zeitzone, Sprache „en-US“); New Identity → Test erneut → andere Canvas-/WebGL-/Audio-Hashes, anderer Bildschirm o. ä. Ohne Schalter: die bekannten Tor-Browser-Werte.
2. **CreepJS** (abrahamjuliot.github.io/creepjs): „lies“/Inkonsistenzen prüfen – Fenster vs. Worker (User-Agent, Kerne, Sprache, Zeitzone), CSS-Media vs. `screen`; Fingerprint-ID vergleichen: gleich bei Reload, anders auf einer zweiten Site mit CreepJS-Kopie (z. B. per eigener Domain) bzw. nach New Identity.
3. **BrowserLeaks**: Canvas (Signatur stabil auf browserleaks.com, anders nach New Identity), WebGL (bei `js.webgl` aus: Renderer „…, or similar“ aus der Liste, Erweiterungsliste), Fonts (Liste erkannter Schriften kleiner/anders als ohne Schalter), JavaScript (Bildschirm, Zeitzone, Sprache Englisch, `hardwareConcurrency`), Client Hints/Header (Accept-Language `en-US,en;q=0.5`, User-Agent passend zu `navigator.userAgent`).
4. Zwei Sites mit dem Schalter nacheinander: Canvas-/Audio-Werte verschieden, auf jeder Site stabil.
5. Mit `css.mediaQueries` an: Bildschirm in JS und CSS wieder RFP-Werte; mit `js.canvas` an: Platzhalter statt Rauschen; mit Googlebot an: Googlebot-UA, Sprache Englisch.
6. Seite mit Karten/Grafiken und eine mit vielen Webfonts (Darstellung unverändert, nur benannte Systemschriften fehlen teils); Zoomen (Bildschirm, `devicePixelRatio` und `resolution` passen weiter zusammen).
7. NoScript, Reader View, PDF.js, about:-Seiten mit dem Schalter → unverändert.

## Anwendungsprobe

Index-Probe (temporärer Index, `git read-tree fawkes-base`, dann `git apply --cached` in Phasenreihenfolge):

- Sammeldateien: `phase-01-branding.patch` bis `phase-08-randomization.patch` bestehen `git apply --check` und ergeben den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`), `fawkes-phase-02` (`ded25fd99f13`), `fawkes-phase-03` (`aa18953cfa4f`), `fawkes-phase-04` (`dd9f9ead8e67`), `fawkes-phase-05` (`33768452f3ad`), `fawkes-phase-06` (`6d56d5b6daa0`), `fawkes-phase-07` (`2778b279eddb`) bzw. `fawkes-phase-08` (`3c07fd7ad1f2`).
- Serien: alle Patches aus `phase-01-branding/` (6), `phase-02-framework/` (7), `phase-03-no-tor/` (8), `phase-04-network/` (9), `phase-05-js-apis/` (10), `phase-06-css/` (8), `phase-07-profiling/` (9) und `phase-08-randomization/` (12) lassen sich anwenden und ergeben exakt den Tree von `fawkes-phase-08` (`3c07fd7ad1f2`).
- **Ergebnis: grün.**

Die Probe mit `git am` im Prüf-Worktree entfällt weiterhin auf Ihren Wunsch (über sshfs zu langsam).

Phase 8 ändert tor-browser-build nicht.

## Hinweise für spätere Phasen

- **Phase 9** (Cookie-Banner): Sites mit `fpRandomize` sehen Englisch; Banner erscheinen dort englisch.
- **Phase 10** (Proxy-Kette): Abschnitt 3.2 verlangt, dass New Identity auch die Proxy-Zuordnungen zurücksetzt – dafür eignet sich `Services.fawkes.resetSession()` bzw. das Topic `fawkes-session-reset`.
- **Phase 12**: neue kritische Stellen für den ersten Build: `FawkesRandomize.cpp` (Tabellen, `GeckoBindings.h`/`DocumentInlines.h`), das neue virtuelle `FontVisibilityProvider::FawkesFlags()`, `ServiceWorkerPrivate.cpp` (RemoteWorkerData-Argumente), die Realm-Optionen in `nsGlobalWindowOuter.cpp`/`WorkerPrivate.cpp`. Upstream-Tests sind nicht betroffen, solange `fpRandomize` aus ist (Standard).
