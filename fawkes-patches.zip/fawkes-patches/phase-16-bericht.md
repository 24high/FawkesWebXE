# Phase 16 – Packaging (deb, rpm, Windows-ZIP): Bericht

## Commits

tor-browser (Basis `fawkes-phase-11` = `91cb3fe28a4e` plus `fawkes-patches/phase-12.patch`).
Der Build-Baum `~/.cache/fawkeswebxe-src` führt kein Git, deshalb liegt alles nach
Phase 12 als Kette kombinierter Patches ab: `phase-16-packaging.patch`,
`phase-17-branding-signals.patch`, `phase-18-prefs-docs.patch`,
`phase-19-packager-fonts.patch`. Sie werden der Reihe nach auf den Stand von
Phase 12 angewendet. Die Dateien sind den Phasen über ihre Zeitstempel im
Build-Baum zugeordnet (Artefakt-Logs `artifacts/phase16-*` bis `phase19b-*`).
Phasen 13–15 gibt es nicht.

`phase-16-packaging.patch` enthält zusätzlich die 18 Änderungen von Phase 12, die
in `phase-12.patch` fehlten: `LICENSE`, `.gitattributes`, `nsDocShell.cpp`,
`nsHttpChannel.h`, `FawkesFlags.cpp`, `FawkesSwitches.h`,
`FawkesProxyScraper.sys.mjs`, `browser/config/mozconfigs/base-browser`,
`mozconfig-windows-i686`, `mozconfig-windows-x86_64`,
`testing/web-platform/tests/tools/third_party/attrs/.git_archival.txt`,
`test/xpcshell/head_network.js`, `test_fawkes_adblock.js`, `test_fawkes_lan.js`,
`test_fawkes_proxy_scraper.js`, `test_fawkes_proxy_scraper_rules.js`,
`test/browser/browser_fawkes_adblock.js` und
`test/browser/file_fawkes_network.html`. Neu ist außerdem
`mozconfig-windows-msvc` (Bauen mit MSVC/clang-cl unter Linux, für WebRTC auf
Windows).

## Was jetzt da ist

### Werkzeug für die Pakete

- `tools/fawkes/bundle-assets.py` (neu): prüft das signierte Tor-Archiv mit `gpgv`
  gegen einen Keyring, prüft den `tor`-Binary auf AMD64 (ELF bzw. PE), legt
  `tor`, `geoip`, `geoip6`, `torrc-defaults`, `bundle-source.json` und
  `bundle-signature.asc` nach `dist/bin/TorBrowser/Tor` und schreibt
  `adblock.txt` daneben.
- `tools/fawkes/mozconfig-linux-amd64` und `tools/fawkes/mozconfig-windows-amd64`
  (neu): Build-Konfiguration für die beiden Paketziele.
- `browser/installer/Makefile.in`: `FAWKES_Bundle`-Regel, `FAWKES_BUNDLE`-Define
  für `common.py` und `--bundle` für `make install`, `NON_OMNIJAR_FILES` um
  `adblock.txt` und `TorBrowser/**` erweitert, `bundle`-Hook in `stage-package`.
- `browser/installer/package-manifest.in`: `[fawkes-bundle]`-Einträge für
  `adblock.txt` und die Tor-Dateien.
- `toolkit/mozapps/installer/packager.py`: `FawkesBundleFile` beim Packaging,
  damit `torrc-defaults` und `bundle-signature.asc` byte-genau erhalten bleiben.
- `python/mozbuild/mozbuild/repackaging/rpm.py`: Name aus `application.ini` statt
  `firefox` und Kleinbuchstaben für das Programmverzeichnis.
- `browser/installer/linux/app/rpm/firefox.spec.j2`: `firefox` für
  `firefox.desktop`, Symlink und `distribution.ini`.
- `testing/mochitest/runtests.py`: setzt `network.proxy.type` im Harness auf 0,
  wenn `network.proxy.auto_config` ohne Tor aktiv ist.
- `browser/config/mozconfigs/base-browser`: WebRTC eingebaut (der Fawkes-Schalter
  entscheidet pro Seite), `--disable-webrtc` nur für MinGW; die
  Windows-Mozconfigs haben jetzt den Ausführungs-Modus.

### Lizenz, Markenbild, Start

- `LICENSE`: „FawkesWeb XE (c) 2026 Dennis Michael Heine" und der Hinweis auf die
  Tor-Browser-Lizenz; dieselbe Zeile fällt aus `toolkit/content/license.html`,
  `browser/base/content/aboutDialog.xhtml` (auch der `fawkes.ftl`-Verweis) und
  `toolkit/locales/en-US/toolkit/global/tor-browser.ftl` heraus.
- `browser/themes/shared/sidebar/tor-browser.svg`: Inline-Pfad statt des
  eingebetteten Base64-Bildes.
- `toolkit/components/search/content/base-browser-search-engines.json` und
  `-icons.json`: `rhscz` fällt ganz heraus, Standard-Suche ist `ddg`
  (`test_base_browser.js` angepasst).
- `browser/app/profile/000-tor-browser.js`: Kommentar, dass beim Start immer Tor
  genommen wird.
- `browser/branding/fawkeswebxe/firefox.icns`: kleineres Markenbild.

### EULA und Gerüst

- `browser/components/fawkes/Fawkes.sys.mjs` (−121 Zeilen), `FawkesEULA.sys.mjs`,
  `content/eulaDialog.js`, `content/eulaDialog.xhtml`,
  `content/config/fawkes.mjs`: EULA-Text und Ablauf gestrafft.
- `browser/components/fawkes/jar.mn` und `browser/components/BrowserComponents.manifest`:
  EULA-Einträge an den Anfang, `FawkesEULA.ready` an das Ende.
- `browser/components/abouttor/content/aboutTor.js` (+78): Startseiten-Logik.

### Code-Korrekturen

- `netwerk/protocol/http/nsHttpChannel.cpp` (+85) und `.h`: Ad-Block-Entscheidung
  und Fehlerseite im Kanal.
- `toolkit/components/fawkes/FawkesNetwork.cpp` (+126) und `.h`: Ad-Block-Liste,
  LAN-Schutz und Ports.
- `toolkit/components/fawkes/FawkesFlags.cpp` (+60) und `FawkesSwitches.h` (+13):
  Übergabe der Schalter an Dokumente, Worker und Worklets.
- `toolkit/components/fawkes/FawkesSwitches.inc` (−15) und `FawkesService.cpp`:
  Schaltertabelle und Schlüssel.
- `toolkit/components/fawkes/FawkesProxyScraper.sys.mjs`: Scraper-Regeln.
- `dom/canvas/ClientWebGLContext.cpp`/`.h`, `dom/webidl/Window.webidl`,
  `layout/style/nsMediaFeatures.cpp`,
  `toolkit/components/resistfingerprinting/nsRFPService.cpp`: WebGL-Parameter,
  Medien-Merkmale und RFP-Werte.
- `docshell/base/nsDocShell.cpp`: Flag-Übergabe beim Dokument.

### Doku, Tests, Dateimodi

- `docs/css.md`, `docs/network.md`, `docs/proxy-sources.md`, `docs/storage.md`:
  stark gekürzt.
- Tests: `browser_fawkes_branding.js`, `browser_fawkes_button.js`,
  `browser_fawkes_eula.js`, `browser_fawkes_googlebot.js`,
  `browser_fawkes_preferences.js`, `browser_fawkes_randomize_consistency.js`,
  `browser_fawkes_randomize_english.js`, `head_randomize.js`,
  `file_fawkes_echo_headers.sjs`, `file_fawkes_flags.html`,
  `file_fawkes_randomize.html`, `file_fawkes_webgl.html` (neu),
  `test_fawkes_service.js`, `test_fawkes_store.js`.
- `tools/lint/eslint/eslint-plugin-mozilla/lib/services.json`: zwei Einträge heraus.
- `.gitattributes`: LFS-Filter für `*.md` und `*.patch`; zahlreiche Dateien im
  Baum stehen von 0644 auf 0755 (auch `corruptDB.sqlite`-Testdaten).

## Tests

`./mach build` für Linux amd64 und Windows amd64, `./mach test --auto`
(Browser- und XPCShell-Tests, `artifacts/phase16-browser-tests.log`,
`artifacts/phase16-try-auto.log`), Packaging-Prüfungen
(`artifacts/phase16-bundle-negative-tests.log`,
`artifacts/phase16-final-package-checks.log`,
`artifacts/phase16-linux-final-verification*.log`,
`artifacts/phase16-windows-final-verification.log`).

## Build-Status

Release 16 gebaut: `fawkeswebxe_153.5.0-16_amd64.deb`,
`fawkeswebxe-153.5.0-16.x86_64.rpm`, `fawkeswebxe_153.5.0-16_windows-amd64.zip`
(zusammen mit Release 18 in `~/Downloads/FawkesWebXE-phase18`).
