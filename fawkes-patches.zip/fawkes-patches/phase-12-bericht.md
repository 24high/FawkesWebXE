# Phase 12 – Granulare Fingerprint-Signale, DNT, Cookie-Ausnahme, EULA: Bericht

## Commits

tor-browser (Basis `fawkes-phase-11` = `91cb3fe28a4e`). Phase 12 ist als ein
kombinierter Patch `phase-12.patch` hinterlegt (keine Einzel-Commits, da die
Änderungen in einer Arbeitskopie ohne Git-Verlauf entstanden sind). Der Patch
lässt sich mit `git apply fawkes-patches/phase-12.patch` auf `fawkes-phase-11`
anwenden.

## Inhalt

### Granulare Fingerprint-Signale (Blockieren und Randomisieren)

Die bisherigen Sammelschalter (`js.device`, `js.canvas`, `js.storage`) werden
für sechs Signale durch je einen eigenen Blockier- und einen eigenen
Randomisierungs-Schalter ergänzt. Alle neuen Schalter sind standardmäßig
aktiviert; Blockieren hat Vorrang vor Randomisieren.

| Signal | Blockieren | Randomisieren |
| --- | --- | --- |
| DOM localStorage | `fp.localStorage` | `randomize.localStorage` |
| DOM sessionStorage | `fp.sessionStorage` | `randomize.sessionStorage` |
| WebGL-Fingerprint | `fp.webglHash` | `randomize.webglHash` |
| Platform | `fp.platform` | `randomize.platform` |
| Maximale Touchpoints | `fp.maxTouchPoints` | `randomize.maxTouchPoints` |
| CPU-Kerne | `fp.hardwareConcurrency` | `randomize.hardwareConcurrency` |

- Speicher: „Randomisieren“ bedeutet eine getrennte, nur für das Dokument
  lebende In-Memory-Isolation (`PartitionedLocalStorage`), keine Veränderung
  gespeicherter Daten. Blockieren blendet `localStorage`/`sessionStorage`
  per `[Func]` aus.
- WebGL: Blockieren verbirgt Renderer/Vendor und verweigert rohes
  Pixel-Auslesen; Exporte liefern Platzhalter. Randomisieren liefert
  Renderer/Vendor aus der Liste und key-abhängiges Pixel-Rauschen; nicht
  bereinigtes PBO-Auslesen bleibt verweigert.
- Platform/Touchpoints/Kerne: maskierte Werte beim Blockieren, sonst
  Werte aus dem Profil der Plattformfamilie, konsistent in Fenster und
  Workern.

Neue Menügruppen „Block fingerprint signals“ und „Fingerprint randomization
details“ plus Einstellungen; neue Bit-Flags 7 (`doNotTrack`) und 10–15 sowie
46–51 in `FawkesSwitches.inc`.

### Do Not Track

`doNotTrack` (standardmäßig aktiv) setzt `DNT: 1` pro Seite und entfernt einen
von einer Weiterleitung übernommenen DNT-Header beim Deaktivieren.
`navigator.doNotTrack` meldet passend `"1"` oder `"unspecified"`. Die native
Vorwahl `privacy.donottrackheader.enabled` ist ebenfalls `true`.

### Cookie-Ausnahme im Menü

„Allow cookies for this site“ (standardmäßig nicht gesetzt) legt eine native
`cookie`-Ausnahme für den aktuellen HTTP/HTTPS-Principal an, sodass Cookies
auch bei globaler Cookie-Blockierung funktionieren; Ausschalten entfernt sie.
Private-Browsing-Ausnahmen bleiben sessiongebunden. Ausnahmen liegen im
Permission-Manager, nicht in `fawkes-sites.json`.

### Branding, Suche, Proxy-Judge, Lizenz

- `~/Downloads/fawkes.png` als Browser-/EXE-Symbol (alle Größen, ICO/ICNS,
  via `tools/fawkes/import-icons.py`).
- Standardsuche `https://search.rhscz.eu/` (normal und privat, Startseite).
- Standard-Proxy-Judge `https://wfuchs.de/azenv.php`.
- Hinweistext „This is an unstable version of FawkesWeb XE for testing new
  features“ (ohne „Learn more“).
- Copyright „(c) 2026 Dennis Michael Heine“ im Über-Dialog und in
  `toolkit/content/license.html` („FawkesWeb XE is (c) 2026 Dennis Michael
  Heine“).

### EULA beim ersten Start

`fawkes.eula.accepted` (Standard `false`). `FawkesEULA.ready`
(`browser-first-window-ready`) öffnet beim ersten Start einen modalen
Lizenz-Dialog; „Akzeptieren“ setzt die Vorgabe, „Ablehnen“ beendet den
Browser. Automatisierte Tests (`Cu.isInAutomation`) überspringen den Dialog.

## Tests

`browser_fawkes_fingerprint_signals.js` (Defaults, Blockieren,
Randomisieren, Speicher-Isolation, WebGL-Auslesen), `browser_fawkes_dnt.js`
(DNT in Dokument/Subressourcen/Workern, Weiterleitung),
`browser_fawkes_eula.js` (Dialog + Akzeptieren), erweiterte
`browser_fawkes_branding.js` (Suche, Hinweistext, Logo, Copyright),
`browser_fawkes_button.js` (Cookie-Ausnahme) sowie die vorhandenen
Randomisierungs-/Dienst-Tests.

## Build-Status

Die Phase wurde auf Linux amd64 und Windows amd64 gebaut. Verteilung als DEB
und portables Windows-ZIP. Das RPM wird über `mach repackage rpm` erzeugt;
dafür wurden `rpm.py` und `firefox.spec.j2` an den App-Namen `fawkeswebxe`
angepasst, das Paket kann aber nur gebaut werden, wenn `rpmbuild` installiert
ist.
