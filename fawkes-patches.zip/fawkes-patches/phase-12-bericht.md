# Phase 12 – Voreinstellungen: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-11` = `7be6bb5456ad`, Tag
`fawkes-phase-12` = `c6f1ff510c7b`, Tree `ec5fa8e7fc27`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `a6f8ae701e3d` | Fawkes: Use fawkes.ico as the application icon |
| 2 | `6fb730b239d4` | Fawkes: Turn on every protection and use DoH only by default |
| 3 | `95f332ae55ba` | Fawkes: Connect to Tor automatically at startup |
| 4 | `887baf43003b` | Fawkes: Let the Cloudflare challenge host run its scripts and styles |
| 5 | `7f38ec238c1c` | Fawkes: Check proxies without an external judge |
| 6 | `5263a5d96a73` | Fawkes: Document the fork and how to build it |
| 7 | `c6f1ff510c7b` | Fawkes: Compile WebRTC in where it builds |

Patches: `fawkes-patches/phase-12-customization/` (6 Dateien) und
`fawkes-patches/phase-12-customization.patch` (Sammeldatei mit den binären
Icons, für `git apply`).

## Was geändert wurde

- **Anwendungs-Icon:** `browser/branding/fawkeswebxe/firefox.ico` (und die
  Fenster-/Tab-Varianten `newwindow.ico`, `newtab.ico`, `pbmode.ico`) sind die
  Datei `/mnt/c/fawkes.ico` (= `C:\fawkes.ico`). `splash.rc` und
  `desktop-launcher.rc` binden sie über `FIREFOX_ICO`/`*_ICO` ein.
- **DNS:** `fawkes.direct.doh.mode = 3` (nur DNS over HTTPS) und
  `fawkes.direct.doh.uri = "https://dns.nextdns.io/"` in
  `browser/components/fawkes/fawkes-prefs.js`. Im Tor-Betrieb bleibt DNS bei
  Tor (kein lokales Auflösen); die Werte gelten für den Betrieb ohne Tor.
- **Standardwerte:** In `toolkit/components/fawkes/FawkesSwitches.inc` ist
  jeder Schalter standardmäßig an, außer `proxyChain`. Daraus entstehen
  `kFawkesBuiltinDefaults` (C++) und `FawkesSwitches.sys.mjs` (generiert).
- **Cloudflare:** `FawkesFlags.cpp` nimmt für Dokumente von
  `challenges.cloudflare.com` die JavaScript-, CSS- und
  Profiling-Schalter weg (`FawkesGroupSwitchMask("Js" | "Css" |
  "Profiling")`), damit die Bot-Prüfung laufen kann. Die Seite, die die
  Prüfung zeigt, behält ihre Schutzschalter.
- **Immer Tor:** `torbrowser.settings.quickstart.enabled = true` und
  `extensions.torlauncher.prompt_at_startup = false` verbinden beim Start
  automatisch mit Tor, auch beim ersten Start eines neuen Profils.
- **Proxy-Judge:** `fawkes.proxy.scraper.judgeUrl` ist optional. Ohne Judge
  prüft der Browser die Proxys selbst (SOCKS5-Greeting, CONNECT und ein
  HTTPS-Request über gültiges TLS an `https://example.com/`); die
  Adressprüfungen (Elite, ausgehendes Land) entfallen dann. Mit Judge bleibt
  alles wie in Phase 11.
- **Dokumentation:** Die `README.md` beschreibt die Features des Forks und den
  Bau (tor-browser-build und mach). `categories.md` und `tor-mode.md` nennen
  die neuen Standardwerte.
- **WebRTC:** Linux- und macOS-Builds kompilieren WebRTC jetzt ein
  (`base-browser` enthält kein `--disable-webrtc` mehr), damit der Schalter
  „blockWebRTC“ es pro Seite freigeben kann. Die MinGW-Ziele (Windows) behalten
  `--disable-webrtc` in `mozconfig-windows-*` (Mozilla-Bug 1393901; WebRTC
  baut dort nicht). Der Menüpunkt zeigt dort weiter „not included in this
  version“.

## Anwendung beim Bauen

Der Bau in `tor-browser-build` holt den Quellbaum über
`projects/firefox/config`:

```
git_url: /home/dh/tor-browser
git_hash: c6f1ff510c7b284e352facb24838c76196a5a1ad
```

Der `git_hash` zeigt auf `fawkes-phase-12`; damit sind die Änderungen
automatisch Teil des nächsten `make torbrowser-testbuild-windows-x86_64`.
Die Patch-Dateien selbst liegen unter `fawkes-patches/` und werden nicht
mitkompiliert; auf einem anderen Checkout werden sie vor dem Bau in der
Reihenfolge der Phasen mit `git am` bzw. `git apply` angewendet (siehe
`README.md`).

## Prüfung

- Sammeldateien 01–12 und die Serie 01–12 ergeben angewendet auf
  `fawkes-base` den Tree von `fawkes-phase-12` (`ec5fa8e7fc27`).
- `make` in `obj-x86_64-pc-linux-gnu/toolkit/components/fawkes` übersetzt die
  geänderten C++-Dateien ohne Fehler (eine bestehende Warnung in
  `FawkesService.cpp`).
- Die JS-Dateien sind syntaktisch geprüft (`node --check`).
- Nicht ausgeführt: die xpcshell- und Browser-Tests (kein vollständiger
  Testlauf in dieser Sitzung) und der Windows-Bau.
