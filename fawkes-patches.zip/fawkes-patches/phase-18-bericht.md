# Phase 18 – Projekte-Doku, Voreinstellungen, Profiling-Feinheiten: Bericht

## Commits

tor-browser (Stand nach `fawkes-patches/phase-17-branding-signals.patch`).
Kombinierter Patch `phase-18-prefs-docs.patch`, ohne Einzel-Commits (der
Build-Baum `~/.cache/fawkeswebxe-src` führt kein Git). Zugeordnet über die
Zeitstempel im Build-Baum (`artifacts/phase18-*`, 7. November 07:22–07:31).

## Was jetzt da ist

### Doku

- `README.md` im Projektstamm: die FawkesWebXE-Beschreibung in 837 Zeilen
  (Schutz vor Fingerprinting, Schalter pro Seite und global, Tor-Modus,
  Proxy-Kette, Packaging, Bauen und Testen) statt der zwei Tor-Browser-Links.
- `browser/components/fawkes/docs/categories.md`, `docs/profiling.md`,
  `docs/proxy-scraper.md`, `docs/tor-mode.md` gekürzt.

### Voreinstellungen (`browser/components/fawkes/fawkes-prefs.js`)

- DNS over HTTPS ist voreingestellt: `fawkes.direct.doh.mode` = 3 und
  `fawkes.direct.doh.uri` = `https://dns.nextdns.io/` (vorher 0 und leer).
- `privacy.donottrackheader.enabled` fällt heraus.
- `webgl.enable-webgl2` = true: WebGL2 ist an, der Schalter `js.webgl`
  entscheidet weiter pro Seite (WebGL2 ist in `001-base-profile.js` aus,
  tor-browser#16404).
- Kommentare zu Proxy-Scraper und EULA gekürzt, die Listen-Präferenzen
  (`blockedCountries`, `sources`) einzeilig.

### Menühinweise

- `browser/components/fawkes/locales/en-US/fawkes.ftl` und `locales/de/fawkes.ftl`:
  Menütexte kürzer und ohne Wiederholungen.

### Profiling

- `toolkit/components/fawkes/FawkesDom.h`: `ReportsOnlyFirstIntersection` und
  `LoadsLazyElementsEagerly` sind zwei getrennte Schalter (vorher ein Verhalten).
- `dom/base/DOMIntersectionObserver.cpp`: gemeldet wird nur der erste Zustand
  eines Beobachters; spätere Zustandswechsel bleiben verborgen.

### Tests

- `browser/components/fawkes/test/browser/browser_fawkes_profiling_scroll.js`
  und `file_fawkes_profiling.html`: Scroll- und Lazy-Loading-Verhalten.
- `browser/components/fawkes/test/browser/browser_fawkes_proxy_scraper.js` und
  `browser.toml` angepasst.

## Tests

`./mach build` Linux amd64 und Windows amd64, Browser-Tests
(`artifacts/phase18-prefs.log`, `artifacts/phase18-prefs-ui.log`,
`artifacts/phase18-scroll-tests.log`, `artifacts/phase18-scraper-tests*.log`,
`artifacts/phase18-linux-ui.log`, `artifacts/phase18-windows-ui.log`).

## Build-Status

Release 18 gebaut: `fawkeswebxe_153.5.0-18_amd64.deb` (134 924 774 Bytes),
`fawkeswebxe-153.5.0-18.x86_64.rpm` (174 304 040 Bytes),
`fawkeswebxe_153.5.0-18_windows-amd64.zip` (171 414 074 Bytes), je mit `.sha256`
(`artifacts/phase18-linux-package-final.log`,
`artifacts/phase18-windows-package-final.log`).

Gefunden, aber erst in Phase 19 behoben: die Pakete von Release 18 enthalten
`/opt/fawkeswebxe/fonts/*.ttf` und `fonts.conf` im Modus `-rw------- root`.
Ein normaler Benutzer kann die gebundelten Schriften nicht lesen, und
`font.system.whitelist` zusammen mit `font.name-list.*` (Tinos, Arimo, Cousine)
schließt die Systemchriften aus – es löst keine Schrift auf, jedes Zeichen wird
mit der Breite eines Geviert-Buchs gezeichnet. Auf der beobachteten Seite
(`artifacts/phase18-proxynova-baseline.log`, `phase18-proxynova-spacing.log`)
waren Wortabstände im Median 16 px bei 16 px Schriftgröße; mit lesbaren
Schriften 4 px.
