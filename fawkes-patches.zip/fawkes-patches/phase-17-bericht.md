# Phase 17 – Markenbild, Startseite, Randomisierungs-Signale: Bericht

## Commits

tor-browser (Stand nach `fawkes-patches/phase-16-packaging.patch`). Wie in
Phase 16 gibt es im Build-Baum `~/.cache/fawkeswebxe-src` keinen Git-Verlauf;
deshalb liegt diese Phase als kombinierter Patch `phase-17-branding-signals.patch`
da. Der Patch wird nach Phase 16 angewendet. Zugeordnet sind die Dateien über
ihre Zeitstempel im Build-Baum (`artifacts/phase17-*`, 7. November 06:30–07:08).

## Was jetzt da ist

### Markenbild und Startseite

- Alle Markenbilder von `browser/branding/fawkeswebxe/` ersetzt: `firefox.ico`
  111801 → 21073 Bytes, `default16/22/24/32/48/64/128/256.png`,
  `newtab.ico`, `newwindow.ico`, `pbmode.ico`, `VisualElements_70/150.png`,
  `content/about-logo.svg`, `about-logo-small.svg`, `about-logo.png`,
  `about-logo@2x.png` (das echte Fawkes-Zeichen, aus `tools/fawkes/import-icons.py`).
- `browser/app/Makefile.in`: unter Windows hängen die `.res`-Dateien an den
  Markenbildern, ein geändertes Icon baut die Ressourcen-Datei neu.
- `browser/components/abouttor/content/aboutTor.css` und `aboutTor.html`:
  responsives Raster (`minmax(0, 1fr)`, `minmax(0, var(--form-max-width))`),
  Abstände und Kopfzeile der Startseite.

### Randomisierung ohne Sammelschalter

`toolkit/components/fawkes/FawkesRandomize.h` und `.cpp` sind deutlich kleiner:

- `enum class Surface` ohne `WebGL`, `Platform`, `MaxTouchPoints` und
  `HardwareConcurrency`; die Fläche `Canvas` deckt WebGL-Auslesen mit ab.
- `IsolatesLocalStorage()` und `IsolatesSessionStorage()` fallen heraus
  (`FawkesDom.cpp`): die Speicher-Randomisierung ist keine
  Dokument-Lebensdauer-Isolierung mehr.
- `GetAppVersion()` fällt heraus, `GetUserAgent()` ohne den Plattform-Parameter,
  `ProfileToJSON()` ohne Schalter, `GetPlatform()` jetzt über das globale
  Objekt statt über die Flags.
- Blockieren gewinnt nur noch dort, wo ein Schalter denselben Wert festlegt.

`toolkit/components/fawkes/FawkesBindings.cpp` und `.h` melden die Flächen für
WebGPU und Audio an `dom/webgpu/Instance.h`, `dom/canvas/CanvasUtils.cpp`
(Auslesereihenfolge) und `dom/canvas/ClientWebGLContext.cpp` weiter;
`dom/base/Navigator.cpp` und `nsGlobalWindowInner.cpp`/`.h` fragen die
Kategorie-Schalter `js.device` und `js.canvas` ab statt der bisherigen
`Block*`-Schalter; `dom/workers/WorkerNavigator.cpp` und `WorkerScope.h`
ebenfalls für Worker.

### Tests und Doku

- Neu: `browser/components/fawkes/test/browser/browser_fawkes_webgl_readback.js`
  und `browser_fawkes_webstorage_defaults.js`.
- Angepasst: `browser_fawkes_js_graphics.js`, `browser_fawkes_js_storage.js`,
  `browser_fawkes_randomize.js`, `browser_fawkes_randomize_precedence.js`,
  `file_fawkes_js.html`, `toolkit/components/fawkes/test/xpcshell/test_fawkes_randomization.js`.
- `docs/js-apis.md` und `docs/randomization.md` gekürzt.

## Tests

`./mach build` Linux amd64 und Windows amd64, Browser-Tests mit
`artifacts/phase17-browser-tests-device-diagnostics.log`, Markenprüfung
`artifacts/phase17-brand-verification.log`, Messungen auf echten Seiten
(`artifacts/phase17-eff-baseline.log`, `artifacts/phase17-eff-final-deb.log`,
`artifacts/phase17-home-baseline.log`, `artifacts/phase17-home-final.log`,
`artifacts/phase17-home-updated.log`), Windows-Branding
`artifacts/phase17-windows-branding-backend.log`.

## Build-Status

Release 17 gebaut: `fawkeswebxe_153.5.0-17_amd64.deb` und
`fawkeswebxe_153.5.0-17_windows-amd64.zip`
(`artifacts/phase17-release.log`, `artifacts/phase17-eff-final-deb.log`,
`artifacts/phase17-windows-package-r*.log`).
