# Phase 4 – Netzwerk im Parent: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-03` = `35616030d641`, Tag `fawkes-phase-04` = `bd7485e2602a`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `8d1b09772d96` | Fawkes: Add the strings of the network protection |
| 2 | `4503a880be57` | Fawkes: Add the error codes and pages of the network protection |
| 3 | `6e7ddae6f77c` | Fawkes: Block the referer per site |
| 4 | `ba02bef8529b` | Fawkes: Send the Googlebot user agent per site |
| 5 | `67e5db3b6065` | Fawkes: Block HTTP/3 per site |
| 6 | `21cc38b9b4dc` | Fawkes: Block the domains of adblock.txt per site |
| 7 | `2ef19b091017` | Fawkes: Block requests from public sites to the local network |
| 8 | `66afc2e24faa` | Fawkes: Test the network protection |
| 9 | `bd7485e2602a` | Fawkes: Document the network protection |

Patches: `fawkes-patches/phase-04-network/` (9 Dateien) und `fawkes-patches/phase-04-network.patch`.
Plan: `/home/dh/.claude/plans/fawkes-phase-04.md` (ohne Rückfrage umgesetzt, wie vereinbart).
Ausführliche technische Doku: `browser/components/fawkes/docs/network.md`.

## Was jetzt da ist

Alle Netzwerkschalter wirken jetzt; entschieden wird im Parent pro Channel anhand der Top-Level-Site (Flags aus Phase 2). Der zentrale Hook sitzt in `nsHttpChannel::AsyncOpen`, direkt nach der Flag-Berechnung und vor allen `http-on-*`-Beobachtern; blockierte Requests scheitern dort synchron, also vor Proxy-Auflösung, DNS und Verbindungsaufbau. Browser-eigene Requests, about:-Seiten und Erweiterungen bleiben unberührt.

- **Referer-Blocker** (Standard an): Der Parent ersetzt die Referrer-Info jedes Requests durch eine ohne Referrer. Kein `Referer`-Header für Dokumente, Subressourcen, Worker, `window.open`, Beacons; Weiterleitungen übernehmen den leeren Referrer; `document.referrer` ist leer (das Dokument bekommt die Referrer-Info vom Parent, `Document::GetReferrer` deckt `about:srcdoc` u. ä. ab). Modus `fawkes.referer.mode`: 0 immer, 1 nur Cross-Site. Der `Origin`-Header bleibt unverändert.
- **Googlebot-UA** (Standard aus): `User-Agent` aller Requests der Site (auch Drittanbieter und Worker) und `navigator.userAgent`/`appVersion`/`platform` in Fenstern und allen Worker-Arten. Andere Sites behalten das `Firefox/`-Token. Bei einer Weiterleitung auf eine Site ohne Schalter kommt der normale UA zurück.
- **HTTP/3-Block** (Standard an): kein QUIC, keine h3-Nutzung aus `Alt-Svc` oder HTTPS-RR, keine Speicherung von h3-Alt-Svc-Einträgen solcher Channels, WebTransport abgelehnt (`NS_ERROR_FAWKES_WEBTRANSPORT_BLOCKED`). Ohne Tor schaltet der Direktmodus `network.http.http3.enable` jetzt global ein (Übergabe aus Phase 3); mit Tor bleibt es aus.
- **Adblocker** (Standard an): `Services.fawkesNetwork` lädt `adblock.txt` aus dem Ordner der Programmdatei (`XREExeF`, Ersatz `GreBinD`) im Hintergrund nach `profile-after-change`. Formate: Domain, Hosts-Zeilen, `||domain^`; Kommentare und Nicht-Unterstütztes werden gezählt. Gespeichert werden 64-Bit-Hashes in einer Hash-Menge (ca. 24 MB für 1 Mio. Einträge), Prüfung über Host und alle übergeordneten Domains. Dazu kommen die Domains aus `fawkes.blockedDomains`. Blockiert werden alle Channel-Arten inkl. WebSocket (vor der Admission, also ohne DNS) und Early-Hints-Preconnects; Fehlercode `NS_ERROR_FAWKES_BLOCKED_BY_ADBLOCK`. Top-Level-Loads zeigen die Fehlerseite „Vom Adblocker blockiert“ mit „Nochmal versuchen“, Frames bleiben leer. Menü: „Adblocker (adblock.txt) – 12 blockiert auf dieser Seite“ bzw. „keine Liste geladen“. Einstellungen: Pfad, Zahl der Domains, Kommentare und nicht unterstützten Zeilen, Knopf „adblock.txt neu laden“. Keine Liste im Paket; `browser/components/fawkes/docs/adblock.txt.example` zeigt das Format.
- **LAN-/Portscan-Schutz** (Standard an): Klassifikation ohne DNS (alle IPv4-Bereiche des Auftrags in allen URL-Schreibweisen, IPv6 inkl. mapped/compatible/NAT64, `localhost`, `*.local`, `*.lan`, `*.home`, `*.internal`, `*.intranet`, `*.corp`, `*.home.arpa`, `*.localdomain`, einteilige Namen; `.onion` nie lokal). Requests öffentlicher Seiten an lokale Ziele scheitern sofort und mit identischem Fehler (`NS_ERROR_FAWKES_LOCAL_NETWORK_BLOCKED`), unabhängig von Ziel und Port. Erlaubt, wenn die Top-Level-Seite selbst lokal ist; Navigationen, wenn der Nutzer oder eine lokale Seite sie gestartet hat und keine öffentliche Site weitergeleitet hat. Tor-Ports (9050, 9051, 9150, 9151, SOCKS-Port der Sitzung, `TOR_SOCKS_PORT`, `TOR_CONTROL_PORT`) auf lokalen Hosts sind immer gesperrt. Ohne Tor werden zusätzlich die aufgelösten Adressen vor dem Verbinden geprüft (DNS-Rebinding). Fehlerseite „Zugriff auf das lokale Netzwerk blockiert“ ohne „Nochmal versuchen“. Der Klassifikator steht für Phase 11 bereit: `Services.fawkesNetwork.isLocalHost()`, `normalizeIPv4()`, `isTorPort()`.

## Entscheidungen ohne Rückfrage (bitte prüfen)

1. **Referer: Policy bleibt, nur der Referrer fällt weg.** Der Auftrag nennt „effektive Referrer-Policy no-referrer“ und „Origin nicht anfassen“. Firefox setzt bei der Policy `no-referrer` `Origin: null` (`ReferrerInfo::ShouldSetNullOriginHeader`). Ich ersetze deshalb nur den Referrer (leer, auch über Weiterleitungen) und lasse die Policy stehen; die Wirkung auf den Referrer ist die von `no-referrer`, der `Origin`-Header bleibt exakt wie ohne Blocker.
2. **Referer bei Navigationen: Schalter der Zielseite oder der auslösenden Seite.** Der Referrer einer Navigation ist die Adresse der Seite, von der sie ausgeht; ist der Blocker dort an, wird er auch entfernt, wenn er auf der Zielseite aus ist (strengere Variante).
3. **„Nur Cross-Site“** bedeutet: auslösendes Dokument und Ziel liegen auf verschiedenen Sites (`ReferrerInfo::IsCrossSiteRequest`, eTLD+1-Vergleich).
4. **Googlebot-Werte**: `appVersion` = UA ohne `Mozilla/` (wie Chrome), `platform` = `Linux x86_64` (Googlebot läuft unter Linux). `vendor`, `oscpu` usw. bleiben bei den RFP-Werten (nicht verlangt). Auf Googlebot-Sites hat der Schalter für diese drei Werte Vorrang vor RFP; das ist die im Auftrag (Abschnitt 10) vorgesehene Ausnahme. Der Googlebot-Wert gilt auch vor einem DevTools-UA-Override.
5. **Chrome-Version im Googlebot-UA bleibt 155.0.0.0.** Laut Release-Kalender (Zweiwochen-Rhythmus ab 8. 9. 2026) ist 155 die Oktober-Version (6. 10. 2026); Googlebot zieht Chrome-Versionen mit Verzug nach. Quellen: [Chrome-Blog zum Zweiwochen-Rhythmus](https://developer.chrome.com/blog/chrome-two-week-release?hl=en), [Release-Kalender (Drittquelle)](https://www.superchargebrowser.com/library/chrome-149-whats-coming-tab-users.md). Bitte beim Test gegen den echten Googlebot prüfen; der Wert ist in den Einstellungen änderbar.
6. **`fawkes.googlebot.userAgent` und `fawkes.referer.mode` sind jetzt Static Prefs** (`StaticPrefList.yaml`) statt Einträgen in `fawkes-prefs.js`: Worker müssen den UA auf ihrem eigenen Thread lesen, Content-Prozesse den Modus. Name, Standardwert und Einstellungsseite sind unverändert.
7. **HTTP/3 ohne Tor global an**, WebTransport bleibt auf dem Firefox-Standard (an); beides wird pro Site durch „HTTP/3 blockieren“ (Standard an) verhindert. Ohne die globale Freigabe hätte „nicht blockiert“ nichts bewirkt.
8. **adblock.txt-Pfad**: Ordner von `XREExeF` (Linux `Browser/` neben `fawkeswebxe`, das `start-fawkeswebxe` startet; Windows neben `fawkeswebxe.exe`; macOS `Contents/MacOS` im App-Bundle – eine Datei dort bricht die Bundle-Signatur, das ist dokumentiert). Kein weiterer Pfad, kein Pref.
9. **Adblock-Formate**: `$important` wird akzeptiert, alle anderen Regeloptionen (`$third-party` …) und Ausnahmen (`@@`) gelten als nicht unterstützt, damit nichts falsch (zu weit oder zu eng) blockiert wird. Namen ohne Punkt (`localhost` aus Hosts-Dateien) und Nicht-ASCII-Namen werden übersprungen (Punycode-Form verwenden). IPv4-Einträge blockieren nur genau diese Adresse. Dateien über 256 MB werden abgelehnt.
10. **64-Bit-Hashes statt Strings**: Speicher ca. 24 MB statt ca. 80 MB bei 1 Mio. Einträgen. Eine Fehlblockade durch eine Hash-Kollision ist bei 1 Mio. Einträgen pro Abfrage mit etwa 5·10⁻¹⁴ vernachlässigbar.
11. **Frames bleiben leer**: Blockierte Werbe- und LAN-Frames zeigen keine Fehlerseite (sonst stünde in jedem Werbeplatz eine). Das betrifft nur diese beiden Fehler; die `.onion`-Fehlerseite aus Phase 3 erscheint weiter in allen Frames.
12. **Menüzähler**: zählt Subressourcen, Frames, Worker-Requests und WebSockets pro Seite (Window-Global des Top-Level-Dokuments), nicht blockierte Top-Level-Dokumente (die zeigen die Fehlerseite). Fehlt `adblock.txt`, zeigt das Menü „keine Liste geladen“ samt Zahl, denn die eigenen Domains blockieren weiter.
13. **HTTPS-Only** ersetzt Fawkes-Fehlerseiten nicht mehr durch seine eigene (`nsHTTPSOnlyUtils::HttpsUpgradeUnrelatedErrorCode` kennt das Modul `FAWKES`), sonst sähe man bei einer hochgestuften Werbe-URL „Seite nicht sicher verfügbar“.
14. **LAN – zusätzliche Bereiche** (strenger als die Liste): `255.255.255.255`, `fec0::/10`, IPv4-kompatibles `::a.b.c.d`, NAT64 `64:ff9b::/96` mit lokaler IPv4, `*.localdomain`. Hosts, die URLs als ungültige IPv4-Adresse ablehnen würden, und ungültige IPv6-Literale gelten als lokal (fail closed).
15. **LAN – wer darf**: Subressourcen, Frames, Worker dürfen lokale Ziele erreichen, wenn die Top-Level-Seite lokal ist (Name/IP; ohne Tor auch, wenn Firefox' LNA für die Seite eine lokale oder private Adresse erfasst hat, z. B. `fritz.box`). Navigationen (Links, Formulare, `location`, `window.open`) dürfen es, wenn der Nutzer, der Browser, eine Erweiterung oder eine lokale Seite sie startet und keine öffentliche Site weiterleitet; maßgeblich ist der Schalter der auslösenden Seite. Folge: Ein Link von einer öffentlichen Seite auf `http://192.168.1.1` wird blockiert, auch wenn der Nutzer klickt (Router-CSRF); Eintippen funktioniert. Die Fehlerseite sagt das.
16. **Tor-Ports immer gesperrt**, auch bei ausgeschaltetem Schalter, auf lokalen Seiten und beim Eintippen, aber nur auf lokalen Hosts (ein öffentlicher Server auf Port 9050 bleibt erreichbar).
17. **Ein Fehlercode für alle LAN-Sperren** (Literal, Name, Tor-Port, aufgelöste Adresse), damit sich Ursachen nicht unterscheiden lassen.
18. **DNS-Rebinding ohne Tor**: Channels, für die der Schutz gilt, bekommen eigene Verbindungen (`nsHttpConnectionInfo` mit Hash-Key-Teil `[!lan]`), deren Socket-Transports jede aufgelöste Adresse vor dem `connect` prüfen (`nsISocketTransport::FAWKES_NO_LOCAL_ADDRESSES`, HTTP/3 in `HttpConnectionUDP`). So kann keine fremde, ungeprüfte Verbindung wiederverwendet werden. Über einen Proxy (Phase 10) löst der Proxy auf, die Prüfung entfällt dann.
19. **Firefox' Local Network Access** (`network.lna.*`, in Tor Browser an) bleibt aktiv, wird aber nur nachrangig erreicht: LNA prüft erst nach dem TCP-Verbindungsaufbau und fragt den Nutzer; Fawkes blockiert vorher und ohne Frage. Wiederverwendet wird LNAs Adressraum der Dokumente – nur ohne Tor, denn mit Tor stammt scheinbar jedes Dokument vom SOCKS-Proxy auf diesem Computer.
20. **Mit Tor wird nie lokal aufgelöst**: Der Klassifikator arbeitet nur mit dem Host-String; die Socket-Prüfung gibt es nur im Direktmodus und nur ohne Proxy.

## Geänderte Upstream-Dateien (dünne Hooks, für spätere Rebases)

| Datei | Änderung |
| --- | --- |
| `xpcom/base/ErrorList.py`, `js/xpconnect/src/xpc.msg` | `NS_ERROR_FAWKES_BLOCKED_BY_ADBLOCK` (2), `NS_ERROR_FAWKES_LOCAL_NETWORK_BLOCKED` (3), `NS_ERROR_FAWKES_WEBTRANSPORT_BLOCKED` (4) |
| `docshell/base/nsDocShell.cpp` | Fehlerschlüssel `fawkesAdblocked`, `fawkesLocalNetworkBlocked`; diese zwei nur im Top-Frame |
| `toolkit/content/aboutNetError.mjs` | Einträge in `initFawkesError()`, Hostname als Argument, „Nochmal versuchen“ je Fehler |
| `dom/security/nsHTTPSOnlyUtils.cpp` | Modul `FAWKES` gilt als vom Upgrade unabhängig |
| `netwerk/protocol/http/nsHttpChannel.cpp` | Hook in `AsyncOpen`, Connection-Info-Flag in `BeginConnect`, h3-Alt-Svc nur mit HTTP/3 |
| `netwerk/protocol/http/AlternateServices.cpp` | h3-Einträge überspringen bei `NS_HTTP_DISALLOW_HTTP3` |
| `netwerk/protocol/http/nsHttp.h` | Caps-Bit `NS_HTTP_FAWKES_NO_LOCAL_ADDRESSES` |
| `netwerk/protocol/http/nsHttpConnectionInfo.{h,cpp}`, `netwerk/ipc/NeckoChannelParams.ipdlh` | Flag `fawkesNoLocalAddresses` (Hash-Key, Klone, IPC) |
| `netwerk/protocol/http/DnsAndConnectSocket.cpp`, `ConnectionEstablisher.cpp` | Socket-Flag aus der Connection-Info |
| `netwerk/protocol/http/HttpConnectionUDP.cpp` | Adressprüfung für HTTP/3 |
| `netwerk/base/nsISocketTransport.idl`, `netwerk/base/nsSocketTransport2.cpp` | `FAWKES_NO_LOCAL_ADDRESSES`, Prüfung vor dem Verbinden |
| `netwerk/protocol/websocket/WebSocketChannel.cpp` | Prüfung vor der Admission |
| `netwerk/protocol/http/EarlyHintPreconnect.cpp` | kein Preconnect zu blockierten Hosts |
| `dom/base/Document.cpp` | `document.referrer` |
| `dom/base/Navigator.cpp`, `dom/workers/WorkerNavigator.cpp` | Googlebot-Werte |
| `modules/libpref/init/StaticPrefList.yaml` | `fawkes.googlebot.userAgent`, `fawkes.referer.mode` |
| `browser/components/preferences/preferences.js` | Gruppe `fawkesAdblock` im Fawkes-Pane |

Neuer Code: `toolkit/components/fawkes/` (`FawkesNetwork.{h,cpp}`, `FawkesNetworkService.{h,cpp}`, `FawkesAdblock.{h,cpp}`, `FawkesLocalNetwork.{h,cpp}`, `nsIFawkesNetwork.idl`, Erweiterungen in `FawkesFlags`, `FawkesService`, `FawkesTorMode.sys.mjs`, `components.conf`, `moz.build`) und `browser/components/fawkes/` (Menüzähler in `Fawkes.sys.mjs`, Einstellungen in `content/config/fawkes.mjs`, Strings, `fawkes-prefs.js`, `docs/network.md`, `docs/adblock.txt.example`).

## Tests (geschrieben, laufen erst in Phase 12)

| Anforderung (Abschnitt 8) | Test |
| --- | --- |
| xpcshell: adblock.txt-Parser und Suffix-Matching | `toolkit/components/fawkes/test/xpcshell/test_fawkes_adblock.js`: alle Formate, BOM, CR, Kommentar-/Nicht-unterstützt-Zähler, Duplikate, Groß-/Kleinschreibung, Punkte am Ende, Subdomains, keine Teilstring-Treffer, fehlende Datei, neueste Ladung gewinnt, `fawkes.blockedDomains`, 200 000 Einträge, blockierte Channels |
| xpcshell: LAN-Klassifikation inkl. exotischer IPv4-Schreibweisen | `test_fawkes_lan.js`: Bereichsgrenzen, Dezimal/Oktal/Hex/kurze Formen, ungültige IPv4, IPv6-Formen, Namen, `.onion`, `normalizeIPv4`, Tor-Ports, sofortiger gleicher Fehler, Schalter, lokale Top-Level-Seite, Navigationen, Weiterleitung durch öffentliche Site |
| browser: Referer | `browser/components/fawkes/test/browser/browser_fawkes_referer.js` (+ xpcshell `test_fawkes_http_switches.js`: beide Modi, auslösende Seite, Origin) |
| browser: UA in Header und navigator inkl. Worker | `browser_fawkes_googlebot.js` (+ xpcshell: Dokumente, Subressourcen, Weiterleitung auf andere Site) |
| browser: LAN-Blockade mit gleichem Fehler und gleicher Zeit | `browser_fawkes_lan.js`, ohne Tor `direct/browser_fawkes_direct_lan.js` (öffentlicher Name mit lokaler Adresse) |
| browser: Adblock-Blockade und Fehlerseite | `browser_fawkes_adblock.js`: alle Ressourcenarten, leere Frames, Fehlerseite mit „Nochmal versuchen“, Schalter, eigene Domains, Menüzähler, „keine Liste“, Einstellungen |
| HTTP/3 | xpcshell `test_fawkes_http_switches.js` (`allowHttp3`, WebTransport), `test_fawkes_tor_mode.js` (global an ohne Tor) |

## Prüfungen ohne Build

- `node --check` für alle neuen bzw. geänderten JS/MJS-Dateien (Testseite und sjs über stdin).
- `fluent.syntax` aus dem Tree: beide FTL-Dateien ohne Fehler, gleiche IDs und Attribute (131 Nachrichten).
- `ErrorList.py`-Generator: `NS_ERROR_FAWKES_BLOCKED_BY_ADBLOCK = 0x80760002`, `…_LOCAL_NETWORK_BLOCKED = 0x80760003`, `…_WEBTRANSPORT_BLOCKED = 0x80760004`.
- Static-Pref-Generator mit Präprozessor: erzeugt `fawkes_googlebot_userAgent` (`DataMutexString`) und `fawkes_referer_mode`.
- XPIDL-Parser: `nsIFawkesNetwork.idl` (Signaturen passen zu `FawkesNetworkService`), `nsISocketTransport.idl` (`FAWKES_NO_LOCAL_ADDRESSES = 131072`).
- IPDL-Parser und -Typprüfung (mit Präprozessor) für `NeckoChannelParams.ipdlh`: OK.
- TOML der drei Test-Manifeste geparst.
- Parser und Klassifikator 1:1 nach JS portiert (Scratchpad, nicht im Tree) und gegen die Erwartungstabellen der xpcshell-Tests laufen lassen: alle Erwartungen stimmen (ein Zählfehler in meinem Test gefunden und korrigiert).
- C++ von Hand gegen die Header geprüft (u. a. `StaticPrefs`-`ConstAutoLock`, `ReferrerInfo`-Konstruktor und `ReferrerPolicy()`, `nsILoadInfo::RedirectChain()`/`GetIpAddressSpace()`, `net::GetParentIPAddressSpace`, `NetAddr`, `mozilla::HashSet`, `Preferences::RegisterCallbackAndCall`, `NS_DispatchBackgroundTask`, XPIDL-`Promise`). Bei der Prüfung ersetzt: `nsTSubstring::Split` (Verhalten bei leeren Labels unklar) durch eine eigene Schleife.
- Commit-Tree gegen Arbeitsstand verglichen (67 Dateien identisch), keine Dateimodus-Änderung, keine `__pycache__`-Reste, 80 Spalten in neuem Code.
- `./mach lint` nicht ausgeführt (braucht Bootstrap, Phase 12).

## Grenzen und Hinweise für spätere Phasen

- Die Liste lädt asynchron; die ersten Requests einer Sitzung können vor ihr laufen (mit Tor steht man dann ohnehin noch auf about:torconnect).
- Bilder aus dem Bildcache einer Seite können nach dem Einschalten des Adblockers bis zum Neuladen sichtbar bleiben.
- Ohne Tor kann eine Verbindung, die eine Seite bei ausgeschaltetem LAN-Schalter aufgebaut hat, nach dem Einschalten weiterverwendet werden.
- Mit Tor erkennt der LAN-Schutz nur Literale und lokale Namen; was der Exit auflöst, sieht der Browser nicht (Tor-Exits lehnen private Adressen standardmäßig ab).
- **Phase 12**: Die Standardschalter (Referer, LAN) können Upstream-Tests stören, die Referrer erwarten oder `127.0.0.1` von anderen Sites aus laden. Kritische Stellen für den ersten Build: `FawkesNetworkService.cpp` (Lambdas mit `UniquePtr`, Promise), `FawkesLocalNetwork.cpp` (`NetAddr`, `PR_ntohl`), die `nsHttpConnectionInfo`-Klone, `ShouldBlockPreconnect` (`OriginAttributes`). Die Tests nutzen `network.loadinfo.skip_type_assertion`, `network.dns.localDomains` und `network.lna.address_space.public.override`; der WebTransport-Test in xpcshell kann an der Sicherheitsprüfung scheitern, bevor Fawkes greift.
- **Phase 5**: WebRTC/UDP im Direktmodus analog zu HTTP/3.
- **Phase 7**: Die Session-Replay-Liste kann `fawkes::AdblockList` wiederverwenden (eigener Schalter, eigene Liste).
- **Phase 10**: Mit Proxy-Kette löst der Proxy auf; die Socket-Prüfung entfällt dann automatisch, der Literal-/Namensschutz bleibt (wichtig, damit `192.168.x.x` nicht im LAN des Proxys landet).
- **Phase 11**: `Services.fawkesNetwork.isLocalHost()` (Host ohne Port) und `normalizeIPv4()` für die Validierung gescrapter Einträge.

## Manuelle Prüf-Checkliste (Phase 12)

1. Referer: https://example.com → Link/Fetch auf eine Header-Echo-Seite (z. B. httpbin) zeigt keinen `Referer`, `document.referrer` leer; „nur Cross-Site“ einstellen → Same-Site-Requests haben ihn wieder.
2. Formular-POST auf eine andere Site: `Origin` ist gleich mit und ohne Referer-Blocker.
3. Googlebot-UA für eine Site einschalten → Header-Echo und `navigator.userAgent`/`appVersion`/`platform` (auch in einem Worker) zeigen Googlebot; eine andere Site zeigt weiter Firefox.
4. Ohne Tor: HTTP/3-Testseite (z. B. cloudflare-quic.com) → mit „HTTP/3 blockieren“ HTTP/2, ausgeschaltet HTTP/3 (Netzwerkmonitor, Spalte Protokoll). Mit Tor immer ohne HTTP/3.
5. `adblock.txt` mit einigen Werbe-Domains neben die Programmdatei legen → Einstellungen zeigen Pfad und Zahlen; Werbung fehlt, Menü zählt; Top-Level-Aufruf einer gelisteten Domain zeigt die Adblock-Fehlerseite; Schalter aus → lädt. Datei entfernen und „neu laden“ → „keine Liste geladen“.
6. Eigene Domain unter „Blockierte Domains“ eintragen → wird blockiert.
7. Lokale Portscan-Testseite (öffentlich): Ports 22/80/443/8080/9150 auf `127.0.0.1` und `192.168.x.1` melden alle dasselbe, sofort; mit ausgeschaltetem Schalter unterscheiden sich offene und geschlossene Ports (dann nur noch Firefox-LNA mit Nachfrage).
8. Router-Oberfläche eintippen (`http://192.168.x.1`, `http://fritz.box` ohne Tor) → funktioniert inkl. aller Unterseiten; ein Link von einer öffentlichen Seite dorthin zeigt die LAN-Fehlerseite.
9. Ohne Tor: DNS-Rebinding-Testseite (z. B. rebind.network / singularity) → lokale Ziele werden nicht erreicht.
10. `http://127.0.0.1:9150/` eintippen → LAN-Fehlerseite, auch mit ausgeschaltetem Schalter.

## Anwendungsprobe

Index-Probe (temporärer Index, `git read-tree fawkes-base`, dann `git apply --cached` in Phasenreihenfolge):

- Sammeldateien: `phase-01-branding.patch` bis `phase-04-network.patch` bestehen `git apply --check` und ergeben den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`), `fawkes-phase-02` (`ded25fd99f13`), `fawkes-phase-03` (`aa18953cfa4f`) bzw. `fawkes-phase-04` (`dd9f9ead8e67`).
- Serien: alle Patches aus `phase-01-branding/` (6), `phase-02-framework/` (7), `phase-03-no-tor/` (8) und `phase-04-network/` (9) lassen sich anwenden und ergeben exakt den Tree von `fawkes-phase-04` (`dd9f9ead8e67`).
- **Ergebnis: grün.**

Die Probe mit `git am` im Prüf-Worktree entfällt weiterhin auf Ihren Wunsch (über sshfs zu langsam).

Während der Phase brach git zweimal mit SIGBUS bzw. einem Ein-/Ausgabefehler ab, weil das sshfs-Mount kurz weg war; die leere `index.lock` habe ich entfernt und den Schritt wiederholt (Plumbing ist wiederholbar). Das Commit-Hilfsskript wiederholt solche Fehler jetzt selbst.

Phase 4 ändert tor-browser-build nicht.
