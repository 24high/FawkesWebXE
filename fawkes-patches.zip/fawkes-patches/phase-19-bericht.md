# Phase 19 - Release-Packager und Schrift-Rechte: Bericht

## Commits

tor-browser (Stand nach `fawkes-patches/phase-18-prefs-docs.patch`).
Kombinierter Patch `phase-19-packager-fonts.patch`, ohne Einzel-Commits (der
Build-Baum `~/.cache/fawkeswebxe-src` fuehrt kein Git). Zugeordnet ueber den
Zeitstempel im Build-Baum (`artifacts/phase19b-release-package.log`,
7. November 12:52).

## Was jetzt da ist

`tools/fawkes/package-release.py` (neu, 242 Zeilen) baut aus den beiden
Build-Archiven die drei Paketdateien einer Veroeffentlichung:

- Argumente `--linux-archive`, `--windows-archive`, `--output`, `--version`,
  `--release`; Zieldateien `fawkeswebxe_<Version>-<Release>_amd64.deb`,
  `fawkeswebxe-<Version>-<Release>.x86_64.rpm`,
  `fawkeswebxe_<Version>-<Release>_windows-amd64.zip` und je `.sha256`.
  Vorhandene Zieldateien werden nicht ueberschrieben.
- `verify_app()` prueft `fawkeswebxe`/`fawkeswebxe.exe` und `tor`/`tor.exe` auf
  AMD64 (ELF bzw. PE), die Tor-Dateien `geoip`, `geoip6`, `torrc-defaults`,
  `bundle-source.json`, `bundle-signature.asc` und dass `adblock.txt` im Paket
  byte-genau der Datei `~/Downloads/adblock.txt` entspricht.
- Im Archiv wird geprueft, dass die eingebauten Schutz-Voreinstellungen stimmen
  (alle Schalter ausser `googlebotUA` und `proxyChain` sind an), dass
  `FawkesEULA.sys.mjs` vorhanden ist und `fawkes.eula.accepted` auf `false`
  steht.
- `linux_root()`: `shutil.copytree` nach `opt/fawkeswebxe`, danach Angleichung
  der Modi - Verzeichnisse und ausfuehrbare Dateien 0755, Datendateien 0644 -,
  Symlink `usr/bin/fawkeswebxe`, `usr/share/applications/fawkeswebxe.desktop`,
  `usr/share/icons/hicolor/128x128/apps/fawkeswebxe.png`.
- `dpkg-shlibdeps` ueber alle ELF-Dateien fuer die `Depends`-Zeile,
  `dpkg-deb --root-owner-group`, `rpmbuild` mit `_build_id_links none`,
  `__os_install_post %{nil}` und `__provides_exclude`/`__requires_exclude` fuer
  die privaten `.so`-Dateien; das Windows-Archiv wird unveraendert
  uebernommen.
- Veroeffentlichen erst am Ende: Hardlink in das Zielverzeichnis mit Ruecknahme,
  wenn ein Link fehlschlaegt.

### Warum die Modi

Die Build-Umgebung legt die heruntergeladenen Schriften mit dem nur fuer den
Eigentuemer lesbaren Modus des Downloads ab. Im Quellbaum sind sie Symlinks auf
`~/.mozbuild/fonts/*.ttf`; das Mozilla-Archiv loest die Symlinks auf und behaelt
0600. Im installierten Paket konnte damit kein normaler Benutzer die
gebundelten Schriften lesen. Firefox registriert `<appdir>/fonts` ueber
`FcConfigAppFontAddDir` (`gfx/thebes/gfxFcPlatformFontList.cpp`,
`MOZ_BUNDLED_FONTS`); die Tor-Voreinstellungen `font.system.whitelist` und
`font.name-list.*` (Tinos, Arimo, Cousine) schliessen die Systemschriften aus.
Ohne lesbare Schrift loest keine Schrift auf, und jedes Zeichen bekommt die
Breite eines Gevierts - daher die zu grossen Wortabstaende im Blocksatz.

## Messung

Seite `proxynova.com/proxy-articles/list-of-proxy-judges/` (lokale Kopie,
16 px Text), Median der Leerzeichenbreite:

| Stand | Median | Maximum | Mittel | Zeilen |
| --- | --- | --- | --- | --- |
| Release 18 installiert (Schriften 0600) | 16 px | 32,65 px | 9,9 px | 90 |
| dasselbe Binary mit lesbaren Schriften | 4 px | 8 px | 2,6 px | 63 |
| Release 19 installiert, 7. November | 4 px | 8 px | 2,6 px | 63 |
| Chromium als Vergleich | 4 px | - | 2,58 px | - |

## Tests

`sha256sum -c` fuer alle drei Pakete, `dpkg -c`/`rpm -qlp` auf die Modi der
Schriften (keine `-rw-------` mehr), Installation des entpackten deb als
normaler Benutzer ohne Fontconfig-Umgebung und Nachmessen der Seite
(`artifacts/phase19b-release-package.log`, `artifacts/phase19-linux-build*.log`,
`artifacts/phase19-windows-build.log`).

Nach der Installation von `fawkeswebxe_153.5.0-19_amd64.deb` ist
`/opt/fawkeswebxe/fonts` im Modus `0644 root:root`; gemessen als normaler
Benutzer ohne Fontconfig-Umgebung (`file:///tmp/opencode/pn-min.html`,
1280x900-Fenster, Tor aus) ergeben sich 63 Zeilen und Leerzeichenbreiten im
Median 4 px, Maximum 8 px, Mittel 2,6 px - deckungsgleich mit der Referenz
`/tmp/opencode/pk-19.json` der entpackten Fassung.

## Build-Status

Release 19 gebaut: `fawkeswebxe_153.5.0-19_amd64.deb` (134 924 938 Bytes),
`fawkeswebxe-153.5.0-19.x86_64.rpm` (174 303 926 Bytes),
`fawkeswebxe_153.5.0-19_windows-amd64.zip` (171 414 074 Bytes), je mit
`.sha256`; das Windows-Archiv ist byte-gleich zu Release 18.
