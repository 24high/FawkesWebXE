# Phase 7 – Verhaltens-Profiling blockieren: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-06` = `fcaa5701b8bf`, Tag `fawkes-phase-07` = `c6f3f412a55b`, Tree `2778b279eddb`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `9e0958520c4a` | Fawkes: Count blocked session replay requests in the menu |
| 2 | `0d45f8fddddf` | Fawkes: Hide scrolling and pointer movement per site |
| 3 | `5285587cf0f9` | Fawkes: Hide attention and exit intent per site |
| 4 | `0fdf5acdf589` | Fawkes: Use GetRelevantGlobal() in the JavaScript protection (Korrektur von Phase-5-Code) |
| 5 | `8c4ec6d9cbc7` | Fawkes: Coarsen the clocks of a site while the user types |
| 6 | `0f36942d2531` | Fawkes: Block session replay and heatmap providers per site |
| 7 | `e0f9cc35ec59` | Fawkes: Test the behavioral profiling protection |
| 8 | `cb18d14f1509` | Fawkes: Document the behavioral profiling protection |
| 9 | `c6f3f412a55b` | Fawkes: Make the typing windows of profiling.typing more robust (Befunde der Code-Prüfung) |

Patches: `fawkes-patches/phase-07-profiling/` (9 Dateien) und `fawkes-patches/phase-07-profiling.patch`.
Plan: `/home/dh/.claude/plans/fawkes-phase-07.md` (ohne Rückfrage umgesetzt, wie vereinbart).
Technische Doku: `browser/components/fawkes/docs/profiling.md`; die finale Tabelle Kategorie → Events/APIs → Mechanismus → Bruchrisiko steht in `browser/components/fawkes/docs/categories.md`.

## Was jetzt da ist

Alle sechs Schalter der Gruppe „Verhaltens-Profiling blockieren“ (samt „alle“) wirken jetzt in der Engine: im Event-System, im IntersectionObserver- und Lazy-Loading-Code, im Dokumentzustand, in der Timer-Präzision von nsRFPService und im Netzwerkschutz des Parent-Prozesses. Keine Erweiterung, kein eingeschleustes JavaScript. Betroffen ist nur Web-Inhalt; Browser-Code und die System-Gruppe bleiben unberührt.

- **Scroll-Tracking** (`profiling.scroll`, aus): `scroll`, `scrollend`, `wheel`, die Altformen `DOMMouseScroll`/`MozMousePixelScroll` und `contentvisibilityautostatechange` werden als Listener, `on*`-Property und `on*`-Attribut ignoriert (auch `<body onscroll>`). `IntersectionObserver` mit Callback aus Web-Inhalten meldet pro Ziel nur den ersten Zustand nach `observe()` und danach keine Änderung mehr. `loading="lazy"` bei Bildern und Iframes lädt sofort (wie bei abgeschaltetem Skripting).
- **Maus-/Touch-Bewegung** (`profiling.pointer`, aus): `mousemove`, `mouseover/out/enter/leave`, `pointermove`, `pointerover/out/enter/leave`, `pointerrawupdate`, `touchmove` werden ignoriert. Klicks, `mousedown/up`, `pointerdown/up`, `touchstart/end` und HTML-Drag-&-Drop bleiben.
- **Aufmerksamkeit/Verweildauer** (`profiling.attention`, aus): `visibilitychange` und `pagehide` werden ignoriert; `focus`/`blur`, die der Fokus-Manager an Fenster oder Dokument schickt (Tab-, Fenster-, Programmwechsel), erreichen nur noch die System-Gruppe. `document.hidden` = `false`, `visibilityState` = `"visible"`, `document.hasFocus()` = `true` für Skripte der Seite; Browser-Code, Erweiterungen und die Hintergrund-Pause sehen den echten Zustand.
- **Exit-Intent** (`profiling.exitIntent`, an): `mouseout`/`mouseleave`/`pointerout`/`pointerleave`, die beim Verlassen des Top-Level-Dokuments mit der Maus entstehen, erreichen nur die System-Gruppe; `beforeunload` wird weiter ausgelöst, aber ein abgebrochenes `beforeunload` zeigt keinen Dialog mehr.
- **Tipp-Dynamik** (`profiling.typing`, an): Tastatur-, Kompositions- und `input`-Events werden zugestellt. Jeder Tastendruck (und ein Klick/Tipp in ein Textfeld) öffnet ein „Tippfenster“ bis 2 s nach dem letzten Tastendruck; darin haben `performance.now()`, `Date.now()`/`new Date()`, `requestAnimationFrame`-, Idle- und Video-Frame-Zeitstempel sowie `event.timeStamp` (Fenster und Worker) eine Präzision von 100 ms – aufgerundet auf ein Vielfaches der RFP-Präzision, also 100,002 ms bei 16,667 ms –, mit dem Jitter von nsRFPService. Zeitstempel von Tastatur-, Kompositions- und Eingabe-Events sind immer grob; für sie gibt es keine Event-Timing-Einträge. Außerhalb der Fenster bleibt die normale Präzision (Animationen ruckeln nur beim Tippen).
- **Session-Replay & Heatmaps** (`profiling.sessionReplay`, an): eingebaute Liste (`toolkit/components/fawkes/FawkesSessionReplayDomains.inc`, 45 Domains: Hotjar, Microsoft Clarity, FullStory, Mouseflow, Smartlook, LogRocket, Contentsquare/ClickTale, Yandex Metrica Webvisor, Lucky Orange, Crazy Egg, Inspectlet, Quantum Metric, Glassbox, Decibel, SessionCam, SessionStack, Heap, PostHog, OpenReplay, Highlight, Ptengine, Zoho PageSense, Plerdy, TruConversion) wird im Parent zusätzlich zum Adblocker blockiert (`fawkes::AdblockList`, `CheckRequest()`), mit eigenem Fehler `NS_ERROR_FAWKES_SESSION_REPLAY_BLOCKED` (Modul FAWKES, 7; nächster freier: 8) und Menüzähler „Session-Replay und Heatmaps – 3 blockiert auf dieser Seite“. Keine Listen-Updates aus dem Netz.

## Entscheidungen ohne Rückfrage (bitte prüfen)

1. **IntersectionObserver: „erster Zustand“ statt Entfernen.** Entfernen (`[Func]`) hätte auf vielen Seiten ohne Feature-Detection einen `ReferenceError` ausgelöst (IntersectionObserver gibt es seit 2019 überall), Polyfills hätten auf Polling umgestellt (das Scrollen genauso sieht). „Alles sichtbar“ zu melden hätte Lazy-Loader und Infinite Scroll alles (womöglich endlos) nachladen lassen, alle stummen „Abspielen wenn sichtbar“-Videos gestartet und der Geometrie widersprochen, die die Seite selbst lesen kann. Der wahre Zustand einmal, dann nichts mehr, hält Seiten lauffähig und verrät nur, was beim ersten Layout ohnehin berechenbar ist. Folge: Nachladen beim Scrollen (Infinite Scroll, skriptbasiertes Lazy-Loading, „Scroll-Spy“-Menüs) hört auf; deshalb wird natives Lazy-Loading zu eager. Browser-interne Observer (natives Lazy-Loading, `content-visibility: auto`, Iframe-Drosselung) haben native Callbacks und sind nicht betroffen.
2. **Zusätzlich gefilterte Scroll-Signale:** die Altformen `DOMMouseScroll`/`MozMousePixelScroll` (gleichwertig zu `wheel`) und `contentvisibilityautostatechange` (feuert, wenn `content-visibility: auto`-Inhalt ins Bild scrollt).
3. **Fokus-Events: verbergen statt Listener ignorieren.** `focus`/`blur` werden nur dann verborgen, wenn der Fokus-Manager sie an Fenster oder Dokument schickt; Capture-Listener am Dokument, die den Fokus von Formularfeldern verfolgen, funktionieren weiter. **`focusin`/`focusout` bleiben unangetastet**: Gecko schickt sie nie an Fenster oder Dokument, Listener dort sehen nur Fokuswechsel zwischen Elementen; sie zu ignorieren hätte Fokusfallen modaler Dialoge (Barrierefreiheit) zerstört, ohne etwas zu verbergen. `freeze`/`resume` gibt es in Gecko nicht.
4. **`document.hidden`/`visibilityState`/`hasFocus()` lügen nur für die Seite**: über WebIDL `BinaryName` auf `Document::HiddenFromScript()` usw., die nur dann „sichtbar und fokussiert“ melden, wenn der Schalter für das Dokument **und** das Global des aufrufenden Skripts gilt. Browser-Code (Actors), Content-Scripts von Erweiterungen und C++ (Hintergrund-Pause, Medien, Timer-Drosselung) sehen den echten Zustand. `hasFocus()` ist dann auch in Frames ohne Fokus `true`.
5. **Exit-Intent: nur echte Austritte aus dem Top-Level-Dokument.** Statt `mouseout`-Listener am Dokument zu ignorieren (das hätte delegierte Hover-Menüs, z. B. jQuery `.on("mouseleave", selector)`, auf allen Seiten gebrochen – der Schalter ist standardmäßig an), werden nur die Grenz-Events verborgen, die beim Verlassen des Inhaltsbereichs ohne `relatedTarget` entstehen. Frames sind ausgenommen (sie bekommen solche Events bei jedem Verlassen des Frames). `beforeunload` läuft weiter (Seiten können Entwürfe speichern), nur der Dialog entfällt.
6. **`beforeunload`-Dialoge sind standardmäßig auf allen Seiten unterdrückt** (Auftrag: Exit-Intent „an“). Folge: Webmail und Editoren können nicht mehr vor ungespeicherten Änderungen warnen. Für solche Seiten den Schalter pro Seite ausschalten – **bitte prüfen, ob der Standard so bleiben soll**.
7. **Tipp-Dynamik: grobe Uhren nur in Tippfenstern statt dauerhaft.** Dauerhaft 100 ms hätte JavaScript-Animationen (jQuery, GSAP, Smooth-Scrolling) auf allen Seiten auf 10 Bilder/s gebracht – bei einem Standard-an-Schalter nicht akzeptabel; mit 16,7 ms (RFP) allein bleiben Tastenrhythmen messbar. Darum: Tippfenster pro Content-Prozess (zwei Slots, Atomics), Präzision `fawkes.typing.timerPrecisionMs` = 100, Dauer `fawkes.typing.windowMs` = 2000 (neue Static Prefs, auch in Workern lesbar). Die Fenstergrenzen liegen auf groben Schritten jeder Uhr und ein Fenster beginnt nie in der Vergangenheit, deshalb laufen `performance.now()`, Render- und Event-Zeitstempel nie rückwärts (geprüft, auch von der Code-Prüfung). Jitter = Zufallsmittelpunkt von nsRFPService; RFP wird nicht geschwächt (die Reduktion kommt nach der RFP-Reduktion und ist ein Vielfaches davon).
8. **Mehr als verlangt bei der Tipp-Dynamik:** auch `requestAnimationFrame`-/Idle-Zeitstempel (sonst ließe sich der Tastendruck über den nächsten Frame timen), keine Event-Timing-Einträge für Tipp-Events (`processingStart`/`duration` timen den Tastendruck), Zeitstempel von Tipp-Events immer grob, und ein Klick/Tipp in ein Textfeld öffnet schon ein Fenster, damit auch der erste Tastendruck abgedeckt ist.
9. **Session-Replay: keine Top-Level-Dokumente, nicht auf Anbieterseiten.** Top-Level-Navigationen werden nie blockiert (man kann die Websites der Anbieter besuchen), und auf einer Top-Level-Site, die selbst auf der Liste steht, gilt die Liste nicht (deren eigene Seiten funktionieren). Dadurch braucht es keine Fehlerseite; blockierte Frames bleiben leer. Geprüft wird vor dem Adblocker und unabhängig davon, mit eigenem Fehlercode und Zähler (`fawkes-request-blocked` mit `sessionReplay`). Yandex Metrica nimmt Webvisor mit demselben Tag auf wie die Statistik – blockiert wird Metrica daher ganz (dokumentiert). Nur Domains, bei denen ich sicher bin, dass sie die Aufnahmeskripte ausliefern oder die Aufnahmen empfangen; CloudFront-Hosts nur mit ihrer exakten Distribution (Lucky Orange, Crazy Egg).
10. **Korrektur von Phase 5**: `DOMEventTargetHelper::GetOwnerGlobal()` gibt es in ESR 153 nicht (nur `GetRelevantGlobal()`); fünf Phase-5-Hooks (OffscreenCanvas, AnalyserNode, ScriptProcessorNode, SpeechSynthesis, Performance) hätten nicht kompiliert. Eigener Commit 4. Für Phase 12 ist damit zu rechnen, dass weitere solche API-Abweichungen aus früheren Phasen auftauchen.

## Geänderte Upstream-Dateien (dünne Hooks, für spätere Rebases)

| Datei | Änderung |
| --- | --- |
| `dom/base/DOMIntersectionObserver.cpp` | `Update()`: Observer von Web-Inhalten nur erster Zustand |
| `dom/base/Element.cpp` | `MaybeStartLazyLoading()`: eager bei `profiling.scroll` |
| `dom/base/nsFocusManager.cpp` | `FocusBlurEvent::Run`: Fenster-/Dokument-Fokus nur System-Gruppe |
| `dom/webidl/Document.webidl`, `dom/base/Document.{h,cpp}` | `BinaryName` für `hidden`, `visibilityState`, `hasFocus()`; `…FromScript()` |
| `dom/events/EventStateManager.cpp` | `DispatchMouseOrPointerBoundaryEvent`: Exit-Events; `PreHandleEvent`: Tippfenster |
| `layout/base/nsDocumentViewer.cpp` | `DispatchBeforeUnload`: kein Dialog |
| `dom/performance/Performance.cpp` | `Now()`, `TimeStampToDOMHighResForRendering()` (+ Korrektur `GetRelevantGlobal()`) |
| `dom/events/Event.cpp` | `TimeStamp()` (Fenster und Worker) |
| `toolkit/components/resistfingerprinting/nsRFPService.cpp` | `ReduceTimePrecisionAsUSecsWrapper` (JS `Date`) |
| `dom/performance/PerformanceEventTiming.cpp` | keine Einträge für Tipp-Events |
| `modules/libpref/init/StaticPrefList.yaml` | `fawkes.typing.timerPrecisionMs`, `fawkes.typing.windowMs` |
| `docshell/base/nsDocShell.cpp` | `FilterStatusForErrorPage`: Session-Replay-Frames leer |
| `xpcom/base/ErrorList.py`, `js/xpconnect/src/xpc.msg` | `NS_ERROR_FAWKES_SESSION_REPLAY_BLOCKED` (7) |
| `dom/canvas/CanvasUtils.cpp`, `dom/media/webaudio/AnalyserNode.cpp`, `ScriptProcessorNode.cpp`, `dom/media/webspeech/synth/SpeechSynthesis.cpp` | Korrektur `GetRelevantGlobal()` |

Neuer Code: `toolkit/components/fawkes/` (`FawkesTiming.{h,cpp}`, `FawkesSessionReplayDomains.inc`, Erweiterungen in `FawkesDom.{h,cpp}`, `FawkesNetwork.cpp`, `FawkesNetworkService.{h,cpp}`, `nsIFawkesNetwork.idl` mit `isSessionReplayHost()`/`sessionReplayDomainCount`, `moz.build`) und `browser/components/fawkes/` (Zähler in `Fawkes.sys.mjs`, ein String in en-US/de, `docs/profiling.md`, `categories.md`, `architecture.md`, `js-apis.md`, `network.md`).

## Tests (geschrieben, laufen erst in Phase 12)

| Anforderung (Abschnitt 8) | Test |
| --- | --- |
| Scroll-Tracking mit lokaler Testseite, aus/an, andere Site, Browser-Listener | `browser_fawkes_profiling_scroll.js`: Listener/Property/Attribut an Fenster, Dokument, Element; echtes Scrollen; IntersectionObserver (`[false, true]` vs. `[false]`); Lazy-Bild und -Iframe über Zähl-Server |
| Maus-/Touch-Bewegung | `browser_fawkes_profiling_pointer.js`: alle Typen, echte Mausbewegungen (`synthesizeMouse`), Klicks kommen an |
| Aufmerksamkeit | `browser_fawkes_profiling_attention.js`: Listener, Hintergrund-Tab (`hidden`, `visibilityState`, `hasFocus()` für Seite vs. Browser-Code), keine Fenster-Fokus-Events, Element-Fokus und `focusin` funktionieren |
| Exit-Intent | `browser_fawkes_profiling_exit.js`: Maus über den Parent aus der Seite auf die Adressleiste bewegt (Austritts-Events nur ohne Schalter), `beforeunload`-Dialog ohne/mit Schalter, Handler läuft trotzdem, andere Site fragt weiter |
| Tipp-Dynamik | `browser_fawkes_profiling_typing.js`: Uhren vor/während/nach dem Tippen (Seite, rAF, Worker), Zeitstempel von `keydown`/`keyup`/`input` immer grob, Klick ins Textfeld, ohne Schalter, Monotonie über beide Fenstergrenzen, Event Timing, andere Site |
| Session-Replay | `browser_fawkes_profiling_session_replay.js`: Skript, `fetch`, Bild, WebSocket, Frame (leer), Zähler im Menü, kein Request erreicht `http-on-opening-request`, Schalter aus, andere Site; xpcshell `test_fawkes_session_replay.js`: Listen-Treffer inkl. Subdomains/Groß-/Kleinschreibung/Punkt am Ende, keine Teilstring-Treffer, Channels (Subressource blockiert, Top-Level-Dokument und Anbieterseite nicht, Schalter aus, unabhängig vom Adblocker) |

Hilfsdateien: `head_profiling.js`, `file_fawkes_profiling.html`, `file_fawkes_profiling_worker.js`; Zähl-Server `file_fawkes_counter.sjs` aus Phase 5.

## Prüfungen ohne Build

- **Code-Prüfung durch einen separaten Prüf-Agenten** (nur lesend, gegen die Header des Trees und Searchfox ESR 153): keine Compile-Fehler gefunden; alle verwendeten APIs, Signaturen, Konstness, Namensräume, Codegen von `BinaryName`, Unified-Build-Namen, Static-Pref-Namen geprüft. Seine Befunde zur Logik habe ich in Commit 9 umgesetzt (alte Event-Zeitstempel nach dem Vergessen eines Fensters immer grob; Klick ins Textfeld öffnet ein Fenster; Basis `TimeStamp::FirstTimeStamp()` statt des lazy und ohne Sperre berechneten `ProcessCreation()`; ehrlichere Kommentare/Doku zu `Date.now()` und den Grenzen pro Prozess) bzw. als Grenzen dokumentiert. Er hat auch bestätigt, dass `GetOwnerGlobal()` im Tree nicht existiert.
- **WebIDL-Parser** aus dem Tree über alle Dateien (mit Präprozessor und Stubs): fehlerfrei; `hidden`/`visibilityState`/`hasFocus` tragen die `BinaryName`-Werte.
- **XPIDL-Parser**: `nsIFawkesNetwork.idl` erzeugt `IsSessionReplayHost(const nsACString&, bool*)` und `GetSessionReplayDomainCount(uint32_t*)`, passend zur Implementierung.
- **Static-Pref-Generator** mit Präprozessor: erzeugt `fawkes_typing_timerPrecisionMs` und `fawkes_typing_windowMs` (`RelaxedAtomicUint32`).
- **`ErrorList.py`-Generator**: `NS_ERROR_FAWKES_SESSION_REPLAY_BLOCKED = 0x80760007`, keine Kollision im Modul.
- `fluent.syntax`: beide FTL-Dateien fehlerfrei, gleiche IDs (135 Nachrichten).
- `node --check` für `Fawkes.sys.mjs`, alle neuen Tests, `head_profiling.js`, den Worker und die Inline-Skripte der Testseite; `browser.toml` und `xpcshell.toml` mit `tomllib` geparst, alle `head`- und `support-files`-Pfade existieren.
- 80 Spalten in neuem Code (außer FTL-Strings und `xpc.msg`, wie dort üblich).
- Commit-Tree gegen Arbeitsstand (50 Dateien identisch), keine Dateimodus-Änderung, keine `__pycache__`/`parser.out`-Reste.
- `./mach lint` nicht ausgeführt (braucht Bootstrap, Phase 12).

## Grenzen (ehrlich, auch in `profiling.md`)

- **Polling lässt sich nicht verhindern**, ohne die meisten Seiten zu brechen: `scrollY`, `getBoundingClientRect()`, `matches(":hover")`, `document.activeElement` per Timer/rAF, immer neue IntersectionObserver (bzw. `unobserve`/`observe`), Frame-Zeiten.
- Scroll-Tiefe zeigt sich auch an später geladenen Dingen (per Skript eingefügte Bilder, CSS-Bilder von `content-visibility: auto`-Inhalt); scroll-getriebene Animationen deckt `css.scrollAnimations` ab.
- Pointer: Positionen von Klicks und `dragover` bleiben sichtbar; `:hover`-Bilder deckt `css.interaction` ab.
- Aufmerksamkeit: fokussierte Formularfelder bekommen beim Tab-/Fensterwechsel weiter `blur`/`focus`; Hintergrund-Tabs bekommen weniger Frames und gedrosselte Timer (messbar).
- Exit-Intent: Bewegung Richtung Seitenoberkante braucht `profiling.pointer`, Fokusverlust (Klick in die Adressleiste) `profiling.attention`; Exit-Events in Frames bleiben.
- **„Verborgene“ Events erreichen auch Content-Scripts von Erweiterungen nicht** (Fenster-Fokus/-Blur, Exit-Events): `mOnlySystemGroupDispatchInContent` überspringt alle Listener der Standardgruppe auf Inhaltszielen. Browser-Code (Actors, System-Gruppe) ist nicht betroffen. NoScript nutzt diese Events nicht.
- Tipp-Dynamik: Mittelwerte über viele Tastendrücke nähern sich weiter den echten Werten (die Rundung mit Jitter ist erwartungstreu) – grobe Uhren verlangen nur viel mehr Stichproben. Der erste Tastendruck nach einer Pause hat die normale Präzision, außer man hat vorher ins Feld geklickt. Nicht abgedeckt: Zählschleifen mit `setTimeout()`/`postMessage()`, `SharedArrayBuffer`-Zähler (nur cross-origin-isolierte Seiten), `AudioContext.currentTime`, Medien-`currentTime`, CSS-Animations-Events, `document.timeline`, rAF in Workern. Tippfenster gelten pro Content-Prozess: Frames anderer Sites in anderen Prozessen und Shared Worker sehen sie nicht (eine Seite könnte Tastendrücke an so einen Frame weiterreichen); andere Seiten desselben Prozesses bekommen beim Tippen ebenfalls grobe Uhren; ohne Fission (in Tor Browser auf dem Desktop an) könnte eine Site am eigenen Uhrverhalten erkennen, dass auf einer anderen Site desselben Prozesses getippt wird. `Date.now()` kann an einer Fenstergrenze sehr selten um bis zu einen groben Schritt zurückspringen (folgt der Wanduhr). Content-Scripts, die `performance.now()` der Seite lesen, bekommen deren Präzision.
- Session-Replay: Dienste hinter Erstanbieter-Proxys/CNAMEs, selbst gehostetes PostHog/OpenReplay oder in eigene Bundles eingebaute Skripte stehen nicht auf der Liste.

## Hinweise für spätere Phasen

- **Phase 8** (Randomisierung) ändert ebenfalls nsRFPService/Timer: die Tipp-Reduktion muss nach der RFP-Reduktion bleiben, und der grobe Schritt muss ein Vielfaches der RFP-Präzision sein (`BaseResolutionUSec()` in `FawkesTiming.cpp` spiegelt `GetTimerPrecisionType()`; bei Änderungen dort anpassen).
- **Phase 12**: neue kritische Stellen für den ersten Build: `FawkesTiming.cpp` (nsRFPService-Typen, `Atomic`-Array), `Document.webidl` `BinaryName` (Codegen), `DOMIntersectionObserver.cpp` (Variant-`as<>()` → `CallbackObject*`), die `FawkesSessionReplayDomains.inc`-Einbindung im Konstruktor. Standard-an-Schalter, die Upstream-Tests stören können: `profiling.exitIntent` (beforeunload-Dialog-Tests, Maus-Austritts-Tests), `profiling.typing` (Timer-Präzisions-Tests nach Tastatureingaben in Web-Inhalten), `profiling.sessionReplay` (unwahrscheinlich). Dort ggf. per `Services.fawkes.setDefault()` im Harness abschalten.

## Manuelle Prüf-Checkliste (Phase 12)

1. Lange Nachrichtenseite (z. B. golem.de) mit „Scroll-Tracking“ an: Seite funktioniert, Bilder weiter unten sind sofort geladen (Netzwerkmonitor, ohne Scrollen); Infinite-Scroll-Seite lädt nicht mehr nach (erwartet); aus → normal.
2. Seite mit Hover-Menü und eine Drag-&-Drop-Seite mit „Maus-/Touch-Bewegung“ an: Menü/Ziehen funktionieren nicht (erwartet); Klicks gehen.
3. Testseite, die `document.hidden`, `visibilityState`, `hasFocus()` und `visibilitychange`/`blur` protokolliert (z. B. eine einfache lokale Seite): mit „Aufmerksamkeit“ an → beim Tab-Wechsel nichts, Werte „sichtbar/fokussiert“; Videoplayer pausiert nicht im Hintergrund; mit „Hintergrund-Pause“ zusätzlich an → Seite pausiert trotzdem (echter Zustand).
4. Seite mit Exit-Intent-Popup (Newsletter-Layer beim Verlassen nach oben): kein Popup beim Herausfahren mit der Maus; Seite mit „Seite wirklich verlassen?“-Abfrage (Formular-Editor) → kein Dialog beim Wegnavigieren, mit Schalter aus wieder Dialog.
5. Tipp-Dynamik: Keystroke-Demo (z. B. eine Seite, die `keydown`-Zeitstempel und `performance.now()` anzeigt): während des Tippens nur Vielfache von ~100 ms, 2 s nach dem Tippen wieder fein; Animationen laufen außerhalb des Tippens flüssig.
6. Seite mit Hotjar oder Microsoft Clarity (z. B. viele Shop- oder Medienseiten): Netzwerkmonitor zeigt keine Requests an `*.hotjar.com`/`clarity.ms`, Menü „Session-Replay und Heatmaps – N blockiert“; hotjar.com selbst lässt sich öffnen und funktioniert.
7. NoScript, Reader View, PDF.js, about:-Seiten mit allen Profiling-Schaltern an → unverändert.

## Anwendungsprobe

Index-Probe (temporärer Index, `git read-tree fawkes-base`, dann `git apply --cached` in Phasenreihenfolge):

- Sammeldateien: `phase-01-branding.patch` bis `phase-07-profiling.patch` bestehen `git apply --check` und ergeben den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`), `fawkes-phase-02` (`ded25fd99f13`), `fawkes-phase-03` (`aa18953cfa4f`), `fawkes-phase-04` (`dd9f9ead8e67`), `fawkes-phase-05` (`33768452f3ad`), `fawkes-phase-06` (`6d56d5b6daa0`) bzw. `fawkes-phase-07` (`2778b279eddb`).
- Serien: alle Patches aus `phase-01-branding/` (6), `phase-02-framework/` (7), `phase-03-no-tor/` (8), `phase-04-network/` (9), `phase-05-js-apis/` (10), `phase-06-css/` (8) und `phase-07-profiling/` (9) lassen sich anwenden und ergeben exakt den Tree von `fawkes-phase-07` (`2778b279eddb`).
- **Ergebnis: grün.** (Eine erste Probe vor dem Korrektur-Commit 9 war ebenfalls grün; nach Commit 9 wurden Tag und Patches neu erzeugt und erneut geprüft.)

Die Probe mit `git am` im Prüf-Worktree entfällt weiterhin auf Ihren Wunsch (über sshfs zu langsam).

Phase 7 ändert tor-browser-build nicht.
