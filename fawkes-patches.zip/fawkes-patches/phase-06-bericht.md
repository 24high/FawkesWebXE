# Phase 6 – CSS-Kategorien im Stylesystem, eigene CSS-Muster: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-05` = `70d20508417c`, Tag `fawkes-phase-06` = `fcaa5701b8bf`, Tree `6d56d5b6daa0`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `0ad03cfc677c` | Fawkes: Share the pattern compiler between scripts and stylesheets |
| 2 | `80e4c316709d` | Fawkes: Fix CSS media features per site |
| 3 | `aa8e18e2507b` | Fawkes: Ignore local() fonts of @font-face rules per site |
| 4 | `5cdead8aab3e` | Fawkes: Do not load images of interaction-dependent rules |
| 5 | `7663caa48754` | Fawkes: Turn off scroll-driven animations and env() insets per site |
| 6 | `7c70453ff748` | Fawkes: Drop stylesheets that match the custom stylesheet patterns |
| 7 | `497e3eb32fd0` | Fawkes: Test the CSS protection |
| 8 | `fcaa5701b8bf` | Fawkes: Document the CSS protection |

Patches: `fawkes-patches/phase-06-css/` (8 Dateien) und `fawkes-patches/phase-06-css.patch`.
Plan: `/home/dh/.claude/plans/fawkes-phase-06.md` (ohne Rückfrage umgesetzt, wie vereinbart).
Technische Doku: `browser/components/fawkes/docs/css.md`; die finale Tabelle Kategorie → Funktionen → Mechanismus → Bruchrisiko steht in `browser/components/fawkes/docs/categories.md`.

## Was jetzt da ist

Alle CSS-Schalter wirken jetzt in der Engine – im Stylesystem (Stylo und Geckos Style-Code) und im CSS-Loader –, ohne Erweiterung und ohne eingeschleustes CSS oder JavaScript. Betroffen ist nur Web-Inhalt; Browser- und UA-Stylesheets, about:, PDF.js und Erweiterungsseiten bleiben unverändert. Wie bei den DOM-Schaltern gelten Änderungen nach dem Neuladen.

- **Media-Query-Fingerprinting** (`css.mediaQueries`, aus): `Document::ShouldResistFingerprinting()` antwortet für alle CSS-Ziele von RFP mit „ja“, wenn der Schalter an ist. Dadurch liefern `device-width/-height`, `device-aspect-ratio`, `resolution` und die Pixel-Ratio-Features, `color`, `color-gamut`, `prefers-color-scheme`, `prefers-reduced-motion`, `prefers-reduced-transparency`, `prefers-contrast`, `inverted-colors`, `video-dynamic-range`, `pointer`/`any-pointer` und `hover`/`any-hover` die RFP-Werte – auch dann, wenn RFP für die Seite gelockert ist. Zusätzlich: `display-mode` immer `browser`, `forced-colors` immer `none`, und das verwendete Farbschema (für `light-dark()`, Systemfarben, Formularelemente) folgt `prefers-color-scheme: light`. Die `-moz-*`-Plattform-Features sind ohnehin nur für Browser- und UA-Stylesheets sichtbar.
- **Schriften-Enumeration** (`css.localFonts`, an): `local()`-Quellen von `@font-face`-Regeln werden übersprungen (`fawkes::IgnoreLocalFontSources`, erweitert um Regeln); eine Regel nur mit `local()` hat keine Schrift, eine mit `url()`-Ersatz lädt diesen.
- **CSS-Interaktions-Tracking ohne JS** (`css.interaction`, an): Stylo markiert beim Parsen von Autoren-Stylesheets die `url()`-Werte von Regeln, deren Selektoren einen Interaktionszustand oder das `value`-Attribut prüfen (auch in `:is()`, `:where()`, `:not()`, `:has()`, `:nth-child(… of …)`, verschachtelten Regeln und `@scope`). Der Bildlader lädt solche Bilder auf Seiten mit dem Schalter nicht (außer lokalen Ressourcen wie `data:`). Betroffen sind alle CSS-Bilder: `background`, `border-image`, `mask-image`, `list-style-image`, `content`, `cursor`, `shape-outside`, `image-set()`.
- **Scroll-getriggerte Animationen** (`css.scrollAnimations`, aus): Animationen mit `scroll()`, `view()` oder benannten Fortschritts-Timelines bekommen keine Timeline (wie `animation-timeline: none`).
- **Umgebungswerte** (`css.env`, aus): `env(safe-area-inset-*)` ist 0.
- **Eigene Stylesheet-Muster** (`css.customPatterns`, aus; `fawkes.patterns.css`): passende Stylesheets werden vor dem Parsen verworfen – extern (`<link>`, `@import`, Preloads, Early Hints) als Ladefehler mit `error`-Event, inline als leeres Stylesheet; der Stylesheet-Cache wird umgangen.

## Entscheidungen ohne Rückfrage (bitte prüfen)

1. **`css.interaction`: „gar nicht laden“ statt „alles vorab laden“.** Begründung: Nur so hängt kein einziger Request von der Interaktion ab, unabhängig von Cache-Headern. Vorabladen hätte bei Keylogger-Stylesheets Tausende Requests pro Seite über Tor erzeugt, wäre durch `no-store`, Cache-Verdrängung oder geteilte Stylesheets anderer Dokumente auszuhebeln gewesen (dann doch ein zweiter Request nach der Interaktion), und SVG-Ressourcen und Schriften laufen über andere Lader. Ich habe zusätzlich geprüft, ob sich bereits geladene Bilder (Sprites) „nur aus dem Cache“ zeigen lassen: `nsHttpChannel` würde mit `LOAD_ONLY_FROM_CACHE` wirklich nichts ins Netz schicken (keine Proxy-Auflösung, kein DNS-Prefetch, kein Preconnect), aber `imgLoader` reicht dieses Flag nicht an den Channel weiter (es maskiert die Load-Flags), und seine Ausweichpfade (CORS-Modus, Sicherheitsprüfungen) könnten einen neuen Request auslösen. Deshalb bleibt es beim robusten Nicht-Laden; die Sprite-Grenze ist dokumentiert.
2. **Was als Interaktion zählt** (Liste in `css.md`): alle Pseudoklassen über die Element-Zustandsbits (dadurch auch Aliase wie `:-moz-focusring`, `:-moz-ui-invalid`): `:hover`, `:active`, `:focus`, `:focus-visible`, `:focus-within`, `:checked`, `:indeterminate`, `:target`, `:placeholder-shown`, Validität (`:valid`, `:invalid`, `:user-*`), `:in-range`/`:out-of-range`, `:autofill`, `:open`, `:popover-open`, `:modal`, `:fullscreen`, `:-moz-drag-over`, Medienzustände (`:playing`, `:paused`, `:seeking`, `:buffering`, `:stalled`, `:muted`, `:picture-in-picture`), außerdem `:-moz-window-inactive` (Fensterwechsel) und Attributselektoren auf `value` (jeder Operator, jede Schreibweise). Bewusst nicht: `:visited` (Gecko lädt dort ohnehin keine Bilder), strukturelle und statische Zustände (`:empty`, `:disabled`, `:required`, `:default`, …), `:state()` (nur per Skript). Eine Regel gilt als abhängig, wenn **irgendein** Selektor ihrer Liste abhängig ist, auch innerhalb von `:not()` (z. B. `:not(:placeholder-shown)` verrät Tippen).
3. **Markieren unabhängig von der Site, Durchsetzen pro Dokument.** Die Markierung hängt nur am Stylesheet-Text (Bit `LoadDataFlags::FAWKES_INTERACTION` am URL-Wert), damit geteilte Stylesheets teilbar bleiben und Stylo off-main-thread nichts über Dokumente wissen muss; entschieden wird im Hauptthread im Bildlader mit den Flags des Dokuments. Nur Autoren-Stylesheets werden markiert; lokale Ressourcen (`URI_IS_LOCAL_RESOURCE`: `data:`, `blob:`, `chrome:`, `resource:`, `moz-extension:`) werden immer geladen, weil sie keinen Server erreichen (eigene Checkbox-Grafiken als `data:` funktionieren).
4. **`css.mediaQueries` = RFP-Werte.** Statt eigener Konstanten nutze ich die RFP-Werte (über einen Hook in `Document::ShouldResistFingerprinting(RFPTarget)` nur für die CSS-Ziele). So sind CSS und JavaScript unter RFP konsistent, und Phase 8 hat eine Stelle zum Randomisieren. In Tor Browser mit RFP ist der Schalter größtenteils schon erfüllt; er wirkt, wenn RFP für die Site gelockert ist, und ergänzt `display-mode`, `forced-colors` und das verwendete Farbschema. `scripting` bleibt unverändert (verrät den Skriptzustand/NoScript, nicht das Gerät; ein falscher Wert würde Seiten mit `<noscript>`-Layouts brechen).
5. **`forced-colors: none`, auch wenn Farben erzwungen werden.** Der Schalter ändert nur die Abfrage, nicht die Darstellung (Barrierefreiheit). Seiten können erzwungene Farben weiterhin an berechneten Farben erkennen; Nutzer mit Hochkontrast sollten den Schalter aus lassen (dokumentiert).
6. **`css.scrollAnimations`: keine Timeline statt Parse-Fehler.** Pro Dokument entscheiden geht nur beim Erzeugen der Animation (`nsAnimationManager`); beim Parsen kennt Stylo die Seite nicht (geteilte Stylesheets). Folge: `@supports` meldet weiterhin Unterstützung. Scroll-getriebene Animationen sind in ESR nur in Nightly aktiv (`layout.css.scroll-driven-animations.enabled`); solange die Pref aus ist, zeigt das Menü den Punkt angehakt und deaktiviert („von dieser Version nicht unterstützt“, wie WebRTC in Phase 5). Container-Scroll-State-Queries sind in Gecko aus.
7. **`css.env`: nur die vier Safe-Area-Insets.** Mehr Geräte-Metriken gibt `env()` an Web-Inhalte nicht heraus (`scrollbar-inline-size`, `hairline`, `-moz-gtk-*` sind nur für Browser-Stylesheets; `--*`-Link-Parameter kommen von der einbettenden Seite). `env(titlebar-area-*)` und `env(keyboard-inset-*)` gibt es in Gecko nicht. Auf dem Desktop sind die Insets ohnehin 0.
8. **`css.customPatterns`: Semantik wie bei den Skript-Mustern**, normale Pref `fawkes.patterns.css` (wie `fawkes.patterns.js`). Externe Treffer → Ladefehler mit neuem Code `NS_ERROR_FAWKES_STYLESHEET_BLOCKED` (Modul FAWKES, 6; nächster freier: 7), damit fehlgeschlagene Ladevorgänge nie in den geteilten Cache kommen; inline → leeres Stylesheet (der Inline-Cache wird umgangen).
9. **Muster-Prüfung im `StreamLoader` statt Abschalten der Off-Main-Thread-Zustellung.** Externe Stylesheets werden off-main-thread dekodiert. Mein erster Ansatz (für Musterseiten nicht umleiten) hätte `OnStopRequest` zweimal im Hauptthread laufen lassen und den Parse-Blocker doppelt freigegeben (Promise könnte vor Ende des Parsens auflösen). Stattdessen: `FawkesPatterns` gibt jetzt unveränderliche, referenzgezählte Mustersätze heraus (`RustRegexSet` ist laut Header thread-sicher), der `StreamLoader` holt sie in `OnStartRequest` (Hauptthread) und prüft vor `ParseSheet` über den vorhandenen Fehlerpfad. Dafür habe ich den Phase-5-Code (`FawkesScriptPatterns`) auf den gemeinsamen Compiler umgestellt (Commit 1 und 6).
10. **Nicht abgedeckt (dokumentiert):** bei `css.interaction` Umwege über Custom Properties (`var()`), `@keyframes`, per Interaktion eingeblendete Teilbäume (`display`), Container-Style-Queries, `font-family`-Wechsel und `unicode-range`-Schriften-Keylogger (alle Web-Fonts vorab zu laden hätte jede Site die Bandbreite aller deklarierten Schriften gekostet), externe SVG-Ressourcen (`filter`, `clip-path`, `mask`, `marker`, Paint-Server); bei `css.customPatterns` konstruierbare Stylesheets, `style`-Attribute und CSSOM-Änderungen.

## Geänderte Upstream-Dateien (dünne Hooks, für spätere Rebases)

| Datei | Änderung |
| --- | --- |
| `dom/base/Document.cpp` | `ShouldResistFingerprinting(RFPTarget)` fragt `fawkes::FixesMediaFeature()` (1 Ausdruck + Include) |
| `layout/style/nsMediaFeatures.cpp` | `display-mode` → `browser`; neue Funktion `Gecko_MediaFeatures_FawkesFixed` |
| `layout/style/GeckoBindings.h` | Deklaration `Gecko_MediaFeatures_FawkesFixed` |
| `layout/style/GeckoBindings.cpp` | `Gecko_GetSafeAreaInsets` → 0 bei `css.env` |
| `layout/style/ImageLoader.cpp` | `LoadImage` fragt `fawkes::IgnoreInteractionImage()` |
| `layout/style/nsAnimationManager.cpp` | `GetTimeline`, `GetNamedProgressTimeline` → keine Timeline bei `css.scrollAnimations` |
| `layout/style/Loader.cpp` | `ShouldBypassCache`, `LoadInlineStyle` (Inline-Cache, leeres Sheet) |
| `layout/style/StreamLoader.{h,cpp}` | Mustersatz in `OnStartRequest`, Prüfung vor `ParseSheet` |
| `servo/components/style/gecko/media_features.rs` | `forced-colors` fragt `Gecko_MediaFeatures_FawkesFixed` |
| `servo/components/style/parser.rs` | Feld `NestingContext::fawkes_interaction` |
| `servo/components/style/stylesheets/rule_parser.rs` | Flag für Style-Regeln und `@scope` setzen/zurücksetzen |
| `servo/components/style/url/gecko.rs` | Bit `LoadDataFlags::FAWKES_INTERACTION` beim Erzeugen von `CssUrl` |
| `servo/components/style/lib.rs` | `pub mod fawkes;` |
| `xpcom/base/ErrorList.py`, `js/xpconnect/src/xpc.msg` | `NS_ERROR_FAWKES_STYLESHEET_BLOCKED` (6) |

Neuer Code: `servo/components/style/fawkes.rs` (Selektor-Analyse), `toolkit/components/fawkes/FawkesCss.{h,cpp}`, `FawkesPatterns.{h,cpp}` (gemeinsamer Muster-Compiler), Änderungen in `FawkesDom.{h,cpp}`, `FawkesScriptPatterns.cpp`, `moz.build`; `browser/components/fawkes/` (Menüpunkt Scroll-Animationen in `Fawkes.sys.mjs`, zwei Strings in en-US/de, `docs/css.md`, `categories.md`, `architecture.md`, `js-apis.md`).

## Tests (geschrieben, laufen erst in Phase 12)

| Anforderung (Abschnitt 8) | Test |
| --- | --- |
| Media-Features mit lokaler Testseite, aus/an, andere Site | `browser_fawkes_css_media.js`: RFP aus, System-Präferenzen per `ui.*`-Prefs und Farbschema-Override verstellt; reduzierte Bewegung/Transparenz, invertierte Farben, Farbschema inkl. `light-dark()`, Zeiger/Hover, `display-mode` (über `BrowsingContext.displayMode`), `device-width`, `forced-colors` (mit `browser.display.document_color_use=2`); in Release-Builds mit gesperrtem RFP wird nur protokolliert |
| `local()`-Schriften | `browser_fawkes_css_fonts.js`: Regel nur mit `local()` hat keine Schrift, Regel mit `url()`-Ersatz lädt diesen (Zähl-Server); andere Site |
| Interaktion | `browser_fawkes_css_interaction.js`: `:hover` (echte Mausbewegung), `:checked`, `[value$=…]`, `:has()`, verschachtelte Regel, `@scope`, `:target`, externes Stylesheet; Zähl-Server zählt Bildrequests; aus/an/andere Site; unabhängige Bilder laden weiter |
| `env()` und Scroll-Animationen | `browser_fawkes_css_env_animations.js`: `env(safe-area-inset-top)` = 0, unbekannte Variablen behalten ihren Fallback; mit eingeschalteter Pref `scroll()`, `view()`, benannte Timeline ohne/mit Schalter |
| Eigene Muster | `browser_fawkes_css_patterns.js`: Teilstring ohne Groß-/Kleinschreibung, Regex, `.`-Regex, inline/extern/`@import`, Cache aus dem vorigen Lauf, keine Muster, andere Site |
| Menü | `browser_fawkes_button.js` angepasst (Scroll-Animationen ohne Engine-Unterstützung angehakt und deaktiviert) |

Hilfsdateien: `head_css.js`, `file_fawkes_css.html`, `file_fawkes_css_interaction.css`, `file_fawkes_css_patterns.html` und `file_fawkes_css_patterns_{marked,clean,import,imported}.css`; Zähl-Server `file_fawkes_counter.sjs` aus Phase 5.

## Prüfungen ohne Build

- **Selektor-Analyse gegen das echte `selectors`-Crate** (Kopie im Scratchpad, offline mit `third_party/rust`, Test mit dessen Dummy-Implementierung): `a:hover`, `:active >`, `[value$="a"]`, `[VALUE^=x]`, `[value]`, Selektorlisten, `:is()`, `:where()`, `:not(:hover)`, `:has(input:hover)`, `:has(> [value=""])`, `:nth-child(2 of :hover)`, `::slotted(:hover)`, `:host(:hover)`, `a:hover::before` als abhängig; `a`, Kombinatoren, `[data-value]`, `[type=checkbox]`, `:is(.a, .b)`, `:has(.y)`, `:nth-child(2 of .z)`, `:lang(en)`, `::before` als unabhängig; `@scope`-Grenzen über `Option`-Ketten – alles grün.
- **`const`-Bitmaske** der Zustände mit dem vendorten `bitflags` 2.10 in einem Mini-Crate kompiliert (`from_bits_retain`/`bits` sind `const fn`).
- **`rustfmt --check`** (Konfiguration `servo/rustfmt.toml`) für `fawkes.rs`, `parser.rs`, `rule_parser.rs`, `url/gecko.rs`, `media_features.rs`: sauber.
- `ErrorList.py`-Generator: `NS_ERROR_FAWKES_STYLESHEET_BLOCKED = 0x80760006`, keine Kollision, im erzeugten Header.
- `fluent.syntax`: beide FTL-Dateien fehlerfrei, gleiche IDs (134 Nachrichten).
- `node --check` für `Fawkes.sys.mjs`, alle neuen Tests, `head_css.js`, den Button-Test und die Inline-Skripte der Testseiten; `browser.toml` mit `tomllib` geparst, alle `head`- und `support-files`-Pfade existieren.
- C++ von Hand gegen die Header geprüft, u. a.: `StyleLoadDataFlags::FAWKES_INTERACTION` (cbindgen erzeugt Bitflags-Konstanten als assoziierte Konstanten), `StyleComputedUrl::LoadData() const`, Vorwärtsdeklaration `struct StyleComputedUrl` wie in `ImageLoader.h`, `enum class RFPTarget : uint64_t`, `nsPresContext::Document() const`, `StyleAnimationTimeline::Tag`, `FontFaceSetImpl::GetDocument()`, `RustRegexSet` (implizites Move, Template-Konstruktor greift nicht), `NS_INLINE_DECL_THREADSAFE_REFCOUNTING`, `do_AddRef(const RefPtr&)`, `nsTStringRepr::operator string_view`, `rure.h` global exportiert, der Fehlerpfad in `StreamLoader::OnStopRequest` (identisch zum vorhandenen Prüfungs-Fehlerpfad, auch off-main-thread), `MarkLoadTreeFailed` (Elternsheet eines verworfenen `@import` meldet `error`), `SharedStyleSheetCache::InsertIfNeeded` (fehlgeschlagene Ladevorgänge werden nicht gecacht).
- Commit-Tree gegen Arbeitsstand (47 Dateien identisch), keine Dateimodus-Änderung (`ErrorList.py` bleibt 100755), keine `__pycache__`/`parser.out`-Reste.
- `./mach lint` nicht ausgeführt (braucht Bootstrap, Phase 12).

## Grenzen und Hinweise für spätere Phasen

- **Sprites bei `css.interaction`** (Standard an!): Hover-Regeln, die dieselbe Bild-URL wiederholen, zeigen beim Hover kein Bild; nur Regeln, die `background-position` ändern, funktionieren. Seitenbrüche: Icons, die beim Hover wechseln oder verschwinden, eigene Checkbox-/Radio-Grafiken mit externen Bildern. Für betroffene Seiten den Schalter pro Seite ausschalten.
- `css.interaction` deckt Umwege nicht ab (Custom Properties, `@keyframes`, eingeblendete Teilbäume, Container-Style-Queries, Web-Fonts, externe SVG-Ressourcen) – siehe `css.md`. Mit JavaScript lässt sich Interaktion ohnehin messen (Phase 7).
- Teilen zwei gleichzeitig offene Dokumente derselben Site ein Stylesheet mit verschiedenen Einstellungen, teilen sie die Bilder bzw. bei Mustern einen gleichzeitig laufenden Ladevorgang (nur nach einer Schalteränderung, solange beide offen sind).
- **Phase 7**: Die Interaktions-Pseudoklassen liegen in `servo/components/style/fawkes.rs` (`INTERACTION_STATES`); wer neue Profiling-Schalter für CSS braucht, kann dort ansetzen.
- **Phase 8**: Media-Features kommen aus RFP (`nsMediaFeatures.cpp`) und `FawkesCss.cpp` (`FixesMediaFeature`, `FixMediaFeatures`); bei aktiver Randomisierung müssen `device-*`, `resolution`, `color` zu den randomisierten JS-Werten (Screen, `devicePixelRatio`, `colorDepth`) passen – am einfachsten dort, wo RFP die Werte liefert. Vorschlag wie in Phase 5: Blockier-Schalter vor Randomisierung.
- **Phase 12**: Kritische Stellen für den ersten Build: `servo/components/style/fawkes.rs` (Visitor-Signaturen mit Gecko-Typen `AtomIdent`/`Namespace`, `atom!("value")`), die cbindgen-Konstante `StyleLoadDataFlags::FAWKES_INTERACTION`, bindgen für `Gecko_MediaFeatures_FawkesFixed`, `FawkesPatterns.h` (Header zieht `RustRegex.h`/`rure.h` in `StreamLoader.cpp`), Unified-Build-Namen in `toolkit/components/fawkes`. Die Standardschalter `css.interaction` und `css.localFonts` sind für alle http(s)-Sites an und können Upstream-Tests stören, die auf Testseiten (mochi.test, example.com) Hover-Bilder oder `local()`-Schriften erwarten (Reftests unter `layout/reftests/font-face/`, `:hover`-Bildtests); dort ggf. per `Services.fawkes.setDefault()` im Harness abschalten.

## Manuelle Prüf-Checkliste (Phase 12)

1. CSS-Keylogger-Demo (z. B. eine lokale Seite mit `input[value$="a"] { background: url(http://127.0.0.1:…/a) }` und einem Framework, das `value` spiegelt): Standard → im Netzwerkmonitor keine Requests beim Tippen; Schalter „Interaktions-Tracking ohne JavaScript“ aus → Requests pro Zeichen.
2. Hover-Tracking: Seite mit `a:hover { background: url(…) }` → kein Request beim Hovern; ein normal gesetztes Hintergrundbild lädt.
3. Eine Seite mit Sprite-Icons, die beim Hover wechseln (Bild-URL in der Hover-Regel wiederholt) → Icon verschwindet beim Hover (erwartet); Schalter für die Seite aus → wieder normal.
4. BrowserLeaks Fonts / CreepJS: `local()`-Erkennung über `@font-face` findet keine installierten Schriften; Seiten mit Web-Fonts sehen normal aus.
5. Media Queries (z. B. eine Seite, die `matchMedia`-Werte anzeigt, oder CreepJS „CSS media“): RFP-Werte; mit „Media-Query-Fingerprinting“ an und dunklem Systemthema (Tor-Browser-Einstellung „Website-Darstellung: dunkel“) bleibt `prefers-color-scheme: light`, `display-mode` im Vollbild `browser`.
6. Scroll-Animationen: in `about:config` `layout.css.scroll-driven-animations.enabled=true`, Demo-Seite mit `animation-timeline: scroll()` → Schalter an: Element bleibt statisch, aus: Animation folgt dem Scrollen. Mit Pref aus: Menüpunkt angehakt und deaktiviert.
7. Eigene Stylesheet-Muster: z. B. `googleapis` oder den Namen eines Werbe-CSS eintragen, Schalter an → das Stylesheet erscheint im Netzwerkmonitor, aber die Seite ist ohne dessen Regeln; Konsole/`link.onerror`; andere Site unberührt.
8. NoScript, Reader View, PDF.js und `about:`-Seiten mit allen CSS-Schaltern an → unverändert.

## Anwendungsprobe

Index-Probe (temporärer Index, `git read-tree fawkes-base`, dann `git apply --cached` in Phasenreihenfolge):

- Sammeldateien: `phase-01-branding.patch` bis `phase-06-css.patch` bestehen `git apply --check` und ergeben den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`), `fawkes-phase-02` (`ded25fd99f13`), `fawkes-phase-03` (`aa18953cfa4f`), `fawkes-phase-04` (`dd9f9ead8e67`), `fawkes-phase-05` (`33768452f3ad`) bzw. `fawkes-phase-06` (`6d56d5b6daa0`).
- Serien: alle Patches aus `phase-01-branding/` (6), `phase-02-framework/` (7), `phase-03-no-tor/` (8), `phase-04-network/` (9), `phase-05-js-apis/` (10) und `phase-06-css/` (8) lassen sich anwenden und ergeben exakt den Tree von `fawkes-phase-06` (`6d56d5b6daa0`).
- **Ergebnis: grün.**

Die Probe mit `git am` im Prüf-Worktree entfällt weiterhin auf Ihren Wunsch (über sshfs zu langsam).

Phase 6 ändert tor-browser-build nicht.
