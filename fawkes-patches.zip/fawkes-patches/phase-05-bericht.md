# Phase 5 – JavaScript-API-Kategorien, WebRTC, eigene JS-Muster: Bericht

## Commits

tor-browser (Branch `fawkes`, Basis `fawkes-phase-04` = `bd7485e2602a`, Tag `fawkes-phase-05` = `70d20508417c`):

| Schritt | Commit | Inhalt |
| --- | --- | --- |
| 1 | `912fb2ee9e7e` | Fawkes: Add the strings of the WebRTC menu item |
| 2 | `cc3f604a00e7` | Fawkes: Ignore event listeners of blocked API categories |
| 3 | `05bf9c86accc` | Fawkes: Block WebGL, canvas readout and audio fingerprinting per site |
| 4 | `fab4a53632a1` | Fawkes: Hide device information, sensors and local fonts per site |
| 5 | `07a44fb7d67f` | Fawkes: Block storage supercookies, beacons and clipboard reads per site |
| 6 | `e0d1db14380f` | Fawkes: Block hardware interfaces and DRM and pause background pages |
| 7 | `d04e567f7adf` | Fawkes: Allow WebRTC per site |
| 8 | `865c8654107a` | Fawkes: Drop scripts that match the custom script patterns |
| 9 | `b431dbb616d3` | Fawkes: Test the JavaScript protection |
| 10 | `70d20508417c` | Fawkes: Document the JavaScript protection |

Patches: `fawkes-patches/phase-05-js-apis/` (10 Dateien) und `fawkes-patches/phase-05-js-apis.patch`.
Plan: `/home/dh/.claude/plans/fawkes-phase-05.md` (ohne Rückfrage umgesetzt, wie vereinbart).
Ausführliche technische Doku: `browser/components/fawkes/docs/js-apis.md`; die finale Tabelle Kategorie → APIs → Mechanismus → Bruchrisiko steht in `browser/components/fawkes/docs/categories.md`.

## Was jetzt da ist

Alle JavaScript-Schalter und der WebRTC-Schalter wirken jetzt in der Engine (WebIDL-Bindings, DOM-Implementierungen, Event-System, Skriptlader), ohne Erweiterung und ohne in die Seite eingeschleustes JavaScript. Betroffen ist nur Web-Inhalt: Browserseiten, about:, PDF.js, Erweiterungsseiten, System-Principal und die Sandboxes von Content-Scripts haben keine Fawkes-Flags. NoScript und andere Erweiterungen behalten auch Listener, die sie über Xray-Wrapper auf Seiten registrieren, weil maßgeblich das Global des Listener-Codes ist.

- **WebGL/WebGPU** (`js.webgl`, Standard an): alle `WebGL*`-Interfaces und `WebGLContextEvent` entfernt (`[Func]`), WebGPU samt `navigator.gpu` über `webgpu::Instance::PrefEnabled`; `getContext("webgl"/"experimental-webgl"/"webgl2"/"webgpu")` liefert `null`, auch auf `OffscreenCanvas` in Workern.
- **Canvas-Auslesen** (`js.canvas`, aus): `toDataURL`, `toBlob`, `getImageData`, `OffscreenCanvas.convertToBlob` (und WebGL `readPixels`) liefern Firefox' Platzhalter, ohne Canvas-Abfrage; `measureText()` rundet alle Metriken auf ganze Pixel.
- **Audio** (`js.audio`, aus): `OfflineAudioContext` und `OfflineAudioCompletionEvent` entfernt; `AnalyserNode` liefert Stille; der Eingangspuffer von `ScriptProcessorNode`-Events und die Eingänge von `AudioWorklet`-Prozessoren sind still.
- **Geräte-Infos** (`js.device`, aus): `hardwareConcurrency` (Fenster und Worker) und `maxTouchPoints` mit den RFP-Werten, `screen.orientation` fest (`landscape-primary`, 0), keine Plugins/MIME-Typen, `pdfViewerEnabled` = false, `getGamepads()` leer, `enumerateDevices()` leer, `getVoices()` leer, `navigator.connection`/`NetworkInformation` entfernt, Gamepad- und `devicechange`-Listener ignoriert.
- **Sensoren & Standort** (`js.sensors`, an): Geräte-Event-Interfaces, `ondevice*`/`onuserproximity` am `Window`, `navigator.geolocation` und die `Geolocation*`-Interfaces entfernt; Sensor-Listener werden ignoriert (die Sensoren werden gar nicht erst eingeschaltet).
- **Schriften** (`js.fonts`, aus): `local()`-Quellen von FontFaces, die Skripte anlegen, werden übersprungen; `FontFace.load()` kann installierte Schriften nicht mehr abtasten.
- **Speicher-Supercookies** (`js.storage`, aus): `localStorage`/`sessionStorage` leben nur so lange wie das Dokument (im Speicher), `indexedDB` ist `null` (Fenster und Worker), `caches`/`Cache`, Service Worker, `BroadcastChannel` und `SharedWorker` entfernt.
- **Beacons & Telemetrie** (`js.beacons`, an): `sendBeacon()` meldet Erfolg und sendet nichts, `keepalive` wird ignoriert, keine `<a ping>`-Pings (auch mit `browser.send_pings`), keine Resource-Timing-Einträge, Reporting API entfernt.
- **Zwischenablage** (`js.clipboard`, aus): `copy`/`cut`/`paste`/`selectionchange`-Listener, -Properties und -Attribute von Web-Inhalten werden ignoriert; `clipboard.read()`/`readText()` liefern eine leere Zwischenablage ohne Einfüge-Abfrage.
- **Hardware-Schnittstellen** (`js.hardware`, an): Web MIDI, Web Serial (Fenster und Dedicated Worker), Web Share, `PushManager`, Wake Lock, WebXR-Einstieg entfernt.
- **DRM** (`js.drm`, an): `requestMediaKeySystemAccess()`, alle `MediaKey*`-Interfaces und die EME-Member der Media-Elemente entfernt.
- **Hintergrund-Pause** (`js.backgroundPause`, aus): Seiten in Hintergrund-Tabs und in inaktiven Browserfenstern werden pausiert: Timer, Idle-Callbacks, Worker und AudioContexts angehalten, keine `requestAnimationFrame`-Callbacks, Medien angehalten (ohne `pause`-Event). Das Zeichnen läuft weiter.
- **WebRTC** (`blockWebRTC`, an; im Menü „WebRTC aktivieren“): alle WebRTC-Interfaces, `MediaStreamEvent` und `onrtctransform` per `[Func]`, dazu `navigator.mediaDevices`. Bei aktiver Proxy-Kette und auf Nicht-Web-Seiten immer aus. Der Menüpunkt ist deaktiviert und erklärt warum, wenn der Build kein WebRTC enthält oder die Proxy-Kette läuft.
- **Eigene JS-Muster** (`js.customPatterns`, aus; `fawkes.patterns.js`): passende externe, Inline-, Modul- und Worker-Skripte werden vor dem Kompilieren verworfen.

## Entscheidungen ohne Rückfrage (bitte prüfen)

1. **WebRTC bleibt ausgebaut (mozconfig unverändert).** `browser/config/mozconfigs/base-browser` enthält `ac_add_options --disable-webrtc` (laut Kommentar baut WebRTC nicht mit MinGW, also nicht für Windows im Tor-Browser-Build). Ich habe die konservative Variante gewählt: Zeile bleibt, der Schalter ist vollständig umgesetzt, wirkt aber erst, wenn WebRTC einkompiliert wird. **Nötige Änderung, falls gewünscht:** die Zeile `ac_add_options --disable-webrtc` in `browser/config/mozconfigs/base-browser` entfernen (Linux/macOS; für Windows/MinGW müsste WebRTC erst dort bauen). Das Menü zeigt bis dahin „WebRTC aktivieren (in dieser Version nicht enthalten)“, deaktiviert.
2. **`media.peerconnection.enabled` = true** (`fawkes-prefs.js`). Der Fawkes-Schalter (Standard: blockiert) ist das eigentliche Tor; ohne die globale Pref könnte „WebRTC aktivieren“ nie etwas bewirken. Damit Tor Browsers Verhalten an anderer Stelle nicht schwächer wird: `navigator.mediaDevices` (Kamera/Mikrofon), das Gecko an diese Pref koppelt, gibt es nur auf Sites mit erlaubtem WebRTC, und Seiten, die kein Web-Inhalt sind (about:, Erweiterungen, `file:`), bekommen WebRTC nie.
3. **Mit Tor zusätzlich `media.peerconnection.ice.proxy_only` = true** (fail closed), zu Tor Browsers `relay_only`, `proxy_only_if_behind_proxy`, `no_host`, `default_address_only` und mDNS. Über Tor funktioniert nur TURN über TCP/TLS durch den Tor-SOCKS-Proxy (`WebrtcTCPSocket` kann SOCKS); STUN, UDP und Direktverbindungen nicht. **Ohne Tor** setzt `directModePrefs()` `proxy_only` und `relay_only` auf false (UDP, STUN, Peer-to-Peer wie in anderen Browsern); `no_host`, `default_address_only` und mDNS bleiben an, lokale Adressen bleiben verborgen. Die öffentliche Adresse sieht der Peer dann – wie jede Website im Direktbetrieb.
4. **Canvas: Firefox' Platzhalter** (bei jedem Auslesen neue Zufallspixel) statt eines konstanten Bildes, weil es der vorhandene Engine-Pfad ist (`CanvasUtils::ImageExtractionResult`) und nichts Wiedererkennbares liefert; die Canvas-Abfrage von Tor Browser erscheint dabei nicht. `measureText()` wird gerundet statt auf Null gesetzt, damit Diagramme und Textlayouts weiter funktionieren.
5. **Audio: `AudioBuffer.getChannelData()` wird nicht neutralisiert.** Seiten füllen eigene Puffer über dieses Array (Spiele, Synthesizer); ein neutralisiertes Array hätte jede selbst erzeugte Audioausgabe stumm geschaltet. Stattdessen ist das still, was die Engine aus einem Audiograph rendert und Seiten zurücklesen können: `OfflineAudioContext` (entfernt), `AnalyserNode`, `ScriptProcessorNode`-Eingang, `AudioWorklet`-Eingänge.
6. **Geräte-Werte = RFP-Werte** (4 Kerne, unter macOS 8; 0 Touchpoints; `landscape-primary`/0; keine Plugins, also `pdfViewerEnabled` = false). Mit RFP liefert Tor Browser großteils schon dieselben Werte; der Schalter hält sie fest, auch wenn Phase 8 pro Site randomisiert (dort ist zu entscheiden, wer Vorrang hat; mein Vorschlag: der Blockier-Schalter).
7. **Speicher: `localStorage`/`sessionStorage` pro Dokument statt entfernt.** Viele Seiten rufen `localStorage.getItem()` ohne Prüfung auf und würden mit einer Ausnahme abbrechen. Genutzt wird Firefox' vorhandener partitionierter Speicher (`PartitionedLocalStorage` mit eigenem `SessionStorageCache`). `indexedDB` ist laut WebIDL nullable und wird `null`. `window.name` über Site-Grenzen löscht Firefox bereits (`privacy.window.name.update.enabled`, Standard an).
8. **Beacons neutralisiert statt Fehler**: `sendBeacon()` gibt `true` zurück, `keepalive` wird ignoriert (der Request läuft normal, wird aber beim Verlassen der Seite abgebrochen), Resource-Timing-Einträge werden gar nicht aufgezeichnet (statt `PerformanceObserver` zu entfernen, den viele Seiten für andere Eintragstypen nutzen).
9. **Zwischenablage**: Schreiben (`writeText()`, Kopier-Buttons) bleibt erlaubt; nur Lesen und die Events sind betroffen.
10. **Hardware**: Gecko hat weder WebUSB noch WebHID noch Web Bluetooth; Payment Request ist nur in Nightly gebaut (kein Hook nötig). Bei WebXR entferne ich den Einstieg (`navigator.xr`, `XRSystem`); die übrigen `XR*`-Interfaces hängen an `dom.vr.webxr.enabled`, das Tor Browser ausschaltet. MIDI/Share/Push über ihre vorhandenen Func-Funktionen (`Navigator::HasMidiSupport`, `HasShareSupport`, `PushManager::IsEnabled`).
11. **Hintergrund-Pause**: „unfokussiertes Fenster“ = Browserfenster ist nicht das aktive Fenster. Pausiert wird wie bei einem modalen Dialog (`nsGlobalWindowInner::Suspend`), Medien wie im Back-Forward-Cache. Ich habe bewusst **nicht** `Document::IsRenderingSuppressed` genutzt, weil das im sichtbaren, aber inaktiven Fenster auch das Zeichnen stoppt (eingefrorenes Fenster); stattdessen überspringt der Refresh-Driver nur die `requestAnimationFrame`-Callbacks. Netzwerk-Callbacks und `postMessage` laufen weiter (die Uhr steht, die Seite nicht). Ein pausiertes Dokument kommt nicht in den Back-Forward-Cache.
12. **Events**: maßgeblich ist das Global des Listener-Codes (entpackt), bei `on*`-Attributen das Global des Elements. Ein ignoriertes `on*`-Property liest danach `null` und entfernt einen früheren Handler (wie ein von CSP blockiertes Attribut).
13. **Eigene Muster – Semantik wie FawkesWeb**: jede Zeile (getrimmt) als Teilstring *und*, wenn gültig, als regulärer Ausdruck, beides ohne Groß-/Kleinschreibung. Regex-Syntax ist die des Rust-`regex`-Crates (kein Look-around, keine Rückverweise); solche Zeilen zählen nur als Teilstring, wie FawkesWeb ungültige Regex ignoriert. Kompiliert wird mit dem im Tree vorhandenen `mozilla::RustRegexSet` (`xpcom/string/RustRegex.h`, C-API `rure` des vendorten `regex`-Crates 1.12.3) – dadurch kein neues Rust-Crate und keine `Cargo.lock`-Änderung.
14. **`fawkes.patterns.js` bleibt eine normale Pref** (keine Static Pref wie in Phase 4): alle Aufrufer laufen im Hauptthread (auch die Worker-Skripte werden im Hauptthread geladen), und die Pref hat einen Standardwert, wird also an Content-Prozesse nicht saniert gesendet. Phase 6 (CSS-Muster) kann denselben Weg gehen.
15. **Verworfene Skripte**: extern mit `error`-Event und neuem Fehlercode `NS_ERROR_FAWKES_SCRIPT_BLOCKED` (Modul FAWKES, 5), inline ohne Event wie ein CSP-Block, Worker-Skripte als Ladefehler (`importScripts()` wirft `NetworkError`). Solange Muster gelten, umgeht das Dokument den Skript-Cache im Speicher und lädt Quelltext statt serialisierter Stencils, damit kein Skript ungeprüft durchrutscht.

## Geänderte Upstream-Dateien (dünne Hooks, für spätere Rebases)

| Datei | Änderung |
| --- | --- |
| `dom/events/EventListenerManager.cpp` | Prüfung in `AddEventListenerInternal`, `SetEventHandler` (Property und Attribut) |
| `dom/canvas/CanvasRenderingContextHelper.cpp`, `CanvasUtils.cpp`, `CanvasRenderingContext2D.cpp` | `getContext()` → `null`, Platzhalter, gerundete Textmetriken |
| `dom/webgpu/Instance.h` | `PrefEnabled(cx, obj)` fragt Fawkes |
| `dom/media/webaudio/AnalyserNode.cpp`, `ScriptProcessorNode.cpp`, `AudioWorkletNode.cpp` | Stille |
| `dom/base/Navigator.cpp`, `dom/workers/WorkerNavigator.cpp`, `dom/base/nsPluginArray.cpp`, `dom/base/ScreenOrientation.cpp`, `dom/media/MediaDevices.cpp`, `dom/media/webspeech/synth/SpeechSynthesis.cpp` | Geräte-Werte, `sendBeacon`, MIDI/Share/getUserMedia-Funcs |
| `dom/base/nsGlobalWindowInner.cpp` | Sensor-Func, `localStorage`/`sessionStorage`/`indexedDB` |
| `layout/style/FontFaceSetImpl.cpp` | `local()`-Quellen überspringen |
| `dom/workers/WorkerScope.cpp`, `dom/cache/Cache.cpp`, `dom/serviceworkers/ServiceWorkerUtils.cpp` | `indexedDB` im Worker, Caches, Service Worker |
| `dom/fetch/Request.cpp`, `docshell/base/nsPingListener.cpp`, `dom/performance/Performance.cpp` | `keepalive`, Pings, Resource Timing |
| `dom/events/Clipboard.cpp` | `read()`/`readText()` |
| `dom/push/PushManager.cpp` | Push |
| `dom/base/Document.{h,cpp}`, `layout/base/nsRefreshDriver.cpp`, `dom/media/mediaelement/HTMLMediaElement.cpp` | Hintergrund-Pause |
| `dom/script/ScriptLoader.cpp`, `dom/workers/loader/NetworkLoadHandler.cpp`, `CacheLoadHandler.cpp` | Eigene Muster, Cache-Umgehung |
| `xpcom/base/ErrorList.py`, `js/xpconnect/src/xpc.msg` | `NS_ERROR_FAWKES_SCRIPT_BLOCKED` (5) |
| 56 Dateien in `dom/webidl/` | ein `Func="mozilla::FawkesBindings::…"` je Interface/Member: WebGL (3), Offline-Audio (2), Navigator, WorkerNavigator, NetworkInformation, Geolocation (4), Window, BroadcastChannel, SharedWorker, Reporting, Serial (2), Wake Lock (2), WebXR, EME (7 + HTMLMediaElement), WebRTC (25 + MediaStreamEvent, DedicatedWorkerGlobalScope) |

Neuer Code: `toolkit/components/fawkes/` (`FawkesBindings.{h,cpp}`, `FawkesDom.{h,cpp}`, `FawkesScriptPatterns.{h,cpp}`, Erweiterungen in `FawkesFlags`, `FawkesTorMode.sys.mjs`, `moz.build`) und `browser/components/fawkes/` (WebRTC-Menüpunkt in `Fawkes.sys.mjs`, Prefs, Strings, `docs/js-apis.md`, `docs/categories.md`).

## Tests (geschrieben, laufen erst in Phase 12)

| Anforderung (Abschnitt 8) | Test |
| --- | --- |
| jede JS-Kategorie mit lokaler Testseite, blockiert vs. nicht blockiert, Fenster und Worker | `browser_fawkes_js_graphics.js` (WebGL, Canvas, Audio), `browser_fawkes_js_device.js` (Geräte, Sensoren, Schriften), `browser_fawkes_js_storage.js` (Speicher inkl. Neuladen, Beacons mit Zähl-Server, Zwischenablage), `browser_fawkes_js_hardware.js` (Hardware, DRM, andere Site unberührt), `browser_fawkes_js_background.js` (Hintergrund-Tab und inaktives Fenster); Testseite `file_fawkes_js.html`, Worker `file_fawkes_js_worker.js`, Helfer `head_js.js`, `file_fawkes_counter.sjs` |
| Event-Listener (Listener, `on*`-Property, `on*`-Attribut), Browsercode behält Listener | in `browser_fawkes_js_storage.js` (Zwischenablage), `browser_fawkes_js_device.js` (Gamepad, Sensoren) |
| WebRTC | `browser_fawkes_webrtc.js`: Prefs, Standard blockiert, pro Site erlaubt (wenn einkompiliert), Proxy-Kette, about:-Seite, Menüpunkt; Direktbetrieb in `xpcshell/test_fawkes_tor_mode.js` |
| Eigene Muster | `browser_fawkes_script_patterns.js`: Teilstring ohne Groß-/Kleinschreibung, Regex, ungültige Regex als Teilstring, inline/extern/Modul/`import()`/Worker/`importScripts()`, Cache, keine Muster, andere Site |
| Menü | `browser_fawkes_button.js` angepasst (WebRTC-Punkt ohne WebRTC-Build deaktiviert) |

## Prüfungen ohne Build

- **WebIDL-Parser aus dem Tree** über alle 921 Dateien von `dom/webidl` und `dom/chrome-webidl` (mit Präprozessor, `MOZ_WEBRTC` und `MOZ_WEBSPEECH` an, generierte CSS-Interfaces als Stubs): fehlerfrei; jede neue `Func`-Angabe an Interface bzw. Member ist angekommen.
- **Muster-Semantik gegen das vendorte `regex` 1.12.3** (kleines Rust-Programm im Scratchpad mit `third_party/rust` als Quelle, kein Browser-Build): Escaping identisch zu `regex::escape`, ungültige Regex (offene Klammer, Look-ahead, Rückverweis) werden erkannt und nur als Teilstring genutzt, Unicode-Groß-/Kleinschreibung, leere Zeilen – alle Erwartungen grün. Die `rure`-Optionen (Bytes-Set, Unicode, Case-insensitive) entsprechen denen von `RustRegexOptions`.
- `ErrorList.py`-Generator: `NS_ERROR_FAWKES_SCRIPT_BLOCKED = 0x80760005`, keine Kollision im Modul.
- `fluent.syntax`: beide FTL-Dateien fehlerfrei, gleiche IDs (133 Nachrichten).
- `node --check` für alle neuen bzw. geänderten JS/MJS-Dateien (inkl. Inline-Skript der Testseite, `.sjs`, `fawkes-prefs.js`); TOML des Test-Manifests geparst.
- C++ von Hand gegen die Header geprüft, u. a. `PrefableDisablers` (Func bekommt das Global), Codegen leitet den Header aus `mozilla::FawkesBindings::X` ab, `CallbackObject::CallbackPreserveColor`, `js::UncheckedUnwrap`, `JS::GetNonCCWObjectGlobal`, `xpc::NativeGlobal` (auch im Worker), Überladungen von `fawkes::IsActive` (JSObject*/Document*/nsIGlobalObject*), `nsGlobalWindowInner::Suspend/Resume`, `Document`-Zugriffsrechte, `LoadedScript::ScriptText<>`, `RustRegexSet`-Konstruktor, `AppendUTF16toUTF8(…, fallible)`, `nsTArray::RemoveElementsBy`, Namensräume aller Hook-Dateien. Bei der Prüfung geändert: die rAF-Pause sitzt im Refresh-Driver statt in `IsRenderingSuppressed` (s. Entscheidung 11).
- Commit-Tree gegen Arbeitsstand (127 Dateien identisch), keine Dateimodus-Änderung (`ErrorList.py` bleibt 100755), keine `__pycache__`-Reste, 80 Spalten in neuem Code.
- `./mach lint` nicht ausgeführt (braucht Bootstrap, Phase 12).

## Grenzen und Hinweise für spätere Phasen

- Entfernte Interfaces machen den Browser eher unterscheidbarer (die Lücken sind sichtbar); die Schalter machen Funktionen unbrauchbar, sie tarnen nicht.
- `[Func]`-Prüfungen von `Window`-Membern (`ondevicemotion`, `caches`) gelten mit den Flags beim Anlegen des Fensters (Phase-2-Grenze; wird das anfängliche `about:blank`-Fenster für ein gleichherkünftiges Dokument wiederverwendet, bleiben sie wie beim `about:blank`, das dieselben Flags hat).
- Eigene Muster erfassen nicht: `eval()`, `new Function()`, `setTimeout(String)`, `on*`-Attribute, `javascript:`-URLs, Worklet-Module, Import-Maps.
- `js.audio` schaltet nicht still, was Seiten selbst dekodieren oder erzeugen; `js.fonts` verhindert keine Messung von DOM-Text mit Ersatzschriften (Tor Browsers Schriften-Allowlist begrenzt das).
- `js.backgroundPause` hält Uhren an, nicht die Seite: Netzwerk-Events und Nachrichten anderer Fenster kommen weiter an.
- **Phase 6**: `css.localFonts` kann `fawkes::IgnoreLocalFontSources()` um `@font-face`-Regeln erweitern (`HasRule()` + Dokument-Flags); `css.customPatterns` kann `FawkesScriptPatterns.cpp` als Vorlage nehmen (eigene Pref, `Loader::ShouldBypassCache`, Prüfung vor dem Parsen im Hauptthread).
- **Phase 7**: neue Event-Typen in `SwitchForEvent()` (`FawkesDom.cpp`) eintragen; `profiling.attention` (`document.hidden` = false) und die Hintergrund-Pause sind unabhängig (die Pause hängt am echten Zustand).
- **Phase 8**: `js.device` hält feste Werte; bei aktiver Randomisierung ist der Vorrang zu entscheiden (Vorschlag: Blockier-Schalter vor Randomisierung). Canvas: `js.canvas` (Platzhalter) steht in `ImageExtractionResult` vor der Randomisierung.
- **Phase 10**: WebRTC ist bei aktiver Proxy-Kette erzwungen aus (`FawkesBindings::WebRTCExposed`, Menüpunkt deaktiviert).
- **Phase 12**: Kritische Stellen für den ersten Build: Codegen der `[Func]`-Header (`mozilla/FawkesBindings.h` in vielen Binding-Dateien), `FawkesDom.cpp` (viele DOM-Header, `TextMetrics`, `FontFaceImpl`), `FawkesScriptPatterns.cpp` (`RustRegexSet` mit `nsTArray<nsCString>`), die `Maybe<FawkesSwitch>`-Ausdrücke, Unified-Build-Namenskonflikte statischer Funktionen. Die Standardschalter `js.webgl`, `js.sensors`, `js.beacons`, `js.hardware`, `js.drm` sind für alle Sites an und können Upstream-Tests stören, die WebGL, Geräte-Events, `sendBeacon`, Resource Timing, Wake Lock oder EME auf http(s)-Testseiten erwarten (example.com, mochi.test); dort ggf. per `Services.fawkes.setDefault()` im Harness abschalten. Die Tests der Hintergrund-Pause und von Audio hängen von Fenster-Fokus bzw. Audio-Ausgabe im Testlauf ab.

## Manuelle Prüf-Checkliste (Phase 12)

1. BrowserLeaks WebGL / `get.webgl.org`: mit Standard („WebGL und WebGPU“ an) „not supported“, `typeof WebGLRenderingContext` undefined; Schalter aus → WebGL läuft.
2. BrowserLeaks Canvas: „Canvas-Auslesen“ an → Signatur ändert sich bei jedem Neuladen, keine Canvas-Abfrage von Tor Browser; aus → wie bisher (Abfrage bzw. Tor-Browser-Verhalten).
3. Audio-Fingerprint-Seite (z. B. audiofingerprint.openwpm.com): „Audio-Fingerprinting“ an → OfflineAudioContext fehlt, Analyser-Werte still; ein Musikplayer spielt weiter.
4. EFF Cover Your Tracks / CreepJS: Geräte-Infos an → 4 Kerne (macOS 8), keine Plugins, `pdfViewerEnabled` false; Sensoren-Werte fehlen.
5. Speicher an: eine Seite mit Login (z. B. ein Forum) → Login geht nach jedem Seitenwechsel verloren (erwartet); `localStorage` innerhalb der Seite funktioniert.
6. Beacons an: Netzwerkmonitor zeigt für `sendBeacon` keinen Request; `performance.getEntriesByType("resource")` in der Konsole leer.
7. Zwischenablage an: Seite mit „Weiterlesen“-Kopieranhang (Tynt-artig) → kopierter Text bleibt unverändert; Rich-Text-Editor: Einfügen per Strg+V funktioniert weiter (Browser-Einfügen), Seiten-Paste-Handler nicht.
8. Hardware an: `navigator.wakeLock` undefined; Videoportal: Bildschirm darf ausgehen.
9. Hintergrund-Pause an: Seite mit sichtbarem Timer/Animation → in anderem Tab bzw. bei Fokus in anderem Programm steht sie, bei Rückkehr läuft sie weiter; Musik pausiert im Hintergrund.
10. Eigene Muster: „Skriptmuster“ mit z. B. `googletagmanager` füllen, Schalter an → Netzwerkmonitor: Skript geladen, aber Konsole „Laden fehlgeschlagen“, Tag Manager läuft nicht; eine andere Site bleibt unberührt.
11. NoScript: Menü öffnen, Site erlauben/verbieten, alles mit allen JS-Schaltern an → funktioniert unverändert.
12. WebRTC (nur nach Ändern der mozconfig): BrowserLeaks WebRTC → standardmäßig „RTCPeerConnection undefined“; „WebRTC aktivieren“ → mit Tor keine lokale/öffentliche IP, nur Relay über TCP; ohne Tor öffentliche IP (erwartet), keine lokale; Proxy-Kette an → wieder undefined.

## Anwendungsprobe

Index-Probe (temporärer Index, `git read-tree fawkes-base`, dann `git apply --cached` in Phasenreihenfolge):

- Sammeldateien: `phase-01-branding.patch` bis `phase-05-js-apis.patch` bestehen `git apply --check` und ergeben den Tree von `fawkes-phase-01` (`fe16f9c6b5c4`), `fawkes-phase-02` (`ded25fd99f13`), `fawkes-phase-03` (`aa18953cfa4f`), `fawkes-phase-04` (`dd9f9ead8e67`) bzw. `fawkes-phase-05` (`33768452f3ad`).
- Serien: alle Patches aus `phase-01-branding/` (6), `phase-02-framework/` (7), `phase-03-no-tor/` (8), `phase-04-network/` (9) und `phase-05-js-apis/` (10) lassen sich anwenden und ergeben exakt den Tree von `fawkes-phase-05` (`33768452f3ad`).
- **Ergebnis: grün.**

Die Probe mit `git am` im Prüf-Worktree entfällt weiterhin auf Ihren Wunsch (über sshfs zu langsam).

Phase 5 ändert tor-browser-build nicht.
